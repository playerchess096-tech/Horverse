# -*- coding: utf-8 -*-
import os, sys, json, math, random, subprocess, wave
import numpy as np
from PIL import Image, ImageDraw
from scipy.signal import butter, lfilter
sys.path.insert(0, os.path.dirname(__file__))
from content import *
import items as IT
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
RES = ROOT + '/src/main/resources'; A = RES + '/assets/horror_universe'; D = RES + '/data/horror_universe'
def wj(p, o):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, 'w', encoding='utf-8') as f: json.dump(o, f, ensure_ascii=False, indent=1)
def rgb(h): return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))
def save(img, p):
    os.makedirs(os.path.dirname(p), exist_ok=True); img.save(p, optimize=True, compress_level=9)
MOBS = parse_mobs()
BOSSDEF = [('custode','humanoid',0.6,1.95,1.0),('corrotto','humanoid',0.6,1.95,1.0),('entity404','humanoid',0.7,2.3,1.2),
           ('mago','humanoid',0.6,1.95,1.0),('steve','humanoid',0.6,1.8,1.0),('osservatore','enderman',0.6,2.9,1.0)]
# ---------------------------------------------------------------- manifest
def build_manifest():
    items = IT.I + IT.eggs(MOBS)
    bosses = []
    for (bid, model, w, h, sc), b in zip(BOSSDEF, BOSSES):
        bosses.append(dict(id=bid, it=b[1], model=model, w=w, h=h, scale=sc, pal=b[2], glow=True))
    man = dict(items=items, blocks=IT.B, mobs=MOBS, bosses=bosses,
               effects=[dict(id=e[0], it=e[1], color=e[2], good=bool(e[3]), interval=e[4]) for e in EFFECTS], sounds=SOUNDS)
    wj(RES + '/horror_content.json', man); return man
# ---------------------------------------------------------------- texture helpers
def fbm(w, h, seed, octv=5, base=3):
    rng = np.random.default_rng(seed); acc = np.zeros((h, w), np.float32); amp = 1.0; tot = 0
    for o in range(octv):
        n = base * 2 ** o
        g = rng.random((max(2, n * h // max(w, h) + 2), max(2, n * w // max(w, h) + 2))).astype(np.float32)
        im = Image.fromarray((g * 255).astype(np.uint8)).resize((w, h), Image.BICUBIC)
        acc += np.asarray(im, np.float32) / 255 * amp; tot += amp; amp *= 0.55
    return acc / tot
def ramp(t, sh, ba, li):
    t = np.clip((t - 0.25) * 2.0, 0, 1)[..., None]; sh, ba, li = [np.array(c, np.float32) for c in (sh, ba, li)]
    lo = sh + (ba - sh) * np.clip(t * 2, 0, 1); hi = ba + (li - ba) * np.clip(t * 2 - 1, 0, 1)
    return np.where(t < 0.5, lo, hi)
def tex_noise(w, h, pal, seed, style='plain'):
    ba, sh, li, ac = [rgb(c) for c in PAL[pal]]
    t = fbm(w, h, seed); img = ramp(t, sh, ba, li)
    rng = np.random.default_rng(seed + 7)
    img *= (1 + (rng.random((h, w, 1)) - 0.5) * 0.14)
    yy, xx = np.mgrid[0:h, 0:w]
    if style in ('veins', 'cracks'):
        r = np.abs(fbm(w, h, seed + 3, 4, 4) - 0.5); m = (r < 0.025)[..., None]
        img = np.where(m, np.array(ac, np.float32) * (0.8 if style == 'veins' else 0.5), img)
    if style == 'bands': img *= (1 + 0.12 * np.sin(yy / max(1, h / 32.0))[..., None])
    if style == 'plates':
        img *= np.where(((xx // max(1, w // 8)) + (yy // max(1, h // 8))) % 2 == 0, 1.0, 0.86)[..., None]
    return np.clip(img, 0, 255)
def to_rgba(a): 
    o = np.dstack([a, np.full(a.shape[:2], 255, np.float32)]); return Image.fromarray(o.astype(np.uint8), 'RGBA')
def px(img, x0, y0, x1, y1, col, f):  # rettangolo in coordinate 64-base
    ImageDraw.Draw(img).rectangle([x0 * f, y0 * f, x1 * f - 1, y1 * f - 1], fill=col)
STYLE = {'white':'plain','pale':'bands','shadow':'cracks','corrupt':'cracks','green':'veins','rune':'veins','steel':'plates','obs':'plain','blood':'cracks','bone':'bands','ender':'cracks','storm':'plates','rust':'plates','gold':'plain'}
def paint_mob(mid, model, pal, glow, seed):
    f = 4; w = 64 * f; h = (64 if model == 'humanoid' else 32) * f
    ba, sh, li, ac = [rgb(c) for c in PAL[pal]]
    img = to_rgba(tex_noise(w, h, pal, seed, STYLE.get(pal, 'plain')))
    g = Image.new('RGBA', (w, h), (0, 0, 0, 0))
    skin = tuple(int(c * 0.9) for c in li) if pal in ('white', 'pale', 'bone') else ba
    if model in ('humanoid', 'skeleton', 'enderman', 'creeper'):
        px(img, 8, 8, 16, 16, skin + (255,), f)  # faccia
        for (ex0, ex1) in ((9, 11), (13, 15)):
            if pal in ('white', 'pale', 'bone', 'obs'):
                px(img, ex0, 11, ex1, 13, (255, 255, 255, 255), f); px(g, ex0, 11, ex1, 13, ac + (255,), f)
            else:
                px(img, ex0, 11, ex1, 13, (0, 0, 0, 255), f); px(g, ex0, 11, ex1, 12, ac + (255,), f)
        px(img, 10, 14, 14, 15, tuple(int(c * 0.35) for c in sh) + (255,), f)
        if pal == 'obs':  # volto liscio
            px(img, 8, 8, 16, 16, (210, 210, 215, 255), f); px(g, 9, 11, 11, 13, (255, 255, 255, 255), f); px(g, 13, 11, 15, 13, (255, 255, 255, 255), f)
    if not glow: g = None
    return img, g
def paint_special(bid, seed):
    f = 4; img, g = paint_mob(bid, 'humanoid' if bid != 'osservatore' else 'enderman', dict(custode='white', corrotto='corrupt', entity404='green', mago='rune', steve='steel', osservatore='obs')[bid], True, seed)
    if bid == 'steve':  # skin originale in stile "survivor": capelli castani, maglia azzurra, pantaloni blu
        img = Image.new('RGBA', (256, 256), (0, 0, 0, 0)); skin = (222, 170, 130, 255); hair = (80, 52, 30, 255); shirt = (60, 160, 190, 255); pants = (60, 60, 150, 255); shoe = (90, 90, 96, 255)
        px(img, 8, 0, 16, 8, hair, f); px(img, 16, 0, 24, 8, hair, f); px(img, 0, 8, 8, 16, skin, f); px(img, 8, 8, 16, 16, skin, f); px(img, 16, 8, 24, 16, skin, f); px(img, 24, 8, 32, 16, hair, f)
        px(img, 8, 8, 16, 10, hair, f); px(img, 0, 8, 8, 10, hair, f); px(img, 16, 8, 24, 10, hair, f)
        px(img, 9, 12, 11, 13, (255, 255, 255, 255), f); px(img, 13, 12, 15, 13, (255, 255, 255, 255), f); px(img, 9, 12, 10, 13, (60, 60, 160, 255), f); px(img, 14, 12, 15, 13, (60, 60, 160, 255), f); px(img, 10, 14, 14, 15, (140, 90, 70, 255), f)
        px(img, 16, 16, 40, 32, shirt, f); px(img, 20, 16, 36, 20, shirt, f)
        for x0 in (40, 32): px(img, x0, 16, x0 + 16, 32, shirt, f)
        px(img, 40, 28, 56, 32, skin, f); px(img, 32, 60, 48, 64, skin, f); px(img, 32, 48, 48, 60, shirt, f); px(img, 40, 16, 56, 28, shirt, f)
        px(img, 0, 16, 16, 32, pants, f); px(img, 16, 48, 32, 64, pants, f); px(img, 0, 30, 16, 32, shoe, f); px(img, 16, 62, 32, 64, shoe, f)
        px(img, 20, 16, 36, 17, (40, 120, 150, 255), f)
        rng = np.random.default_rng(seed); a = np.asarray(img, np.float32); a[..., :3] *= (1 + (rng.random(a.shape[:2] + (1,)) - 0.5) * 0.08); img = Image.fromarray(np.clip(a, 0, 255).astype(np.uint8), 'RGBA'); g = None
    if bid == 'corrotto':
        d = ImageDraw.Draw(img); rng = random.Random(5)
        for _ in range(60):
            x = rng.randrange(0, 256); y = rng.randrange(64, 256); d.line([x, y, x + rng.randrange(-20, 20), y + rng.randrange(8, 30)], fill=(176, 32, 255, 255), width=1)
    if bid == 'entity404':  # tunica bianca strappata
        d = ImageDraw.Draw(img); px(img, 20, 20, 28, 32, (225, 225, 225, 255), f); px(img, 32, 20, 40, 32, (205, 205, 205, 255), f)
    return img, g
def paint_all_mobs():
    n = 0
    for i, m in enumerate(MOBS):
        img, g = paint_mob(m['id'], m['model'], m['pal'], m['glow'], 1000 + i)
        save(img, A + '/textures/entity/%s.png' % m['id']); n += 1
        if g is not None: save(g, A + '/textures/entity/%s_glow.png' % m['id'])
    for i, (bid, model, w, h, sc) in enumerate(BOSSDEF):
        img, g = paint_special(bid, 5000 + i); save(img, A + '/textures/entity/%s.png' % bid)
        if g is None: g = Image.new('RGBA', (256, 256), (0, 0, 0, 0))   # Steve: nessun occhio luminoso (texture vuota)
        save(g, A + '/textures/entity/%s_glow.png' % bid)
    return n
# ---------------------------------------------------------------- icone oggetti (32x32)
def icon(kind, pal, seed=1):
    ba, sh, li, ac = [rgb(c) for c in PAL[pal]]; S = 32
    im = Image.new('RGBA', (S, S), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    B = ba + (255,); L = li + (255,); Sh = sh + (255,); Ac = ac + (255,); W = (110, 74, 40, 255)
    def ln(a, b, c, w=2): d.line([a, b, ], fill=c, width=w)
    if kind in ('sword', 'dagger', 'spear', 'scythe', 'scepter', 'staff', 'hammer'):
        ln((4, 28), (14, 18), W, 2)
        if kind == 'sword': ln((12, 20), (27, 5), B, 4); ln((13, 19), (27, 5), L, 1); ln((9, 16), (17, 24), Sh, 2)
        if kind == 'dagger': ln((12, 20), (22, 10), B, 3); ln((13, 19), (22, 10), L, 1); ln((9, 16), (17, 24), Sh, 2)
        if kind == 'spear': ln((10, 22), (27, 5), W, 2); d.polygon([(27, 3), (30, 8), (23, 7)], fill=L)
        if kind == 'scythe': ln((6, 26), (22, 6), W, 2); d.arc([10, 0, 31, 20], 200, 330, fill=L, width=3); d.arc([10, 2, 31, 22], 200, 330, fill=B, width=2)
        if kind == 'scepter': ln((5, 27), (21, 11), Sh, 3); d.ellipse([19, 3, 29, 13], fill=B, outline=L); d.ellipse([22, 6, 26, 10], fill=Ac)
        if kind == 'staff': ln((5, 27), (22, 10), W, 3); d.polygon([(22, 3), (28, 9), (22, 15), (16, 9)], fill=B, outline=L); d.ellipse([21, 8, 24, 11], fill=Ac)
        if kind == 'hammer': ln((6, 26), (20, 12), W, 3); d.rectangle([16, 3, 29, 14], fill=B, outline=Sh); d.rectangle([17, 4, 28, 6], fill=L)
    elif kind in ('pickaxe', 'axe', 'shovel', 'hoe'):
        ln((5, 27), (22, 10), W, 3)
        if kind == 'pickaxe': d.arc([6, 2, 30, 26], 215, 325, fill=B, width=4); d.arc([6, 3, 30, 27], 215, 325, fill=L, width=1)
        if kind == 'axe': d.polygon([(16, 5), (28, 7), (28, 19), (20, 16)], fill=B, outline=Sh); ln((17, 6), (27, 8), L, 1)
        if kind == 'shovel': d.ellipse([19, 2, 29, 12], fill=B, outline=Sh); ln((21, 4), (26, 4), L, 1)
        if kind == 'hoe': ln((12, 8), (28, 8), B, 3); ln((12, 8), (12, 14), B, 3)
    elif kind in ('helmet', 'chestplate', 'leggings', 'boots'):
        if kind == 'helmet': d.rectangle([7, 9, 24, 17], fill=B, outline=Sh); d.rectangle([7, 17, 11, 23], fill=B, outline=Sh); d.rectangle([20, 17, 24, 23], fill=B, outline=Sh); d.rectangle([8, 10, 23, 12], fill=L)
        if kind == 'chestplate': d.rectangle([7, 7, 24, 26], fill=B, outline=Sh); d.rectangle([2, 7, 8, 16], fill=B, outline=Sh); d.rectangle([23, 7, 29, 16], fill=B, outline=Sh); d.rectangle([13, 7, 18, 12], fill=Sh); d.rectangle([8, 9, 23, 11], fill=L)
        if kind == 'leggings': d.rectangle([7, 6, 24, 14], fill=B, outline=Sh); d.rectangle([7, 14, 13, 27], fill=B, outline=Sh); d.rectangle([18, 14, 24, 27], fill=B, outline=Sh); d.rectangle([8, 7, 23, 9], fill=L)
        if kind == 'boots': d.rectangle([5, 12, 12, 24], fill=B, outline=Sh); d.rectangle([4, 22, 14, 27], fill=B, outline=Sh); d.rectangle([19, 12, 26, 24], fill=B, outline=Sh); d.rectangle([18, 22, 28, 27], fill=B, outline=Sh)
    elif kind == 'ingot': d.polygon([(4, 20), (10, 10), (28, 10), (22, 20)], fill=B, outline=Sh); d.polygon([(4, 20), (22, 20), (22, 25), (4, 25)], fill=Sh); d.polygon([(10, 11), (27, 11), (24, 14), (8, 14)], fill=L)
    elif kind == 'gem': d.polygon([(16, 3), (27, 12), (22, 28), (10, 28), (5, 12)], fill=B, outline=Sh); d.polygon([(16, 3), (27, 12), (16, 14)], fill=L); d.polygon([(16, 14), (5, 12), (16, 3)], fill=Ac)
    elif kind == 'dust': 
        r = random.Random(seed)
        for _ in range(70): x = int(16 + r.gauss(0, 6)); y = int(20 + r.gauss(0, 4)); d.point((x, y), fill=r.choice([B, L, Sh, Ac]))
    elif kind in ('orb', 'pearl', 'eye', 'core'):
        d.ellipse([5, 5, 27, 27], fill=B, outline=Sh); d.ellipse([9, 8, 17, 15], fill=L)
        if kind == 'eye': d.ellipse([11, 11, 21, 21], fill=(250, 250, 250, 255)); d.ellipse([14, 14, 18, 18], fill=(10, 10, 10, 255))
        if kind == 'core': d.ellipse([11, 11, 21, 21], fill=Ac); d.ellipse([14, 14, 18, 18], fill=(255, 255, 255, 255))
    elif kind in ('token', 'scroll', 'rune'):
        if kind == 'scroll': d.rectangle([6, 7, 25, 25], fill=(220, 205, 160, 255), outline=Sh); d.rectangle([4, 5, 8, 27], fill=(190, 170, 120, 255)); d.rectangle([23, 5, 27, 27], fill=(190, 170, 120, 255)); [ln((10, y), (22, y), Sh, 1) for y in (11, 15, 19)]
        if kind == 'token': d.ellipse([5, 5, 27, 27], fill=B, outline=Sh); d.line([(11, 16), (21, 16)], fill=Ac, width=2); d.line([(16, 11), (16, 21)], fill=Ac, width=2)
        if kind == 'rune': d.polygon([(16, 2), (28, 16), (16, 30), (4, 16)], fill=B, outline=Sh); d.line([(12, 12), (20, 20)], fill=Ac, width=2); d.line([(20, 12), (12, 20)], fill=Ac, width=2)
    elif kind in ('fruit', 'apple'):
        d.ellipse([6, 8, 26, 28], fill=B, outline=Sh); d.ellipse([10, 11, 16, 17], fill=L); ln((16, 8), (19, 3), W, 2); d.polygon([(19, 5), (25, 3), (22, 9)], fill=Ac if kind == 'fruit' else Sh)
    elif kind == 'bread': d.ellipse([3, 11, 29, 27], fill=(200, 160, 100, 255), outline=(120, 80, 40, 255)); [ln((9 + 5 * i, 14), (11 + 5 * i, 22), (150, 105, 60, 255), 1) for i in range(4)]
    elif kind == 'amulet': d.arc([7, 1, 25, 19], 180, 360, fill=Sh, width=2); d.ellipse([8, 14, 24, 30], fill=B, outline=Sh); d.ellipse([13, 19, 19, 25], fill=Ac); d.ellipse([10, 16, 14, 20], fill=L)
    elif kind == 'vial': d.rectangle([13, 3, 19, 9], fill=(180, 180, 190, 255)); d.polygon([(13, 9), (19, 9), (26, 26), (6, 26)], fill=(200, 220, 230, 255), outline=Sh); d.polygon([(10, 18), (22, 18), (26, 26), (6, 26)], fill=B)
    elif kind == 'key': d.ellipse([4, 4, 16, 16], fill=B, outline=Sh); d.ellipse([8, 8, 12, 12], fill=(0, 0, 0, 0)); ln((14, 14), (27, 27), B, 3); ln((22, 22), (26, 18), B, 2); ln((25, 25), (29, 21), B, 2)
    elif kind == 'totem': d.polygon([(16, 2), (27, 10), (24, 28), (8, 28), (5, 10)], fill=B, outline=Sh); d.ellipse([11, 8, 21, 18], fill=L); d.ellipse([13, 11, 15, 13], fill=Sh); d.ellipse([17, 11, 19, 13], fill=Sh)
    elif kind == 'egg': return None
    a = np.asarray(im, np.float32); al = a[..., 3] > 0
    sh_ = np.zeros_like(al); sh_[1:, :] |= al[:-1, :]; sh_[:, 1:] |= al[:, :-1]; sh_[:-1, :] |= al[1:, :]; sh_[:, :-1] |= al[:, 1:]
    out = a.copy(); edge = sh_ & ~al
    out[edge] = [max(0, c * 0.25) for c in sh] + [255]; out[edge, :3] = np.array(sh) * 0.35
    rng = np.random.default_rng(seed); out[al, :3] *= (1 + (rng.random((int(al.sum()), 1)) - 0.5) * 0.12)
    return Image.fromarray(np.clip(out, 0, 255).astype(np.uint8), 'RGBA')
def paint_items(man):
    for it in man['items']:
        if it['kind'] == 'egg': continue
        im = icon(it['icon'], it['pal'], hash(it['id']) % 9999); save(im, A + '/textures/item/%s.png' % it['id'])
# ---------------------------------------------------------------- blocchi (64x64)
def block_tex(style, pal, seed):
    S = 64; ba, sh, li, ac = [rgb(c) for c in PAL[pal]]
    base = tex_noise(S, S, pal, seed, 'plain'); img = to_rgba(base); d = ImageDraw.Draw(img); yy, xx = np.mgrid[0:S, 0:S]
    if style in ('bricks',):
        for y in range(0, S, 16):
            d.line([0, y, S, y], fill=sh + (255,), width=2)
            for x in range((y // 16 % 2) * 16, S, 32): d.line([x, y, x, y + 16], fill=sh + (255,), width=2)
    if style in ('ore', 'ore_deep'):
        a = np.asarray(to_rgba(tex_noise(S, S, 'shadow' if style == 'ore_deep' else 'bone', seed + 1)), np.uint8); img = Image.fromarray(a, 'RGBA'); d = ImageDraw.Draw(img); r = random.Random(seed)
        for _ in range(7):
            cx, cy = r.randrange(6, 58), r.randrange(6, 58); d.ellipse([cx - 5, cy - 4, cx + 5, cy + 4], fill=ba + (255,), outline=li + (255,))
    if style == 'metal': d.rectangle([2, 2, 61, 61], outline=sh + (255,), width=3); d.rectangle([8, 8, 55, 55], outline=li + (255,), width=1)
    if style == 'flesh' or style == 'vein':
        r = np.abs(fbm(S, S, seed + 9, 4, 3) - 0.5); m = r < (0.035 if style == 'vein' else 0.02); a = np.asarray(img, np.float32); a[m, :3] = np.array(ac if style == 'vein' else li) * 0.9; img = Image.fromarray(a.astype(np.uint8), 'RGBA')
    if style == 'soil': a = np.asarray(img, np.float32); a[..., :3] *= 0.6; img = Image.fromarray(a.astype(np.uint8), 'RGBA')
    if style == 'cube' or style == 'glitch':
        d = ImageDraw.Draw(img); d.rectangle([0, 0, 63, 63], outline=li + (255,), width=3); d.rectangle([6, 6, 57, 57], outline=ac + (255,), width=2)
        if style == 'glitch':
            r = random.Random(seed)
            for _ in range(14): y = r.randrange(64); d.rectangle([r.randrange(0, 40), y, 63, y + r.randrange(1, 4)], fill=r.choice([ac, (0, 0, 0), (255, 255, 255)]) + (255,))
    if style == 'fog':
        a = np.zeros((S, S, 4), np.float32); t = fbm(S, S, seed, 4, 3); a[..., :3] = np.array(sh) * (0.5 + t[..., None]); a[..., 3] = 150 + 90 * t; img = Image.fromarray(a.astype(np.uint8), 'RGBA')
    if style == 'rune' or style == 'rune_node':
        d.rectangle([2, 2, 61, 61], outline=sh + (255,), width=3)
        d.line([(20, 16), (44, 48)], fill=ac + (255,), width=3); d.line([(44, 16), (20, 48)], fill=ac + (255,), width=3); d.ellipse([22, 22, 42, 42], outline=li + (255,), width=3)
        if style == 'rune_node': d.ellipse([27, 27, 37, 37], fill=(255, 255, 255, 255))
    if style == 'statue':
        d.rectangle([0, 0, 63, 63], outline=sh + (255,), width=2); d.line([(8, 20), (56, 20)], fill=sh + (255,), width=2); d.line([(8, 44), (56, 44)], fill=sh + (255,), width=2)
    if style == 'fate':
        d.rectangle([2, 2, 61, 61], outline=ac + (255,), width=3); d.polygon([(32, 8), (50, 32), (32, 56), (14, 32)], outline=li + (255,), width=3); d.ellipse([26, 26, 38, 38], fill=ac + (255,))
    if style == 'altar':
        d.rectangle([0, 0, 63, 63], outline=sh + (255,), width=3); d.ellipse([12, 12, 52, 52], outline=ac + (255,), width=3); d.ellipse([24, 24, 40, 40], outline=li + (255,), width=2)
    if style == 'barrel':
        a = np.asarray(to_rgba(tex_noise(S, S, 'rust', seed, 'plates')), np.uint8); img = Image.fromarray(a, 'RGBA'); d = ImageDraw.Draw(img)
        for y in (10, 32, 54): d.rectangle([0, y - 3, 63, y + 3], fill=(60, 40, 25, 255))
    if style == 'sigil':
        d.rectangle([0, 0, 63, 63], outline=sh + (255,), width=3); d.ellipse([10, 10, 54, 54], outline=li + (255,), width=3); d.ellipse([24, 24, 40, 40], fill=ac + (255,))
    if style == 'mark': d.ellipse([8, 8, 56, 56], outline=li + (255,), width=3); d.ellipse([22, 22, 42, 42], fill=(255, 255, 255, 255))
    if style == 'cache': d.rectangle([2, 2, 61, 61], outline=(40, 40, 44, 255), width=3); d.rectangle([20, 24, 44, 40], fill=(200, 160, 40, 255))
    if style == 'sign': d.rectangle([4, 14, 59, 44], fill=(60, 40, 70, 255), outline=sh + (255,), width=3); d.line([(12, 26), (52, 26)], fill=ac + (255,), width=2); d.line([(12, 34), (40, 34)], fill=ac + (255,), width=2)
    if style == 'candle': d.rectangle([22, 18, 42, 62], fill=(238, 238, 245, 255)); d.rectangle([29, 6, 34, 18], fill=(255, 220, 90, 255))
    return img
def paint_blocks(man):
    for i, b in enumerate(man['blocks']):
        save(block_tex(b['style'], b['pal'], 300 + i), A + '/textures/block/%s.png' % b['id'])
def paint_armor():
    for s, pal in (('pale', 'pale'), ('plague', 'green')):
        for L in (1, 2):
            a = tex_noise(256, 128, pal, 700 + L + len(s), 'plates'); img = to_rgba(a); d = ImageDraw.Draw(img); ba, sh, li, ac = [rgb(c) for c in PAL[pal]]
            for x in range(0, 256, 32): d.line([x, 0, x, 128], fill=sh + (255,), width=2)
            d.rectangle([0, 0, 255, 127], outline=sh + (255,), width=3); d.line([0, 64, 255, 64], fill=li + (255,), width=2)
            save(img, A + '/textures/models/armor/%s_layer_%d.png' % (s, L))
def paint_effects(man):
    for e in man['effects']:
        c = e['color']; col = ((c >> 16) & 255, (c >> 8) & 255, c & 255)
        im = Image.new('RGBA', (18, 18), (0, 0, 0, 0)); d = ImageDraw.Draw(im); d.ellipse([1, 1, 16, 16], fill=tuple(int(v * 0.5) for v in col) + (255,), outline=col + (255,)); d.ellipse([5, 5, 12, 12], fill=col + (255,)); d.point((7, 7), fill=(255, 255, 255, 255))
        save(im, A + '/textures/mob_effect/%s.png' % e['id'])
# ---------------------------------------------------------------- modelli / blockstates / lang
def write_models(man):
    for it in man['items']:
        p = A + '/models/item/%s.json' % it['id']
        if it['kind'] == 'egg': wj(p, {'parent': 'minecraft:item/template_spawn_egg'})
        else:
            hand = it['icon'] in ('sword', 'dagger', 'spear', 'scythe', 'scepter', 'staff', 'hammer', 'pickaxe', 'axe', 'shovel', 'hoe')
            wj(p, {'parent': 'minecraft:item/handheld' if hand else 'minecraft:item/generated', 'textures': {'layer0': 'horror_universe:item/' + it['id']}})
    for b in man['blocks']:
        m = {'parent': 'minecraft:block/cube_all', 'textures': {'all': 'horror_universe:block/' + b['id']}}
        if b['style'] in ('fog', 'cube', 'glitch'): m['render_type'] = 'minecraft:translucent'
        wj(A + '/models/block/%s.json' % b['id'], m); wj(A + '/blockstates/%s.json' % b['id'], {'variants': {'': {'model': 'horror_universe:block/' + b['id']}}})
        wj(A + '/models/item/%s.json' % b['id'], {'parent': 'horror_universe:block/' + b['id']})
def en_name(i): return i.replace('_', ' ').title()
LINES = {
 'say.custode.1':'Sei stato osservato a lungo.','say.custode.2':'Solo chi è degno può sapere.','say.custode.3':'Toccami, se ne hai il coraggio.','say.custode.4':"L'elettricità ricorda ogni peccato.",
 'say.custode.5':'Hai superato la prova… per ora.','say.custode.6':'Il rituale ti attende, se osi.','say.custode.7':'Il tuo risparmio non sarà dimenticato.','say.custode.8':'Il rituale è stato iniziato senza il mio permesso.',
 'say.corrotto.1':'Ero venuto solo per capire questo mondo.','say.corrotto.2':'Perché mi hai colpito?','say.corrotto.3':'Sento qualcosa di scuro dentro di me.','say.corrotto.4':'Non voglio farti del male… aiutami.','say.corrotto.5':'La luce brucia.','say.corrotto.6':'Grazie. Forse c\'è ancora speranza.','say.corrotto.7':'Le tue cose non ti appartengono più.',
 'say.e404.1':'404: amico non trovato.','say.e404.2':'Ricordi la skin? Io ricordo tutto.','say.e404.3':'Non è un bug. È una condanna.','say.e404.4':'Hanno licenziato un uomo. Hanno creato me.','say.e404.5':'Il sole diventerà verde.','say.e404.6':'Avete riso di lui. Ora piangerete.','say.e404.7':'Ho rubato solo ciò che mi spettava.','say.e404.8':'Hai quattro colpi… no, aspetta. Ne hai troppi.',
 'say.mago.1':'Dipendi troppo dalla tua spada.','say.mago.2':'La conoscenza è l\'unica arma.','say.mago.3':'Guarda con occhi diversi: nulla è come appare.','say.mago.4':'Una prova, un patto. Accetti?','say.mago.5':'Le rune non mentono.','say.mago.6':'Hai occhi buoni. Rispetto.',
 'say.steve.1':'Hai usato di nuovo lo stesso trucco.','say.steve.2':'Questa volta ero preparato.','say.steve.3':'Non basta avere una spada migliore.','say.steve.4':'Hai costruito bene. Vediamo se sai difenderlo.','say.steve.5':'Sei diventato più forte. Anch\'io.','say.steve.6':'Non sei l\'unico che impara.','say.steve.7':'Rispetto. Tregua?',
 'say.osservatore.1':'Non sono io che sono arrivato. Sei tu che sei entrato.','say.osservatore.2':'Sei tornato.','say.osservatore.3':'Ti ricordo.','say.osservatore.4':'Dormi. Ti guardo.','say.osservatore.5':'Hai trovato diamanti. Lo so.','say.osservatore.6':'Nel corridoio c\'era qualcuno.',
 'msg.contact':'Contatto %s su 3','msg.fate_spare':'Hai risparmiato il Custode.','msg.fate_kill':'Hai ucciso il Custode. Il suo sguardo non ti lascerà.','msg.choice':'Il Custode è in ginocchio. Scegli:','msg.choice_spare':'[Risparmia]','msg.choice_kill':'[Uccidi]',
 'msg.artifact_ok':'L\'artefatto vibra: l\'oscurità si ritrae.','msg.purified':'Gli oggetti corrotti sono stati purificati.','msg.corrupted':'Un tuo oggetto è stato corrotto: non puoi usarlo finché non lo purifichi.',
 'msg.soul':'Anima corrotta: %s%%','msg.permadeath':'La tua anima è stata assorbita. Resti nel vuoto finché qualcuno non esegue il rito di recupero.','msg.recovered':'Il rito di recupero ha riportato un\'anima indietro.',
 'msg.victory':'Prova superata.','msg.defeat':'La prova è fallita.','msg.pearl_hit':'Colpo valido con la Perla Rituale: %s su 10','msg.rune_found':'Una runa si è spenta: %s rimaste.','msg.no_weapon':'L\'arma non è abbastanza potente per ferirlo.',
 'msg.immune':'Qualcosa lo protegge: i colpi normali non lo scalfiscono.','msg.timer':'Tempo rimasto','msg.wrong_item':'Solo la spada di ferro conta in questa sfida.','msg.fake_join':'%s è entrato nel gioco',
 'msg.trust':'Fiducia: %s','msg.clone_ally':'Il clone abbassa la guardia. Ti aiuterà nello scontro finale.','msg.realm_off':'Le dimensioni sono disattivate nella configurazione.','msg.statue_placed':'Statua del Destino attiva: %s su 5',
 'msg.sigil_ok':'Sequenza corretta.','msg.sigil_bad':'Sequenza sbagliata.','msg.steal':'Qualcosa ti ha portato via un oggetto…','msg.cache_broken':'Deposito distrutto: ne restano %s.','msg.heart':'Il Cuore della Piaga si spegne. Entity 404 è più debole.',
 'msg.apocalypse':'Il sole diventa verde. Il mondo si spezza.','msg.post':'Non c\'è più nulla da difendere.','msg.e404_retreat':'Entity 404 si ritira lasciando una copia di sé.','msg.limb':'Hai perso l\'uso di un arto… per ora.','msg.mage_energy':'L\'energia del mago è esaurita!',
 'item.scroll_custode.desc':'Occhi bianchi, prove e rituali. Il Custode non vuole uccidere: vuole sapere se sei degno.','item.scroll_corrotto.desc':'Un viaggiatore curioso. Trattalo bene e potrebbe aiutarti; la rabbia lo trasforma.','item.scroll_e404.desc':'Una skin ha ereditato la rabbia del suo proprietario. Leggenda narrativa, non un fatto reale.',
 'item.scroll_mago.desc':'Rune, illusioni, un patto. Distruggi le fonti della magia e il mago è vulnerabile.','item.scroll_steve.desc':'Un sopravvissuto che impara. Distruggi i suoi depositi prima di affrontarlo.','item.scroll_osservatore.desc':'Non è mai arrivato: sei tu che sei entrato.',
 'item.white_symbol.desc':'Un simbolo che suggerisce prove successive.','item.eden_fruit.desc':'Protegge da: Elettrizzato, Corruzione, Sigillo Runico, Instabilità Gravitazionale, Presenza Interiore.','item.anti_dark_artifact.desc':'Usalo vicino al Corrotto o per purificare. Tienine almeno tre.',
 'item.purifying_salt.desc':'Purifica gli oggetti corrotti e neutralizzati.','item.ritual_pearl.desc':'Perla valida per il rito del Custode (10 colpi).','item.plague_blade.desc':'Arma di livello 3 contro Entity 404.','item.lord_blade.desc':'Arma di livello 6 contro Entity 404.',
 'item.reaper_scythe.desc':'La falce del Mietitore: indebolisce chi colpisce.','item.electric_scepter.desc':'Scarica una catena di fulmini. Uso con ricarica.','item.rune_staff.desc':'Lancia un dardo arcano. Inutilizzabile con il Sigillo Runico.','item.plague_vial.desc':'Contiene e rallenta la piaga in un raggio di 12 blocchi.',
 'item.soul_seal.desc':'Respinge le minacce generate all\'interno del giocatore.','item.key_realm.desc':'Usala su un Altare Rituale per aprire la Dimensione Verde.','item.key_vault.desc':'Usala su un Altare Rituale per aprire il Vuoto Pallido.','item.recovery_totem.desc':'Tienilo su un Altare Rituale: recupera le anime perdute.',
 'item.mage_pact.desc':'Un patto in cambio di una prova.','item.observer_lens.desc':'Usala per avviare la Prova dell\'Attenzione.','item.observer_eye.desc':'Ti guarda sempre.','item.plague_core.desc':'Ingrediente della Lama della Piaga.','item.lord_core.desc':'Ingrediente della Lama del Signore.','item.steve_token.desc':'Rispetto guadagnato.',
 'item.ancient_rune_1.desc':'Una delle cinque rune antiche.','item.ancient_rune_2.desc':'Una delle cinque rune antiche.','item.ancient_rune_3.desc':'Una delle cinque rune antiche.','item.ancient_rune_4.desc':'Una delle cinque rune antiche.','item.ancient_rune_5.desc':'Una delle cinque rune antiche.',
 'item.pale_spear.desc':'','item.corrupted':'Corrotto: inutilizzabile finché non purificato','item.neutralized':'Neutralizzato dal Corrotto: purificalo con il Sale',
 'item.plague.tt':'Arma di Entity 404','tab':'Minecraft Horror Universe',
}
def write_lang(man):
    it, en = {}, {}
    it['itemGroup.horror_universe'] = 'Minecraft Horror Universe'; en['itemGroup.horror_universe'] = 'Minecraft Horror Universe'
    for i in man['items']:
        it['item.horror_universe.' + i['id']] = i['it']; en['item.horror_universe.' + i['id']] = en_name(i['id'])
    for b in man['blocks']:
        it['block.horror_universe.' + b['id']] = b['it']; en['block.horror_universe.' + b['id']] = en_name(b['id'])
    for m in man['mobs']:
        it['entity.horror_universe.' + m['id']] = m['it']; en['entity.horror_universe.' + m['id']] = en_name(m['id'])
    for b in man['bosses']:
        it['entity.horror_universe.' + b['id']] = b['it']; en['entity.horror_universe.' + b['id']] = b['it']
    for e in man['effects']:
        it['effect.horror_universe.' + e['id']] = e['it']; en['effect.horror_universe.' + e['id']] = en_name(e['id'])
    for s in man['sounds']:
        it['subtitles.horror_universe.' + s] = 'Suono: ' + s.replace('_', ' '); en['subtitles.horror_universe.' + s] = 'Sound: ' + s.replace('_', ' ')
    for k, v in LINES.items():
        key = ('horror_universe.' + k) if not k.startswith('item.') else ('item.horror_universe.' + k[5:])
        it[key] = v; en[key] = v
    wj(A + '/lang/it_it.json', it); wj(A + '/lang/en_us.json', en)
# ---------------------------------------------------------------- suoni
SR = 32000
def T(d): return np.arange(int(SR * d)) / SR
def lpf(x, fc, o=2): b, a = butter(o, min(0.99, fc / (SR / 2))); return lfilter(b, a, x)
def hpf(x, fc, o=2): b, a = butter(o, min(0.99, fc / (SR / 2)), 'high'); return lfilter(b, a, x)
def bpf(x, lo, hi): b, a = butter(2, [lo / (SR / 2), min(0.99, hi / (SR / 2))], 'band'); return lfilter(b, a, x)
def fadeio(x, a=0.3, b=0.6):
    n = len(x); e = np.ones(n); na = int(a * SR); nb = int(b * SR)
    if na > 0: e[:na] = np.linspace(0, 1, na)
    if nb > 0: e[-nb:] = np.minimum(e[-nb:], np.linspace(1, 0, nb))
    return x * e
def nrm(x, p=0.8): return x / (np.max(np.abs(x)) + 1e-9) * p
def drone(r, d, fr, na=0.3, lf=0.15):
    t = T(d); x = sum(np.sin(2 * np.pi * f * (1 + r.uniform(-0.003, 0.003)) * t + r.uniform(0, 6)) * (0.6 + 0.4 * np.sin(2 * np.pi * lf * (1 + i * 0.3) * t + i)) for i, f in enumerate(fr))
    x = x / len(fr) + na * lpf(r.standard_normal(len(t)), 500) * (0.5 + 0.5 * np.sin(2 * np.pi * lf * 0.5 * t))
    return fadeio(nrm(x, 0.5), 2.0, 2.5)
def beat(r, d, bpm=70):
    t = T(d); x = np.zeros(len(t)); per = 60.0 / bpm
    for k in range(int(d / per)):
        for off, f, a in ((0, 52, 1.0), (0.27, 64, 0.7)):
            i0 = int((k * per + off) * SR); n = min(int(0.35 * SR), len(t) - i0)
            if n > 0: tt = np.arange(n) / SR; x[i0:i0 + n] += a * np.sin(2 * np.pi * f * tt) * np.exp(-tt * 14)
    return nrm(lpf(x, 180), 0.9)
def steps(r, d, n=8):
    t = T(d); x = np.zeros(len(t)); tm = 0.2
    for _ in range(n):
        i0 = int(tm * SR); m = int(0.25 * SR)
        if i0 + m < len(t): tt = np.arange(m) / SR; x[i0:i0 + m] += (np.sin(2 * np.pi * 70 * tt) + 0.5 * lpf(r.standard_normal(m), 900)) * np.exp(-tt * 18) * r.uniform(0.6, 1)
        tm += r.uniform(0.35, 0.6) * (1.2 if r.random() < 0.2 else 1)
    return nrm(x, 0.8)
def creak(r, d):
    t = T(d); f = 180 + 120 * np.sin(2 * np.pi * 0.6 * t) + 60 * t; ph = np.cumsum(2 * np.pi * f / SR); x = (np.mod(ph, 2 * np.pi) / np.pi - 1) * (0.6 + 0.4 * np.sin(2 * np.pi * 7 * t))
    return fadeio(nrm(bpf(x, 250, 1800), 0.7), 0.2, 0.5)
def whisper(r, d):
    t = T(d); n = bpf(r.standard_normal(len(t)), 1200, 4200); g = np.zeros(len(t)); tm = 0.1
    while tm < d - 0.3:
        L = r.uniform(0.12, 0.35); i0 = int(tm * SR); m = int(L * SR); g[i0:i0 + m] = np.hanning(len(g[i0:i0 + m])) * r.uniform(0.4, 1); tm += L + r.uniform(0.05, 0.2)
    return fadeio(nrm(n * g, 0.55), 0.2, 0.5)
def glitch(r, d):
    t = T(d); x = np.zeros(len(t)); tm = 0
    while tm < d - 0.1:
        L = r.uniform(0.02, 0.12); i0 = int(tm * SR); m = int(L * SR)
        seg = np.sign(np.sin(2 * np.pi * r.choice([220, 440, 880, 1760, 3000]) * np.arange(m) / SR)) if r.random() < 0.5 else r.standard_normal(m)
        seg = np.round(seg * 4) / 4; x[i0:i0 + m] += seg * r.uniform(0.3, 1) * (r.random() < 0.8); tm += L + r.uniform(0.0, 0.15)
    return nrm(x, 0.6)
def thunder(r, d):
    t = T(d); x = lpf(r.standard_normal(len(t)), 220) * np.exp(-t * 0.8) + 0.5 * hpf(r.standard_normal(len(t)), 1800) * np.exp(-t * 14)
    return nrm(x, 0.9)
def zap(r, d):
    t = T(d); x = hpf(r.standard_normal(len(t)), 2500) * np.exp(-t * 9) + np.sin(2 * np.pi * (4000 - 3000 * t / d) * t) * np.exp(-t * 7) * 0.5
    return nrm(x, 0.8)
def chime(r, d, f0=440):
    t = T(d); x = sum(np.sin(2 * np.pi * f0 * k * t) * np.exp(-t * (3 + i * 2)) / (i + 1) for i, k in enumerate((1, 2.76, 5.4, 8.9)))
    return nrm(x, 0.7)
def whoosh(r, d):
    t = T(d); n = r.standard_normal(len(t)); x = bpf(n, 300, 2500) * np.sin(np.pi * t / d) ** 2
    return nrm(x, 0.7)
def stinger(r, d):
    t = T(d); x = sum(np.sign(np.sin(2 * np.pi * f * t)) for f in (466, 493, 622, 659)) * np.exp(-t * 3) + hpf(r.standard_normal(len(t)), 1500) * np.exp(-t * 6)
    return nrm(lpf(x, 5000), 0.85)
def choir(r, d):
    t = T(d); x = sum((np.mod(2 * np.pi * f * t + 0.6 * np.sin(2 * np.pi * 5 * t), 2 * np.pi) / np.pi - 1) * 0.3 for f in (196, 247, 294, 392, 466))
    return fadeio(nrm(lpf(x, 1400), 0.6), d * 0.3, d * 0.4)
def growl(r, d):
    t = T(d); f = 70 + 15 * np.sin(2 * np.pi * 3 * t); ph = np.cumsum(2 * np.pi * f / SR); x = (np.mod(ph, 2 * np.pi) / np.pi - 1) * (0.6 + 0.4 * np.sign(np.sin(2 * np.pi * 28 * t))) + 0.3 * lpf(r.standard_normal(len(t)), 700)
    return fadeio(nrm(lpf(x, 900), 0.8), 0.1, 0.4)
def breath(r, d):
    t = T(d); x = bpf(r.standard_normal(len(t)), 300, 1500) * (0.5 + 0.5 * np.sin(2 * np.pi * 0.28 * t)) ** 2
    return fadeio(nrm(x, 0.6), 0.5, 0.8)
def grind(r, d):
    t = T(d); x = lpf(r.standard_normal(len(t)), 500) * (0.5 + 0.5 * np.sin(2 * np.pi * 5.5 * t + 3 * np.sin(2 * np.pi * 0.7 * t))) + 0.15 * np.sin(2 * np.pi * (900 + 250 * np.sin(2 * np.pi * 1.3 * t)) * t) * (np.sin(2 * np.pi * 2 * t) > 0.5)
    return fadeio(nrm(x, 0.7), 0.1, 0.3)
def cast(r, d):
    t = T(d); x = np.zeros(len(t))
    for k, f in enumerate((392, 494, 587, 784, 988)):
        i0 = int(k * 0.1 * SR); tt = t[:len(t) - i0]; x[i0:] += np.sin(2 * np.pi * f * tt) * np.exp(-tt * 5)
    x += 0.25 * hpf(r.standard_normal(len(t)), 4000) * np.exp(-t * 6)
    return nrm(x, 0.7)
def portal(r, d):
    t = T(d); x = sum(np.sin(2 * np.pi * (f + 400 * t / d) * t + 3 * np.sin(2 * np.pi * 4 * t)) for f in (110, 165, 220)) + 0.4 * bpf(r.standard_normal(len(t)), 500, 3000)
    return fadeio(nrm(x, 0.7), 0.2, d * 0.5)
def static(r, d):
    t = T(d); g = (np.sin(2 * np.pi * 6 * t) > -0.3).astype(float); return nrm(lpf(r.standard_normal(len(t)), 7000) * g, 0.5)
def bell(r, d):
    t = T(d); x = sum(np.sin(2 * np.pi * 196 * k * t) * np.exp(-t * (0.7 + 0.5 * i)) for i, k in enumerate((1, 2, 2.4, 3, 4.2, 5.4)))
    return nrm(x, 0.8)
def tentacle(r, d):
    t = T(d); x = bpf(r.standard_normal(len(t)), 150, 900) * np.exp(-t * 12) + np.sin(2 * np.pi * 55 * t) * np.exp(-t * 9)
    return nrm(x, 0.85)
def scream(r, d):
    t = T(d); f = 420 + 300 * np.sin(np.pi * t / d); ph = np.cumsum(2 * np.pi * f / SR); x = np.mod(ph, 2 * np.pi) / np.pi - 1
    return fadeio(nrm(lpf(bpf(x, 600, 2600), 1800), 0.4), 0.2, d * 0.6)
def laugh(r, d):
    t = T(d); x = np.zeros(len(t))
    for k in range(4):
        i0 = int((0.05 + k * 0.28) * SR); m = int(0.18 * SR); tt = np.arange(m) / SR; f = 330 - 40 * k; x[i0:i0 + m] += (np.mod(2 * np.pi * f * tt, 2 * np.pi) / np.pi - 1) * np.exp(-tt * 9)
    return nrm(lpf(x, 1500), 0.6)
def alarm(r, d):
    t = T(d); return nrm(np.sign(np.sin(2 * np.pi * np.where(np.sin(2 * np.pi * 2 * t) > 0, 740, 554) * t)) * 0.5, 0.45)
SOUND_RECIPES = {
 'ambient.pale': lambda r: drone(r, 30, (55, 82.4, 110, 165), 0.25), 'ambient.void': lambda r: drone(r, 30, (41.2, 61.7, 123.5), 0.4, 0.07),
 'ambient.plague': lambda r: drone(r, 30, (49, 73.4, 98, 146.8), 0.5, 0.2), 'ambient.arcane': lambda r: drone(r, 30, (110, 164.8, 220, 329.6), 0.15, 0.1),
 'ambient.steel': lambda r: drone(r, 30, (65.4, 98, 130.8), 0.35, 0.3), 'ambient.watch': lambda r: drone(r, 30, (36.7, 55, 73.4), 0.45, 0.05),
 'ambient.ritual': lambda r: choir(r, 30), 'ambient.dark': lambda r: drone(r, 30, (32.7, 49, 65.4, 98), 0.3, 0.12),
 'heartbeat': lambda r: beat(r, 8), 'steps_behind': lambda r: steps(r, 6), 'door_creak': lambda r: creak(r, 3.5), 'whisper_a': lambda r: whisper(r, 6), 'whisper_b': lambda r: whisper(r, 8),
 'glitch_a': lambda r: glitch(r, 3), 'glitch_b': lambda r: glitch(r, 5), 'thunder_far': lambda r: thunder(r, 7), 'zap': lambda r: zap(r, 1.2), 'chime': lambda r: chime(r, 3.5),
 'rune_hum': lambda r: drone(r, 6, (220, 330, 440), 0.05, 0.4), 'whoosh': lambda r: whoosh(r, 1.5), 'teleport': lambda r: portal(r, 1.4), 'stinger': lambda r: stinger(r, 2.2),
 'choir': lambda r: choir(r, 12), 'growl': lambda r: growl(r, 3), 'breath': lambda r: breath(r, 8), 'statue_grind': lambda r: grind(r, 4), 'cast': lambda r: cast(r, 1.6),
 'portal': lambda r: portal(r, 5), 'static': lambda r: static(r, 4), 'bell': lambda r: bell(r, 8), 'tentacle': lambda r: tentacle(r, 1.2), 'scream_far': lambda r: scream(r, 4),
 'mimic': lambda r: creak(r, 2.2), 'clone_laugh': lambda r: laugh(r, 1.5), 'alarm': lambda r: alarm(r, 3), 'swing_heavy': lambda r: whoosh(r, 1.0)}
MULTI = {'whisper_a', 'steps_behind', 'glitch_a', 'thunder_far', 'door_creak', 'teleport', 'heartbeat', 'static'}
def make_sounds():
    sd = A + '/sounds'; os.makedirs(sd, exist_ok=True); sj = {}; tmp = '/tmp/hu_snd.wav'; total = 0
    for sid in SOUNDS:
        names = []
        for v in ([1, 2] if sid in MULTI else [0]):
            r = np.random.default_rng(hash(sid) % 100000 + v); rr = random.Random(hash(sid) % 100000 + v)
            class R:  # wrapper per usare sia numpy sia random
                def __init__(s): s.n = r; s.p = rr
                def standard_normal(s, n): return s.n.standard_normal(n)
                def uniform(s, a, b): return s.p.uniform(a, b)
                def random(s): return s.p.random()
                def choice(s, l): return s.p.choice(l)
            x = SOUND_RECIPES[sid](R()); x = np.clip(x, -1, 1)
            with wave.open(tmp, 'wb') as w: w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((x * 32767).astype('<i2').tobytes())
            fn = sid.replace('.', '_') + ('_%d' % v if v else ''); out = '%s/%s.ogg' % (sd, fn)
            subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', tmp, '-c:a', 'libvorbis', '-q:a', '4', out], check=True); total += os.path.getsize(out)
            names.append({'name': 'horror_universe:' + fn, 'stream': True} if sid.startswith('ambient') or len(x) > SR * 8 else 'horror_universe:' + fn)
        sj[sid] = {'sounds': names, 'subtitle': 'subtitles.horror_universe.' + sid}
    wj(A + '/sounds.json', sj); return total
if __name__ == '__main__':
    man = build_manifest(); n = paint_all_mobs(); paint_items(man); paint_blocks(man); paint_armor(); paint_effects(man); write_models(man); write_lang(man)
    print('texture mob', n); sb = make_sounds(); print('audio bytes', sb)
