# Minecraft Horror Universe (NeoForge 1.21.1, Java 21)

Mod horror con sei entità intelligenti: **Custode dagli Occhi Bianchi, Corrotto / Dio dell'Oscurità, Entity 404, Uomo Magico, Steve il Giocatore Impossibile, Osservatore**.
Il progetto è un sorgente Gradle completo. **Non è stato compilato** da chi lo ha scritto (l'ambiente non aveva rete né Minecraft): al primo build possono comparire errori di API da correggere.

## Compilare da telefono con GitHub (consigliato)
1. Crea un repository su GitHub (anche privato).
2. Dal sito, **Add file → Create new file**, scrivi come nome `.github/workflows/build.yml` e incolla il contenuto di `docs/build.yml`.
3. **Add file → Upload files** e carica questo `.zip` così com'è (il workflow lo scompatta da solo). In alternativa carica i file del progetto nella radice.
4. Scheda **Actions** → apri l'ultima esecuzione → in fondo, **Artifacts → risultato-build**: dentro c'è il `.jar` da mettere in `mods/` (e `build.log`).
5. Se la build fallisce, apri la stessa pagina dell'esecuzione: nel riquadro **Summary** c'è già l'elenco degli errori di compilazione (file, riga, motivo). Basta uno screenshot o copiare quel riquadro: si correggono in pochi minuti.
6. Per aggiornare il progetto ricarica lo zip **con lo stesso nome** (così sostituisce il vecchio e parte una nuova build).

## Compilare sul PC
`gradle build` (Gradle 8.11+, JDK 21) → `build/libs/horror_universe-1.0.0.jar`. Richiede NeoForge 21.1.x.

## Dimensione
Il jar contiene circa 10 MB di risorse (texture HD dei mostri, suoni sintetizzati OGG, strutture, dati): resta tra 7 e 25 MB. `tools/` rigenera tutto (`python3 tools/gen_assets.py && python3 tools/gen_data.py`).

## Contenuti
- 6 boss a livelli (Custode 5, Corrotto 5, Entity 404: 7 + clone bonus + fase post-distruzione, Mago 5, Steve 5, Osservatore 3 prove), anche come presenze autonome (osservano, spariscono se guardate, reagiscono).
- 82 creature con abilità e debolezze diverse (tutte dal prompt + `barrier_pylon`, copie, illusioni...), ~70 oggetti, 30 blocchi, 13 effetti, 36 suoni, 9 strutture, 2 dimensioni, 4 biomi, minerale Pallido.
- Aggiunte mie: Bidone Arrugginito (loot e mimico), Nebbia Oscura, Blocco Illusorio, Sigilli, Statue del Destino, set Pallido e della Piaga (utensili, armature), Falce del Mietitore, Lancia, Pugnale Arcano, Martello, Fiala di Contenimento, Lente dell'Osservatore, Totem di Recupero.
- Comandi: `/horror status|summon <entità> [livello]|event <nome>|choice spare|kill|reset|recover|realm|restore`.

## AI e compatibilità con altre mod
- Stati (osserva, pedina, indaga, ostile, fugge, tregua, alleato), vista con campo visivo, udito (rumore di corsa/blocchi/combattimento), memoria limitata che si salva, adattamento allo stile del giocatore (mischia / distanza / costruttore), relazioni persistenti.
- Armi di altre mod: contano per attacco "da tooltip" (attributi). Tag dati: `horror_universe:valid_weapons`, `invalid_weapons`, `magic_items`, `steal_blacklist`, `custode_summons`, `assimilable` (include `#c:bosses`), `no_assimilate`, `ai_threats`, `ai_ignored`.
- API Java: `HorrorApi.setWeaponAttack(item, valore)`, eventi `HorrorApi.HitEvent` (cancellabile) e `HorrorApi.LevelEvent`.

## Cosa manca o è semplificato (onestà)
Cielo/sole/luna verdi (solo particelle), arene isolate del Mago, "mostri dentro il cibo", cassa speciale del lv6, zone protette della dimensione 404, interazioni tra entità solo parziali, biomi nuovi nell'Overworld (servirebbe TerraBlender). Testare il bilanciamento in gioco.
Vedi `docs/COERENZA_REGOLE.md` per le contraddizioni del prompt e come sono state risolte.
