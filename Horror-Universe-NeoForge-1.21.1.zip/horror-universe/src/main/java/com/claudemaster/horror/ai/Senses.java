package com.claudemaster.horror.ai;

import com.claudemaster.horror.Weapons;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import java.util.*;

/** Percezione legittima: vista (campo visivo + linea di vista) e udito (rumore del giocatore). Nessuna onniscienza. */
public final class Senses {
    private static final Map<UUID, long[]> BURST = new HashMap<>();
    public static void burst(Player p, double radius, int ticks) { BURST.put(p.getUUID(), new long[]{(long) radius, p.level().getGameTime() + ticks}); }
    public static double noise(Player p) {
        if (p.isSpectator()) return 0;
        double r = p.isCrouching() ? 2 : p.isSprinting() ? 16 : p.getDeltaMovement().horizontalDistanceSqr() > 0.0004 ? 8 : 1;
        if (p.isInWater()) r = Math.max(r, 10);
        long[] b = BURST.get(p.getUUID()); if (b != null && b[1] > p.level().getGameTime()) r = Math.max(r, b[0]);
        return r;
    }
    public static boolean hears(Mob m, Player p) { return noise(p) >= m.distanceTo(p); }
    public static boolean canSee(Mob m, Player p) {
        double d = m.distanceTo(p); double range = p.isCrouching() && p.level().getMaxLocalRawBrightness(p.blockPosition()) < 7 ? 6 : 40;
        if (d > range || !m.hasLineOfSight(p)) return false;
        Vec3 look = m.getViewVector(1f), to = p.getEyePosition().subtract(m.getEyePosition()).normalize();
        return look.dot(to) > 0.2;
    }
    /** Il giocatore sta guardando l'entità? */
    public static boolean lookedAt(Entity e, Player p) {
        Vec3 to = e.getEyePosition().subtract(p.getEyePosition()); double d = to.length(); if (d < 1e-3) return true;
        return p.getViewVector(1f).dot(to.scale(1 / d)) > 0.93 && p.hasLineOfSight(e);
    }
    public static ServerPlayer nearestPlayer(ServerLevel l, Entity e, double r) {
        Player p = l.getNearestPlayer(e.getX(), e.getY(), e.getZ(), r, x -> !x.isSpectator() && x.isAlive());
        return p instanceof ServerPlayer sp ? sp : null;
    }
    public static double threat(Player p) { return p.getHealth() + p.getArmorValue() * 1.5 + Weapons.attack(p.getMainHandItem()) * 2; }
    private Senses() {}
}
