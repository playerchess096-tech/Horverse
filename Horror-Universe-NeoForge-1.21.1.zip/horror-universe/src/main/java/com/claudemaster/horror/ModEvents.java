package com.claudemaster.horror;

import com.claudemaster.horror.entity.*;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;

@EventBusSubscriber(modid = HorrorMod.MODID, bus = EventBusSubscriber.Bus.MOD)
public final class ModEvents {
    @SuppressWarnings("unchecked")
    @SubscribeEvent public static void attributes(EntityAttributeCreationEvent e) {
        for (Content.MobSpec m : Content.MOBS.values())
            e.put((EntityType<? extends net.minecraft.world.entity.LivingEntity>) Reg.type(m.id()), Monster.createMonsterAttributes()
                    .add(Attributes.MAX_HEALTH, m.hp()).add(Attributes.MOVEMENT_SPEED, m.spd()).add(Attributes.ATTACK_DAMAGE, Math.max(0.1, m.dmg()))
                    .add(Attributes.FOLLOW_RANGE, 40.0).add(Attributes.KNOCKBACK_RESISTANCE, m.hp() > 150 ? 0.7 : 0.0).build());
        for (String id : Content.BOSSES.keySet())
            e.put((EntityType<? extends net.minecraft.world.entity.LivingEntity>) Reg.type(id), Monster.createMonsterAttributes()
                    .add(Attributes.MAX_HEALTH, 300.0).add(Attributes.MOVEMENT_SPEED, 0.3).add(Attributes.ATTACK_DAMAGE, 9.0)
                    .add(Attributes.FOLLOW_RANGE, 64.0).add(Attributes.KNOCKBACK_RESISTANCE, 1.0).build());
    }
    @SuppressWarnings({"unchecked", "rawtypes"})
    @SubscribeEvent public static void spawns(RegisterSpawnPlacementsEvent e) {
        for (Content.MobSpec m : Content.MOBS.values()) {
            final boolean hostile = !m.owner().equals("neutral");
            e.register((EntityType) Reg.type(m.id()), SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                    (SpawnPlacements.SpawnPredicate) (t, lvl, reason, pos, rnd) -> hostile
                            ? Monster.checkMonsterSpawnRules((EntityType<? extends Monster>) t, (ServerLevelAccessor) lvl, (MobSpawnType) reason, (BlockPos) pos, (RandomSource) rnd)
                            : Mob.checkMobSpawnRules((EntityType<? extends Mob>) t, (ServerLevelAccessor) lvl, (MobSpawnType) reason, (BlockPos) pos, (RandomSource) rnd),
                    RegisterSpawnPlacementsEvent.Operation.OR);
        }
    }
    private ModEvents() {}
}
