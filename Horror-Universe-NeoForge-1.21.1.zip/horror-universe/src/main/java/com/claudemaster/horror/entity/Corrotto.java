package com.claudemaster.horror.entity;

import com.claudemaster.horror.*;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.BossEvent;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.*;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import java.util.*;

/** Il Corrotto / Dio dell'Oscurità: 1 Viaggiatore, 2 Oscurità Crescente, 3 Corruzione, 4 Corrotto Indebolito, 5 Dio dell'Oscurità. */
public class Corrotto extends BossMob {
    private int weakenedUntil, artifactUses, finalPhase, finalUntil;
    public Corrotto(EntityType<? extends Corrotto> t, Level l) { super(t, l, Ent.CORROTTO); }
    @Override public String key() { return "corrotto"; }
    @Override protected boolean noMelee() { return bossLevel <= 2; }
    private boolean inWindow() { int c = fightTicks % 600; return c >= 420 && c < 560; }
    @Override protected Weapons.Rule rule() {   // L1-L2: "non direttamente attaccabile": solo le armi di Entity 404 (vulnerabilità specifica, vedi COERENZA_REGOLE.md)
        double thr = Config.ATTACK_THRESHOLD.get();
        return switch (bossLevel) {
            case 1, 2 -> Weapons.Rule.special(2, 1);
            case 3 -> tickCount < weakenedUntil ? Weapons.Rule.hitsThr(thr, 3, 1) : Weapons.Rule.immune();
            case 4 -> inWindow() ? Weapons.Rule.hitsThr(thr, 1, 1) : Weapons.Rule.immune();
            default -> finalPhase > 0 ? Weapons.Rule.hitsThr(thr, 4, 2) : Weapons.Rule.immune();
        };
    }
    @Override protected float progress() { return bossLevel <= 2 ? fightTicks / (bossLevel == 1 ? 2400f : 3600f) : bossLevel == 5 ? 1f - Soul.get(fightPlayerOrNull()) / 100f : super.progress(); }
    private ServerPlayer fightPlayerOrNull() { return level() instanceof ServerLevel l ? fightPlayer(l) : null; }
    @Override protected void begin(ServerLevel l, ServerPlayer p) {
        weakenedUntil = artifactUses = finalPhase = finalUntil = 0; clearGear();
        setHp(new double[]{0, 200, 240, 320, 260, 500}[Math.min(bossLevel, 5)]);
        barStyle(bossLevel <= 2 ? BossEvent.BossBarColor.PURPLE : bossLevel == 5 ? BossEvent.BossBarColor.RED : BossEvent.BossBarColor.PINK, bossLevel <= 2 ? BossEvent.BossBarOverlay.NOTCHED_20 : BossEvent.BossBarOverlay.PROGRESS);
        say(p, bossLevel == 1 ? 1 : bossLevel == 2 ? 3 : bossLevel == 5 ? 5 : 4);
        if (bossLevel == 3) for (int i = 0; i < 3; i++) { Vec3 s = Fx.spotAround(l, p.position(), 8, 18); if (s != null) TempBlocks.set(l, BlockPos.containing(s), Reg.block("corrupted_sign").defaultBlockState(), 48000); }
    }
    @Override protected void script(ServerLevel l, ServerPlayer p) {
        switch (bossLevel) { case 1, 2 -> l12(l, p); case 3 -> l3(l, p); case 4 -> l4(l, p); default -> l5(l, p); }
    }
    private void l12(ServerLevel l, ServerPlayer p) {
        int dur = bossLevel == 1 ? 2400 : 3600;
        if (at(200, 40)) summon(l, bossLevel == 1 || l.random.nextBoolean() ? "living_statue" : "statue_guardian", bossLevel, 16, p);
        if (at(300, 0)) p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 80, 0));
        if (bossLevel == 2) {
            if (every(100)) darkBlocks(l, p, 8, "dark_block", 100);
            if (at(260, 0)) { Vec3 e = Fx.spotAround(l, p.position(), 14, 20); if (e != null) { Fx.particles(l, ParticleTypes.SQUID_INK, e.add(0, 1.6, 0), 6, 0.15); Fx.soundTo(p, "whisper_a", 0.6f, 0.8f, e); } }
            if (at(400, 0)) for (BlockPos bp : BlockPos.betweenClosed(p.blockPosition().offset(-6, -2, -6), p.blockPosition().offset(6, 4, 6))) if (l.getBlockState(bp).is(Blocks.TORCH) || l.getBlockState(bp).is(Blocks.WALL_TORCH)) TempBlocks.set(l, bp, Blocks.AIR.defaultBlockState(), 160, true);
            if (fightTicks == 1500) spawnAtLocation(new ItemStack(Reg.item("dark_shard")));
        }
        if (every(80) && distanceTo(p) < 12) tpNear(l, p, 14, 20);
        if (fightTicks >= dur) endFight(l, p, true);
    }
    private void l3(ServerLevel l, ServerPlayer p) {
        if (at(400, 100)) corruptItems(p, 2);
        if (at(300, 60)) summon(l, l.random.nextBoolean() ? "darkness_herald" : "dark_knight", 1, 12, p);
        if (every(160)) darkBlocks(l, p, 4, "dark_block", 80);
        if (every(150) && tickCount >= weakenedUntil) tpNear(l, p, 8, 14);
        if (fightTicks > 7200) endFight(l, p, false);
    }
    private void l4(ServerLevel l, ServerPlayer p) {
        int c = fightTicks % 600;
        if (c == 400) { Fx.sound(l, position(), "bell", 1f, 1.2f); Fx.dust(l, 0xb020ff, position().add(0, 1, 0), 40, 0.8); }
        if (c >= 420 && c < 560 && every(10)) Fx.dust(l, 0xffffff, position().add(0, 1, 0), 10, 0.6);
        if (at(400, 200) && Config.STEAL.get()) steal(p);
        if (every(70)) orb(l, p, 5f, 0xb020ff, "darkness");
        if (at(500, 100)) summon(l, "incomplete_clone", 2, 9, p);
        if (every(260) && !inWindow()) tpNear(l, p, 7, 13);
        if (fightTicks > 6000) { Fx.msg(p, "msg.defeat"); endFight(l, p, false); }
    }
    private void l5(ServerLevel l, ServerPlayer p) {
        if (finalPhase == 1 && fightTicks > finalUntil) { finalPhase = 0; artifactUses = 0; heal(getMaxHealth() * 0.2f); }
        boolean purify = (fightTicks / 400) % 2 == 1;
        if (every(20) && distanceTo(p) < 14) Soul.add(p, purify ? 2 : 1);
        if (every(70)) orb(l, p, 6f, 0xb020ff, "corruption");
        if (!purify && at(200, 60)) summon(l, "statue_guardian", 1, 14, p);
        if (every(100)) darkBlocks(l, p, 5, "dark_block", 100);
        if (at(700, 350)) neutralize(p);
        if (at(600, 300)) heal(getMaxHealth() * 0.06f);
        if (every(200) && finalPhase == 0) tpNear(l, p, 8, 14);
        if (at(500, 0)) Fx.fx(p, "corruption", 200, Soul.get(p) / 40);
        if (fightTicks > 14000) endFight(l, p, false);
    }
    /** L'Artefatto Anti-Oscurità: L3 apre una finestra di vulnerabilità, L5 riduce l'anima corrotta (due usi per la fase finale). */
    public boolean artifact(ServerPlayer p) {
        if (!fighting) return false;
        if (bossLevel == 3) { weakenedUntil = tickCount + 260; artifactUses++; Fx.msg(p, "msg.artifact_ok"); Fx.particles((ServerLevel) level(), ParticleTypes.END_ROD, position().add(0, 1, 0), 40, 0.6); return true; }
        if (bossLevel == 5) { Soul.add(p, -25); artifactUses++; Fx.msg(p, "msg.artifact_ok"); if (artifactUses >= 2 && finalPhase == 0) { finalPhase = 1; finalUntil = fightTicks + 700; say(p, 6); } return true; }
        return false;
    }
    public static boolean useArtifact(ServerPlayer p) {
        boolean used = false;
        for (Corrotto c : p.serverLevel().getEntitiesOfClass(Corrotto.class, p.getBoundingBox().inflate(16), x -> x.fighting)) if (c.artifact(p)) { used = true; break; }
        return purify(p) > 0 || used;
    }
    public static int purify(ServerPlayer p) {
        int n = 0;
        for (int i = 0; i < p.getInventory().getContainerSize(); i++) { ItemStack s = p.getInventory().getItem(i); if (Marks.unusable(s)) { Marks.set(s, "hu_corrupted", false); Marks.set(s, "hu_neutralized", false); Marks.clearLore(s); n++; } }
        if (n > 0) { Fx.msg(p, "msg.purified"); p.removeEffect(Reg.fx("corruption")); }
        return n;
    }
    private void corruptItems(ServerPlayer p, int n) {
        List<Integer> idx = new ArrayList<>();
        for (int i = 0; i < 36; i++) { ItemStack s = p.getInventory().getItem(i); if (!s.isEmpty() && !Marks.unusable(s) && !s.has(DataComponents.FOOD) && s.getMaxStackSize() == 1 && !s.is(Reg.item("anti_dark_artifact")) && !s.is(Reg.item("recovery_totem")) && !s.is(Reg.item("soul_seal"))) idx.add(i); }
        Collections.shuffle(idx); for (int k = 0; k < Math.min(n, idx.size()); k++) { ItemStack s = p.getInventory().getItem(idx.get(k)); Marks.set(s, "hu_corrupted", true); Marks.lore(s, "item.horror_universe.corrupted"); }
        if (!idx.isEmpty()) Fx.msg(p, "msg.corrupted");
    }
    private void neutralize(ServerPlayer p) {
        for (int i = 0; i < p.getInventory().getContainerSize(); i++) { ItemStack s = p.getInventory().getItem(i); if (s.is(Reg.item("anti_dark_artifact")) && !Marks.has(s, "hu_neutralized")) { Marks.set(s, "hu_neutralized", true); Marks.lore(s, "item.horror_universe.neutralized"); Fx.msg(p, "msg.corrupted"); return; } }
    }
    private void steal(ServerPlayer p) {
        if (!stolen.isEmpty()) return; List<Integer> idx = new ArrayList<>();
        for (int i = 0; i < 9; i++) if (!p.getInventory().getItem(i).isEmpty()) idx.add(i);
        if (idx.isEmpty()) return; int i = idx.get(random.nextInt(idx.size())); ItemStack s = p.getInventory().getItem(i);
        stolen.add(s.copy()); p.getInventory().setItem(i, ItemStack.EMPTY); equip(EquipmentSlot.MAINHAND, s.copy()); say(p, 7); Fx.msg(p, "msg.steal");
    }
    @Override protected void cleanup(ServerLevel l, ServerPlayer p) {
        equip(EquipmentSlot.MAINHAND, ItemStack.EMPTY); killMinions(l); TempBlocks.restoreNear(l, blockPosition(), 60, s -> s.is(Reg.block("dark_block")));
    }
    @Override protected void reward(ServerLevel l, ServerPlayer p) {
        switch (bossLevel) {
            case 1 -> Fx.give(p, "dark_shard", 2);
            case 2 -> Fx.give(p, "soul_fragment", 1);
            case 3 -> { Fx.give(p, "purifying_salt", 3); Fx.give(p, "scroll_corrotto", 1); }
            case 4 -> Fx.give(p, "soul_fragment", 2);
            default -> { Fx.give(p, "void_essence", 1); Fx.give(p, "recovery_totem", 1); }
        }
    }
}
