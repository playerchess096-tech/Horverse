package com.claudemaster.horror.ai;

import com.claudemaster.horror.*;
import com.claudemaster.horror.entity.*;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.TagKey;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/** Libreria di abilità riutilizzabili: ogni mostro ne combina alcune (colonna "abilita" del manifest). I nomi senza oggetto (guardian, stalk, ecc.) sono tratti letti dal Brain. */
public final class Skills {
    static final TagKey<Item> STEAL_BLACKLIST = TagKey.create(Registries.ITEM, HorrorMod.id("steal_blacklist"));
    private static boolean minion(HorrorMob m) { for (String t : m.getTags()) if (t.startsWith("hu_of_")) return true; return false; }
    private static int color(HorrorMob m) { Ent e = m.family(); return e == null ? 0xFFFFFF : switch (e) { case CUSTODE -> 0xFFFFFF; case CORROTTO -> 0xB020FF; case E404 -> 0x40FF60; case MAGO -> 0xD070FF; case STEVE -> 0xFFCC40; default -> 0xAAAAAA; }; }
    private static Ability onHit(String eff) {
        return new Ability() {
            public void tick(HorrorMob m, ServerLevel l) {}
            @Override public void hit(HorrorMob m, LivingEntity t) {
                switch (eff) {
                    case "slow" -> t.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 1));
                    case "weakness" -> t.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 0));
                    case "darkness" -> t.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 100, 0));
                    case "wither" -> t.addEffect(new MobEffectInstance(MobEffects.WITHER, 80, 0));
                    case "fire" -> t.igniteForSeconds(4f);
                    case "gravity" -> Fx.fx(t, "gravity_flux", 100, 0);
                    default -> Fx.fx(t, eff, 120, 0);
                }
            }
        };
    }
    private static Ability summoner(String mode) {
        return (m, l) -> {
            if (minion(m) || m.tickCount % 400 != 100 || !(m instanceof SpecMob sm) || !(m.getTarget() instanceof ServerPlayer p) || m.distanceTo(p) > 24) return;
            String tag = "hu_of_" + m.getUUID(); int can = Math.min(2, Config.MAX_MINIONS.get() - Fx.countTag(l, m.position(), 40, tag)); if (can <= 0) return;
            String id = mode.equals("summon") ? Content.minionOf(sm.spec().owner(), sm.key(), ThreadLocalRandom.current()) : sm.key(); if (id == null) return;
            Fx.spawnNear(l, Reg.type(id), m.position(), 7, p, can, tag); Fx.sound(l, m.position(), "whoosh", 0.7f, 0.7f);
        };
    }
    public static Ability create(String n) {
        if (n.startsWith("hit_")) return onHit(n.substring(4));
        return switch (n) {
            case "summon", "summon_pack" -> summoner(n);
            case "dash" -> (m, l) -> { LivingEntity t = m.getTarget(); if (t != null && m.tickCount % 80 == 0 && m.onGround()) { double d = m.distanceTo(t); if (d > 4 && d < 12) { Vec3 v = t.position().subtract(m.position()).normalize(); m.setDeltaMovement(v.x * 0.9, 0.25, v.z * 0.9); Fx.sound(l, m.position(), "whoosh", 0.5f, 1.2f); } } };
            case "lightning" -> (m, l) -> { if (m.getTarget() instanceof ServerPlayer p && m.tickCount % 120 == 60 && m.distanceTo(p) < 18) { Vec3 at = p.position(); Fx.particles(l, ParticleTypes.ELECTRIC_SPARK, at.add(0, 0.2, 0), 25, 1.0); m.later(20, () -> Fx.lightning(l, at, 5f, 2.0, "electrified")); } };
            case "armor" -> (m, l) -> {
                if (m.tickCount != 3) return; double hp = m.getMaxHealth();
                Item[] a = hp > 100 ? new Item[]{Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE, Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS} : hp > 55 ? new Item[]{Items.IRON_HELMET, Items.IRON_CHESTPLATE, Items.IRON_LEGGINGS, Items.IRON_BOOTS} : new Item[]{Items.CHAINMAIL_HELMET, Items.CHAINMAIL_CHESTPLATE, Items.CHAINMAIL_LEGGINGS, Items.CHAINMAIL_BOOTS};
                EquipmentSlot[] s = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
                for (int i = 0; i < 4; i++) { m.setItemSlot(s[i], new ItemStack(a[i])); m.setDropChance(s[i], 0f); }
                m.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(hp > 100 ? Items.DIAMOND_SWORD : Items.IRON_SWORD)); m.setDropChance(EquipmentSlot.MAINHAND, 0f);
            };
            case "blink" -> (m, l) -> { LivingEntity t = m.getTarget(); if (t != null && m.tickCount % 100 == 40 && m.distanceTo(t) > 5) { Vec3 s = Fx.spotAround(l, t.position(), 2, 5); if (s != null) { Fx.particles(l, ParticleTypes.PORTAL, m.position().add(0, 1, 0), 20, 0.4); m.moveTo(s.x, s.y, s.z); Fx.sound(l, s, "teleport", 0.5f, 1.3f); } } };
            case "gaze" -> (m, l) -> { ServerPlayer p = Senses.nearestPlayer(l, m, 24); if (p == null) return; if (Senses.lookedAt(m, p)) { if (++m.mem.gaze > 40) { m.mem.gaze = 0; Fx.fx(p, "watched", 140, 0); Fx.soundTo(p, "breath", 0.6f, 0.8f, m.position()); } } else m.mem.gaze = 0; };
            case "echo" -> (m, l) -> { ServerPlayer p = Senses.nearestPlayer(l, m, 24); if (p == null) return; boolean up = p.getDeltaMovement().y > 0.3 && !p.onGround(); if (up && m.mem.wasOnGround && m.onGround()) m.getJumpControl().jump(); m.mem.wasOnGround = !up; };
            case "mimic_sound" -> (m, l) -> { ServerPlayer p = Senses.nearestPlayer(l, m, 24); if (p == null || m.tickCount % 200 != 90 || l.random.nextInt(3) != 0) return; SoundEvent[] s = {SoundEvents.ZOMBIE_AMBIENT, SoundEvents.SKELETON_AMBIENT, SoundEvents.CREEPER_PRIMED, SoundEvents.SPIDER_AMBIENT}; Fx.vsoundTo(p, s[l.random.nextInt(s.length)], 0.8f, 0.7f + l.random.nextFloat() * 0.5f, p.position().subtract(p.getLookAngle().scale(5))); };
            case "vanish" -> (m, l) -> { ServerPlayer p = Senses.nearestPlayer(l, m, 40); if (p == null) return; if (m.distanceTo(p) > 3 && Senses.lookedAt(m, p)) { if (++m.mem.extra > 30) { Fx.particles(l, ParticleTypes.LARGE_SMOKE, m.position().add(0, 1, 0), 20, 0.4); m.discard(); } } else m.mem.extra = Math.max(0, m.mem.extra - 1); };
            case "heal_pulse" -> (m, l) -> { if (m.tickCount % 100 != 0) return; for (HorrorMob x : l.getEntitiesOfClass(HorrorMob.class, m.getBoundingBox().inflate(8), y -> y != m && y.family() == m.family())) { x.heal(6f); Fx.particles(l, ParticleTypes.HEART, x.position().add(0, 1.5, 0), 3, 0.3); } };
            case "regen_dark" -> (m, l) -> { if (m.tickCount % 40 == 0 && l.getMaxLocalRawBrightness(m.blockPosition()) < 7) m.heal(1.5f); };
            case "leap" -> (m, l) -> { LivingEntity t = m.getTarget(); if (t != null && m.tickCount % 90 == 30 && m.onGround()) { double d = m.distanceTo(t); if (d > 3 && d < 9) { Vec3 v = t.position().subtract(m.position()).normalize(); m.setDeltaMovement(v.x * 0.8, 0.5, v.z * 0.8); } } };
            case "soul_leech" -> (m, l) -> { ServerPlayer p = Senses.nearestPlayer(l, m, 5); if (p != null && m.tickCount % 40 == 0) { Soul.add(p, 1); m.heal(2f); Fx.dust(l, 0x401060, p.position().add(0, 1, 0), 8, 0.3); } };
            case "mirror" -> (m, l) -> { LivingEntity t = m.getTarget(); if (t == null || m.tickCount % 100 != 0) return; for (EquipmentSlot s : new EquipmentSlot[]{EquipmentSlot.MAINHAND, EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) { m.setItemSlot(s, t.getItemBySlot(s).copy()); m.setDropChance(s, 0f); } };
            case "snuff" -> (m, l) -> {
                if (m.tickCount % 60 != 0) return; int n2 = 0;
                for (BlockPos p : BlockPos.betweenClosed(m.blockPosition().offset(-8, -3, -8), m.blockPosition().offset(8, 5, 8))) {
                    BlockState s = l.getBlockState(p);
                    if ((s.is(Blocks.TORCH) || s.is(Blocks.WALL_TORCH) || s.is(Blocks.SOUL_TORCH) || s.is(Blocks.SOUL_WALL_TORCH) || s.is(Blocks.LANTERN)) && TempBlocks.set(l, p, Blocks.AIR.defaultBlockState(), 200, true) && ++n2 >= 4) break;
                }
            };
            case "bolt" -> (m, l) -> { if (m.getTarget() instanceof ServerPlayer p && m.tickCount % 70 == 20 && m.distanceTo(p) < 22 && m.hasLineOfSight(p)) { Orbs.fire(l, m, m.getEyePosition(), p.getEyePosition(), 0.9f, (float) Math.max(2, m.getAttributeValue(Attributes.ATTACK_DAMAGE) * 0.6), color(m), null); Fx.sound(l, m.position(), "cast", 0.7f, 1f); } };
            case "contaminate" -> new Ability() { public void tick(HorrorMob m, ServerLevel l) {} @Override public void death(HorrorMob m, ServerLevel l) { AreaEffectCloud c = new AreaEffectCloud(l, m.getX(), m.getY(), m.getZ()); c.setRadius(3f); c.setDuration(160); c.addEffect(new MobEffectInstance(Reg.fx("plague"), 100, 0)); l.addFreshEntity(c); } };
            case "pull" -> (m, l) -> { if (m.getTarget() instanceof ServerPlayer p && m.tickCount % 120 == 50 && m.distanceTo(p) < 11 && m.hasLineOfSight(p)) { Vec3 v = m.position().subtract(p.position()).normalize().scale(0.9); p.setDeltaMovement(v.x, 0.3, v.z); p.hurtMarked = true; Fx.sound(l, m.position(), "tentacle", 0.8f, 1f); } };
            case "beam" -> (m, l) -> {
                if (m.getTarget() instanceof ServerPlayer p && m.tickCount % 100 == 40 && m.distanceTo(p) < 26 && m.hasLineOfSight(p)) {
                    Vec3 a = m.getEyePosition(); Fx.dust(l, 0x40ff60, a.lerp(p.getEyePosition(), 0.3), 15, 0.2);
                    m.later(20, () -> { if (!m.isAlive()) return; Rays.beam(l, a, p.getEyePosition(), 0x40ff60); p.hurt(l.damageSources().magic(), 8f); Fx.fx(p, "green_hearts", 200, 0); Fx.sound(l, m.position(), "zap", 0.8f, 0.7f); });
                }
            };
            case "meteor" -> (m, l) -> {
                if (m.getTarget() instanceof ServerPlayer p && m.tickCount % 220 == 100 && m.distanceTo(p) < 30) {
                    Vec3 at = p.position(); for (int i = 0; i < 12; i++) Fx.dust(l, 0xe09040, at.add(Math.cos(i * 0.52) * 3, 0.2, Math.sin(i * 0.52) * 3), 2, 0.05);
                    m.later(40, () -> { Fx.particles(l, ParticleTypes.EXPLOSION, at, 3, 1.0); Fx.sound(l, at, "thunder_far", 1f, 1.4f); Fx.hitPlayers(l, at, 3.2, 10f, "plague"); });
                }
            };
            case "retreat_phase" -> new Ability() {
                public void tick(HorrorMob m, ServerLevel l) {}
                @Override public float hurt(HorrorMob m, DamageSource s, float a) {
                    float f = (m.getHealth() - a) / m.getMaxHealth();
                    if (((m.mem.phase == 0 && f < 0.5f) || (m.mem.phase == 1 && f < 0.25f)) && m.level() instanceof ServerLevel l) {
                        m.mem.phase++; ServerPlayer p = Senses.nearestPlayer(l, m, 40); Vec3 sp = Fx.spotAround(l, m.position(), 14, 20); if (sp != null) m.moveTo(sp.x, sp.y, sp.z); m.heal(m.getMaxHealth() * 0.1f);
                        if (p != null && m instanceof SpecMob sm) { String id = Content.minionOf(sm.spec().owner(), sm.key(), ThreadLocalRandom.current()); if (id != null) Fx.spawnNear(l, Reg.type(id), m.position(), 6, p, 2, "hu_of_" + m.getUUID()); }
                    }
                    return a;
                }
            };
            case "drain_hearts" -> new Ability() { public void tick(HorrorMob m, ServerLevel l) {} @Override public void hit(HorrorMob m, LivingEntity t) { m.heal(4f); Fx.fx(t, "green_hearts", 200, 0); } };
            case "steal" -> new Ability() {
                public void tick(HorrorMob m, ServerLevel l) {}
                @Override public void hit(HorrorMob m, LivingEntity t) {
                    if (!Config.STEAL.get() || !(t instanceof ServerPlayer p) || !m.stolen.isEmpty()) return;
                    List<Integer> slots = new ArrayList<>(); for (int i = 0; i < 36; i++) { ItemStack s = p.getInventory().getItem(i); if (!s.isEmpty() && !s.is(STEAL_BLACKLIST)) slots.add(i); }
                    if (slots.isEmpty()) return; int i = slots.get(m.getRandom().nextInt(slots.size())); m.stolen.add(p.getInventory().getItem(i).copy()); p.getInventory().setItem(i, ItemStack.EMPTY);
                    Fx.msg(p, "msg.steal"); m.later(2400, m::returnStolen); m.brain.mood = Mood.FLEEING;
                }
            };
            case "shield_aura" -> (m, l) -> { if (m.tickCount % 40 == 0) for (HorrorMob x : l.getEntitiesOfClass(HorrorMob.class, m.getBoundingBox().inflate(8), y -> y != m && y.family() == m.family())) x.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 60, 1)); };
            case "illusion_split" -> new Ability() {
                public void tick(HorrorMob m, ServerLevel l) {}
                @Override public float hurt(HorrorMob m, DamageSource s, float a) {
                    if (m.level() instanceof ServerLevel l && m.tickCount - m.mem.extra > 100 && Fx.countTag(l, m.position(), 40, "hu_of_" + m.getUUID()) < 3) {
                        m.mem.extra = m.tickCount; ServerPlayer p = Senses.nearestPlayer(l, m, 30); Fx.spawnNear(l, Reg.type("illusion_double"), m.position(), 4, p, 1, "hu_of_" + m.getUUID());
                        Vec3 sp = Fx.spotAround(l, m.position(), 4, 8); if (sp != null) m.moveTo(sp.x, sp.y, sp.z);
                    }
                    return a;
                }
            };
            case "webs" -> (m, l) -> { if (m.getTarget() instanceof ServerPlayer p && m.tickCount % 120 == 60 && m.distanceTo(p) < 10) TempBlocks.set(l, p.blockPosition(), Blocks.COBWEB.defaultBlockState(), 100); };
            case "clue_drop" -> (m, l) -> {
                if (m.tickCount % 800 != 400 || !(m instanceof SpecMob sm)) return;
                String it = switch (sm.spec().owner()) { case "custode" -> "white_symbol"; case "corrotto" -> "dark_shard"; case "e404" -> "green_fragment"; case "mago" -> "rune_shard"; case "steve" -> "steve_token"; default -> "white_symbol"; };
                m.spawnAtLocation(new ItemStack(Reg.item(it)));
            };
            case "gravity" -> (m, l) -> { if (m.tickCount % 20 == 0) for (ServerPlayer p : l.getEntitiesOfClass(ServerPlayer.class, m.getBoundingBox().inflate(7))) Fx.fx(p, "gravity_flux", 60, 0); };
            case "shield_use" -> new Ability() {
                public void tick(HorrorMob m, ServerLevel l) { if (m.tickCount == 4) m.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.SHIELD)); }
                @Override public float hurt(HorrorMob m, DamageSource s, float a) {
                    if (s.getEntity() != null && m.getViewVector(1f).dot(s.getEntity().position().subtract(m.position()).normalize()) > 0.3) { Fx.vsound(m.level(), m.position(), SoundEvents.SHIELD_BLOCK, 0.8f, 1f); return a * 0.5f; }
                    return a;
                }
            };
            case "builder" -> (m, l) -> {
                if (m.getTarget() instanceof ServerPlayer p && m.tickCount % 160 == 80 && m.distanceTo(p) < 12) {
                    Vec3 d = p.position().subtract(m.position()).normalize(); Vec3 mid = m.position().add(d.scale(m.distanceTo(p) * 0.4));
                    for (int k = -1; k <= 1; k++) { BlockPos b = BlockPos.containing(mid.x - d.z * k, mid.y, mid.z + d.x * k); TempBlocks.set(l, b, Blocks.COBBLESTONE.defaultBlockState(), 300); TempBlocks.set(l, b.above(), Blocks.COBBLESTONE.defaultBlockState(), 300); }
                }
            };
            case "clue_trail" -> (m, l) -> { if (m.tickCount % 10 == 0 && (m.brain.mood == Mood.FLEEING || m.brain.mood == Mood.OBSERVING)) Fx.particles(l, ParticleTypes.END_ROD, m.position().add(0, 0.1, 0), 1, 0.05); };
            case "night" -> (m, l) -> { if (m.tickCount % 40 == 0 && l.isDay() && l.canSeeSky(m.blockPosition())) { Fx.particles(l, ParticleTypes.LARGE_SMOKE, m.position().add(0, 1, 0), 15, 0.4); m.discard(); } };
            default -> null;
        };
    }
    private Skills() {}
}
