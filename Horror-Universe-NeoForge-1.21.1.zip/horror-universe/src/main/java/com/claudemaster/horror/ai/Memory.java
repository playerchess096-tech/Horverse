package com.claudemaster.horror.ai;

import com.claudemaster.horror.Weapons;
import com.claudemaster.horror.entity.HorrorMob;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.item.ItemStack;
import java.util.*;

/** Memoria limitata e significativa: cosa ha fatto male, con quali armi, quante volte è fuggito. Mai ogni movimento. */
public class Memory {
    public final Map<String, Integer> hitsBy = new HashMap<>();
    public int hurtCount, fled, melee, ranged, magic, fire, explosion, phase, gaze, extra;
    public long lastHurtTick; public UUID lastAttacker; public boolean triggered, wasOnGround = true;
    public void noteHurt(HorrorMob m, DamageSource s, float amt) {
        hurtCount++; lastHurtTick = m.tickCount; if (s.getEntity() != null) lastAttacker = s.getEntity().getUUID();
        if (s.is(DamageTypeTags.IS_PROJECTILE)) ranged++; else if (s.is(DamageTypeTags.IS_EXPLOSION)) explosion++; else if (s.is(DamageTypeTags.IS_FIRE)) fire++;
        else if (s.is(DamageTypes.MAGIC) || s.is(DamageTypes.INDIRECT_MAGIC)) magic++; else melee++;
        ItemStack w = Weapons.held(s); if (!w.isEmpty()) hitsBy.merge(BuiltInRegistries.ITEM.getKey(w.getItem()).toString(), 1, Integer::sum);
    }
    public String dominant() {
        int best = Math.max(Math.max(melee, ranged), Math.max(magic, fire));
        if (best == 0) return "none"; if (best == ranged) return "ranged"; if (best == magic) return "magic"; if (best == fire) return "fire"; return "melee";
    }
    public void save(CompoundTag t) { CompoundTag m = new CompoundTag(); m.putInt("h", hurtCount); m.putInt("f", fled); m.putInt("m", melee); m.putInt("r", ranged); m.putInt("g", magic); m.putInt("i", fire); m.putInt("p", phase); t.put("mem", m); }
    public void load(CompoundTag t) { CompoundTag m = t.getCompound("mem"); hurtCount = m.getInt("h"); fled = m.getInt("f"); melee = m.getInt("m"); ranged = m.getInt("r"); magic = m.getInt("g"); fire = m.getInt("i"); phase = m.getInt("p"); }
}
