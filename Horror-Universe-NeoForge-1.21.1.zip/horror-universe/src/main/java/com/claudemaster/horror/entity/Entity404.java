package com.claudemaster.horror.entity;

import com.claudemaster.horror.*;
import com.claudemaster.horror.world.Realm;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.BossEvent;
import net.minecraft.world.Container;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.Level.ExplosionInteraction;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import java.util.*;

/** Entity 404. Livelli: 1 Troll, 2 Skin Corrotta, 3 Piaga, 4 Demone Verde, 5 Cucciolo, 6 Signore della Piaga, 7 Apocalisse Verde, 8 Clone Vendicativo (bonus), 9 fase post-distruzione. */
public class Entity404 extends BossMob {
    private int wave, kneelHits, duelHits, loreIdx, timerEnd, trust, cats, lastTalk = -999, retreatLock;
    private BlockPos glitch;
    private final Deque<int[]> dmgLog = new ArrayDeque<>();
    private final Set<String> hitCats = new HashSet<>();
    public Entity404(EntityType<? extends Entity404> t, Level l) { super(t, l, Ent.E404); }
    @Override public String key() { return "entity404"; }
    @Override protected boolean noMelee() { return bossLevel <= 2 || bossLevel == 7; }
    private boolean duelActive() { return bossLevel == 3 && fightTicks >= 600 && (fightTicks / 600) % 2 == 1; }
    private boolean inKneel() { int c = fightTicks % 500; return c >= 380 && c < 480; }
    @Override protected float progress() {
        if (bossLevel == 7) return Math.max(0f, Math.min(1f, (timerEnd - fightTicks) / (Config.E404_TIMER.get() * 20f)));
        if (bossLevel == 3) return Math.min(1f, duelHits / 5f); if (bossLevel == 4) return Math.min(1f, kneelHits / 3f);
        if (bossLevel <= 2) return Math.min(1f, fightTicks / 4800f); return super.progress();
    }
    @Override protected Weapons.Rule rule() {
        double thr = Config.ATTACK_THRESHOLD.get();
        return switch (bossLevel) {
            case 3 -> duelActive() ? Weapons.Rule.normal() : Weapons.Rule.immune();
            case 4 -> inKneel() ? Weapons.Rule.special(1, 1) : Weapons.Rule.immune();
            case 5 -> Weapons.Rule.hitsThr(thr, 8, 4);     // non specificato dal prompt: proposta, vedi COERENZA_REGOLE.md
            case 6 -> Weapons.Rule.hitsThr(thr, 12, 6);    // idem
            case 7 -> (level() instanceof ServerLevel l && Fx.countTag(l, position(), 100, tag() + "_b") > 0) ? Weapons.Rule.immune() : Weapons.Rule.hitsThr(thr, 20, 10);
            case 8 -> Weapons.Rule.hits(4, 2);
            default -> Weapons.Rule.immune();
        };
    }
    @Override protected void begin(ServerLevel l, ServerPlayer p) {
        wave = kneelHits = duelHits = loreIdx = trust = cats = 0; glitch = null; dmgLog.clear(); hitCats.clear(); clearGear(); retreatLock = 0;
        double base = new double[]{0, 100, 120, 300, 260, 400, 900, 2000, 220, 1000}[bossLevel];
        Saga sg0 = Saga.get(l); if (sg0.wi("heart_destroyed") == 1 && l.getGameTime() < sg0.wl("heart_recover_at")) base *= 0.7;   // il cuore distrutto lo indebolisce, finché non recupera con un cuore falso
        setHp(base);
        barStyle(bossLevel >= 7 ? BossEvent.BossBarColor.RED : BossEvent.BossBarColor.GREEN, bossLevel <= 2 ? BossEvent.BossBarOverlay.NOTCHED_10 : BossEvent.BossBarOverlay.PROGRESS);
        say(p, new int[]{0, 1, 2, 3, 4, 5, 6, 6, 4, 8}[bossLevel]);
        if (bossLevel == 5) for (int i = 0; i < 3; i++) Fx.spawnNear(l, Reg.type("green_sentinel"), p.position(), 13, p, 1, tag());
        if (bossLevel == 6) { summon(l, "major_demon", 3, 14, p); equip(EquipmentSlot.MAINHAND, new ItemStack(Items.NETHERITE_SWORD)); }
        if (bossLevel == 7) {
            timerEnd = Config.E404_TIMER.get() * 20; summonType(l, Reg.type("barrier_pylon"), 3, 14, p, 3);
            for (Mob m : l.getEntitiesOfClass(Mob.class, p.getBoundingBox().inflate(40), e -> e.getTags().contains(tag()) && e.getType() == Reg.type("barrier_pylon"))) m.addTag(tag() + "_b");
            if (Saga.get(l).wi("clone_allied") == 1) { Fx.spawnNear(l, Reg.type("e404_clone_ally"), p.position(), 5, null, 1, null); for (HorrorMob m : l.getEntitiesOfClass(HorrorMob.class, p.getBoundingBox().inflate(12), e -> e.key().equals("e404_clone_ally") && e.owner == null)) m.owner = p.getUUID(); }
            Fx.msg(p, "msg.apocalypse");
        }
        if (bossLevel == 9) { Fx.msg(p, "msg.post"); setInvulnerable(false); }
    }
    @Override protected void script(ServerLevel l, ServerPlayer p) {
        switch (bossLevel) { case 1 -> l1(l, p); case 2 -> l2(l, p); case 3 -> l3(l, p); case 4 -> l4(l, p); case 5 -> l5(l, p); case 6 -> l6(l, p); case 7 -> l7(l, p); case 8 -> l8(l, p); default -> l9(l, p); }
    }
    private void l1(ServerLevel l, ServerPlayer p) {
        if (fightTicks == 40 || fightTicks == 420 || fightTicks == 800) { Fx.spawnNear(l, new EntityType<?>[]{EntityType.ZOMBIE, EntityType.SKELETON, EntityType.CREEPER}[wave++ % 3], p.position(), 10, p, 3, tag()); say(p, 4); }
        if (every(60)) tpNear(l, p, 5, 12);
        if (every(200)) for (int i = 0; i < 2; i++) { Vec3 s = Fx.spotAround(l, p.position(), 1, 4); if (s != null) TempBlocks.set(l, BlockPos.containing(s), Blocks.COBWEB.defaultBlockState(), 100); }
        if (wave >= 3 && glitch == null && fightTicks > 900 && Fx.countTag(l, position(), 80, tag()) == 0) {   // l'incontro finisce solo spezzando il Blocco Glitch
            Vec3 s = Fx.spotAround(l, p.position(), 10, 18); if (s != null) { glitch = BlockPos.containing(s); TempBlocks.set(l, glitch, Reg.block("glitch_block").defaultBlockState(), 6000, true); Fx.msg(p, "msg.sigil_ok"); say(p, 1); }
        }
        if (glitch != null && every(10)) Fx.dust(l, 0x40ff60, Vec3.atCenterOf(glitch).add(0, 1, 0), 6, 0.3);
        if (fightTicks > 6000) endFight(l, p, false);
    }
    public void glitchBroken(ServerLevel l, ServerPlayer p, BlockPos pos) { if (fighting && bossLevel == 1 && pos.equals(glitch)) endFight(l, p, true); }
    private void l2(ServerLevel l, ServerPlayer p) {
        if (every(5)) Fx.dust(l, 0x40ff60, position().add(0, 1, 0), 4, 0.5);
        if (at(400, 100) && loreIdx < 5) say(p, 2 + loreIdx++);
        if (at(300, 0)) p.sendSystemMessage(Component.literal(String.valueOf(10000000 + l.random.nextInt(89999999))).withStyle(ChatFormatting.GREEN));
        if (at(500, 200)) summon(l, "imperfect_clone", 1, 9, p);
        if (every(120)) tpNear(l, p, 6, 12);
        if (fightTicks >= 4800) endFight(l, p, true);
    }
    private void l3(ServerLevel l, ServerPlayer p) {
        if (at(300, 100) && Config.STEAL.get() && fightTicks < 600) stealFromChest(l, p);
        if (every(100)) for (int i = 0; i < 3; i++) { BlockPos b = p.blockPosition().offset(l.random.nextInt(21) - 10, -1, l.random.nextInt(21) - 10); b = new BlockPos(b.getX(), Fx.surfaceY(l, b.getX(), b.getZ()) - 1, b.getZ()); if (l.getBlockState(b).is(Blocks.GRASS_BLOCK) || l.getBlockState(b).is(Blocks.DIRT)) TempBlocks.set(l, b, Reg.block("plague_soil").defaultBlockState(), 12000, true); }
        if (fightTicks == 20) Fx.spawnNear(l, Reg.type("corrupt_pup_friend"), p.position(), 4, null, 1, null);
        if (fightTicks == 600) { Fx.msg(p, "msg.wrong_item"); say(p, 3); }
        if (duelActive() && every(80)) tpNear(l, p, 3, 6);
        if (fightTicks > 6000) endFight(l, p, false);
    }
    private void stealFromChest(ServerLevel l, ServerPlayer p) {
        for (BlockPos bp : BlockPos.betweenClosed(p.blockPosition().offset(-24, -6, -24), p.blockPosition().offset(24, 8, 24))) {
            if (l.getBlockEntity(bp) instanceof Container c && !(l.getBlockEntity(bp) instanceof net.minecraft.world.level.block.entity.HopperBlockEntity)) {
                for (int i = 0; i < c.getContainerSize(); i++) if (!c.getItem(i).isEmpty() && !c.getItem(i).is(Reg.item("recovery_totem"))) { stolen.add(c.removeItem(i, 1)); owner = p.getUUID(); say(p, 7); return; }
            }
        }
    }
    @Override protected boolean customHit(ServerPlayer p, DamageSource s, float dmg) {
        ServerLevel l = (ServerLevel) level();
        if (bossLevel == 3) {
            if (!Weapons.held(s).is(Items.IRON_SWORD)) { Fx.bar(p, "msg.wrong_item"); return true; }
            duelHits++; Fx.particles(l, ParticleTypes.DAMAGE_INDICATOR, position().add(0, 1, 0), 8, 0.3); if (duelHits >= 5) endFight(l, p, true); return true;
        }
        if (bossLevel == 4) { kneelHits++; Fx.particles(l, ParticleTypes.SOUL_FIRE_FLAME, position().add(0, 1, 0), 15, 0.4); Fx.sound(l, position(), "glitch_a", 0.8f, 1f); if (kneelHits >= 3) endFight(l, p, true); return true; }
        if (bossLevel == 6) {
            dmgLog.addLast(new int[]{fightTicks, (int) dmg}); while (!dmgLog.isEmpty() && fightTicks - dmgLog.peekFirst()[0] > 60) dmgLog.pollFirst();
            int sum = 0; for (int[] e : dmgLog) sum += e[1];
            if (sum > getMaxHealth() * 0.25f && retreatLock == 0) { retreatLock = 1; retreat(l, p); return true; }
        }
        return false;
    }
    private void retreat(ServerLevel l, ServerPlayer p) {   // ritirata tattica: lascia una copia che attiva il livello bonus; il giocatore subisce una perdita d'arto NARRATIVA e reversibile
        Fx.msg(p, "msg.e404_retreat"); Fx.fx(p, "limb_loss", 2400, 0); Fx.msg(p, "msg.limb");
        Entity404 c = (Entity404) Reg.type("entity404").create(l);
        if (c != null) { c.moveTo(getX(), getY(), getZ()); l.addFreshEntity(c); c.startFight(p, 8); }
        bar.removeAllPlayers(); fighting = false; killMinions(l); discard();
    }
    private void l4(ServerLevel l, ServerPlayer p) {
        if (at(200, 100)) summon(l, "living_tentacle", 1, 7, p);
        if (at(120, 0) && Config.SHAKE.get()) Fx.fx(p, "tremor", 60, 0);
        if (at(600, 300)) { ItemEntity ie = new ItemEntity(l, p.getX() + 2, p.getY() + 0.5, p.getZ(), new ItemStack(Reg.item("green_food"))); l.addFreshEntity(ie); }
        if (at(300, 50)) for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) TempBlocks.set(l, p.blockPosition().offset(dx, -1, dz), Reg.block("plague_flesh").defaultBlockState(), 200, true);
        if (at(700, 400)) summon(l, "minor_demon", 1, 10, p);
        if (at(400, 200) && Config.STEAL.get()) { for (int i = 0; i < 9 && stolen.isEmpty(); i++) if (!p.getInventory().getItem(i).isEmpty()) { stolen.add(p.getInventory().getItem(i).copy()); p.getInventory().setItem(i, ItemStack.EMPTY); Fx.msg(p, "msg.steal"); } }
        if (every(100) && !inKneel()) tpNear(l, p, 5, 11);
        if (fightTicks > 9000) endFight(l, p, false);
    }
    private void l5(ServerLevel l, ServerPlayer p) {
        if (at(160, 40)) for (int[] d : new int[][]{{1, 0}, {-1, 0}, {0, 1}, {0, -1}}) { TempBlocks.set(l, p.blockPosition().offset(d[0], 0, d[1]), Reg.block("green_cube").defaultBlockState(), 200); TempBlocks.set(l, p.blockPosition().offset(d[0], 1, d[1]), Reg.block("green_cube").defaultBlockState(), 200); }
        if (at(220, 0)) p.getFoodData().setFoodLevel(Math.max(0, p.getFoodData().getFoodLevel() - 4));
        if (at(900, 450)) summon(l, "corrupt_pup", 1, 8, p);
        if (every(120)) Fx.fx(p, "green_hearts", 200, 0);
        if (fightTicks > 9000) endFight(l, p, false);
    }
    @Override public boolean doHurtTarget(Entity t) {
        if (bossLevel == 9 && t instanceof ServerPlayer p) { return p.hurt(damageSources().genericKill(), Float.MAX_VALUE); }   // fase post-distruzione: letale anche in Creativa, ma nessun dato viene toccato
        boolean ok = super.doHurtTarget(t); if (ok && bossLevel == 5 && t instanceof LivingEntity le) { heal(6f); Fx.fx(le, "green_hearts", 200, 0); } return ok;
    }
    private void l6(ServerLevel l, ServerPlayer p) {
        if (retreatLock > 0) return;
        if (every(100)) summon(l, "imperfect_clone", 2, 12, p);
        if (every(140)) { Vec3 at = p.position(); for (int i = 0; i < 10; i++) Fx.dust(l, 0xe09040, at.add(Math.cos(i * 0.63) * 3, 0.2, Math.sin(i * 0.63) * 3), 2, 0.05); later(40, () -> { Fx.particles(l, ParticleTypes.EXPLOSION, at, 3, 1.0); Fx.sound(l, at, "thunder_far", 1f, 1.4f); Fx.hitPlayers(l, at, 3.2, 10f, "plague"); }); }
        if (at(300, 100)) p.addEffect(new MobEffectInstance(MobEffects.WITHER, 100, 0));
        if (at(600, 300) && Config.ASSIMILATION.get()) assimilate(l, p);
        if (every(40)) Fx.dust(l, 0x40ff60, p.position().add(0, 30, 0), 20, 6);
        if (every(160)) tpNear(l, p, 6, 12);
        if (fightTicks > 12000) endFight(l, p, false);
    }
    private void assimilate(ServerLevel l, ServerPlayer p) {   // solo creature nel tag horror_universe:assimilable (boss vanilla e di altre mod); mai giocatori
        for (LivingEntity e : l.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(64), x -> x instanceof Mob && !(x instanceof HorrorMob) && x.getType().is(net.minecraft.tags.TagKey.create(net.minecraft.core.registries.Registries.ENTITY_TYPE, HorrorMod.id("assimilable"))) && !x.getType().is(net.minecraft.tags.TagKey.create(net.minecraft.core.registries.Registries.ENTITY_TYPE, HorrorMod.id("no_assimilate"))) && !x.getTags().contains("hu_servant"))) {
            try { e.addTag("hu_servant"); ((Mob) e).setTarget(p); e.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 1200, 0)); Fx.particles(l, ParticleTypes.SOUL_FIRE_FLAME, e.position().add(0, 1, 0), 30, 0.6); } catch (Exception ex) { HorrorMod.LOG.warn("Assimilazione fallita per {}", e.getType(), ex); }
            return;
        }
    }
    private void l7(ServerLevel l, ServerPlayer p) {
        int st = countStatues(l, p); int left = timerEnd - fightTicks; bar.setName(Component.translatable("horror_universe.msg.timer").append(Component.literal(" " + (left / 1200) + ":" + String.format("%02d", (left / 20) % 60) + "  | " + st + "/5")));
        if (left <= 0) { apocalypse(l, p); return; }
        int iv = 120 + 40 * st;
        if (every(iv)) for (int k = 0; k < Math.max(1, 3 - st / 2); k++) { Vec3 at = p.position().add(l.random.nextInt(11) - 5, 0, l.random.nextInt(11) - 5); for (int i = 0; i < 8; i++) Fx.dust(l, 0xe09040, at.add(Math.cos(i * 0.8) * 3, 0.2, Math.sin(i * 0.8) * 3), 1, 0.05); later(40, () -> { Fx.particles(l, ParticleTypes.EXPLOSION, at, 2, 0.8); Fx.sound(l, at, "thunder_far", 1f, 1.5f); Fx.hitPlayers(l, at, 3.2, 12f, "plague"); }); }
        if (at(400, 200)) summon(l, "green_sentinel", 2, 14, p);
        if (at(700, 350) && st < 2 && Config.DIMENSIONS.get()) Realm.hop(p);
        if (at(1500, 700) && st < 3) Fx.fx(p, "inner_threat", 600, 0);
        if (at(2400, 1200) && st < 5 && Fx.countTag(l, position(), 100, tag() + "_b") < 3) { summonType(l, Reg.type("barrier_pylon"), 1, 14, p, 6); for (Mob m : l.getEntitiesOfClass(Mob.class, p.getBoundingBox().inflate(40), e -> e.getTags().contains(tag()) && e.getType() == Reg.type("barrier_pylon") && !e.getTags().contains(tag() + "_b"))) m.addTag(tag() + "_b"); }
        if (every(40)) Fx.dust(l, 0x40ff60, p.position().add(0, 25, 0), 30, 8);
        if (every(180)) tpNear(l, p, 8, 16);
        if (every(300)) summon(l, "plague_hunter", 2, 12, p);
    }
    public static int countStatues(ServerLevel l, ServerPlayer p) { int n = 0; for (BlockPos bp : Saga.get(l).statues()) if (bp.distSqr(p.blockPosition()) < 100 * 100 && l.getBlockState(bp).is(Reg.block("fate_statue"))) n++; return Math.min(5, n); }
    private void apocalypse(ServerLevel l, ServerPlayer p) {
        if (Config.WORLD_DESTRUCTION.get()) { Saga.get(l).wsi("devastated", 1); Fx.msg(p, "msg.apocalypse"); l.setWeatherParameters(0, 24000, true, true); }
        endFight(l, p, false); if (Config.WORLD_DESTRUCTION.get()) spawnPost(l, p);
    }
    public static void spawnPost(ServerLevel l, ServerPlayer p) { Entity404 e = (Entity404) Reg.type("entity404").create(l); if (e == null) return; Vec3 s = Fx.spotAround(l, p.position(), 20, 30); if (s == null) s = p.position(); e.moveTo(s.x, s.y, s.z); l.addFreshEntity(e); e.startFight(p, 9); }
    private void l8(ServerLevel l, ServerPlayer p) {
        if (every(60)) tpNear(l, p, 3, 7); if (at(300, 100)) summon(l, "imperfect_clone", 1, 8, p);
        if (at(500, 0)) Fx.msg(p, "msg.trust", trust);
        if (fightTicks > 9000) endFight(l, p, false);
    }
    /** Persuasione via chat: servono più messaggi lunghi, di categorie diverse, con fiducia sufficiente. Gli insulti la riducono. */
    public void onChat(ServerPlayer p, String text) {
        if (!fighting || bossLevel != 8 || !p.getUUID().equals(fightPlayer) || !(level() instanceof ServerLevel l)) return;
        String t = text.toLowerCase(Locale.ROOT); int words = t.trim().split("\\s+").length;
        if (fightTicks - lastTalk < 40) return; lastTalk = fightTicks;
        if (words < 4) { say(p, 3); Fx.msg(p, "msg.trust", trust); return; }
        if (t.matches(".*(stupid|idiot|muori|noob|inutile|schifo|odio).*")) { trust = Math.max(-50, trust - 25); say(p, 6); Fx.fx(this, "green_hearts", 60, 0); Fx.msg(p, "msg.trust", trust); return; }
        String[][] cat = {{"capisco", "comprendo", "mi dispiace", "scusa", "perdon", "soffri", "dolore", "understand", "sorry"}, {"vendetta", "non serve", "smetti", "basta", "pace", "insieme", "aiut", "non sei solo", "peace", "stop"}, {"skin", "mojang", "licenzi", "rabbia", "dipendente", "umano", "ricord", "fired", "anger"}};
        int gained = 0, newCats = 0;
        for (int i = 0; i < cat.length; i++) for (String k : cat[i]) if (t.contains(k)) { if (hitCats.add("c" + i)) { gained += 18; newCats++; } else gained += 4; break; }
        if (gained == 0) { say(p, 4); gained = 2; }
        trust = Math.min(100, trust + gained); Fx.msg(p, "msg.trust", trust); Fx.particles(l, ParticleTypes.HAPPY_VILLAGER, position().add(0, 2, 0), 8, 0.4);
        if (trust >= 70 && hitCats.size() >= 3) { Saga.get(l).wsi("clone_allied", 1); Fx.msg(p, "msg.clone_ally"); say(p, 5); endFight(l, p, true); }
    }
    private void l9(ServerLevel l, ServerPlayer p) {
        if (every(30) && distanceTo(p) > 3) getNavigation().moveTo(p, 1.4);
        if (at(400, 200)) { Vec3 at = p.position(); later(40, () -> Fx.hitPlayers(l, at, 3.2, 12f, "plague")); Fx.dust(l, 0xe09040, at, 30, 1.5); }
        if (every(30) && distanceTo(p) < 3) doHurtTarget(p);
        if (fightTicks > 12000) endFight(l, p, false);
    }
    @Override protected void onLethal(ServerLevel l, ServerPlayer p, DamageSource s) {
        if (bossLevel == 5 || bossLevel == 6 || bossLevel == 8 || bossLevel == 7) { if (bossLevel == 7) Saga.get(l).wsi("e404_defeated", 1); endFight(l, p, true); } else super.onLethal(l, p, s);
    }
    /** Se un giocatore sta per morire contro il Cucciolo (livello 5), viene trasportato nella Dimensione Verde invece di morire. */
    public static boolean rescueToRealm(ServerPlayer p) {
        for (Entity404 e : p.serverLevel().getEntitiesOfClass(Entity404.class, p.getBoundingBox().inflate(48), x -> x.fighting && x.bossLevel == 5 && p.getUUID().equals(x.fightPlayer))) {
            if (!Config.DIMENSIONS.get()) return false; p.setHealth(6f); e.endFight(p.serverLevel(), p, false); Realm.enter(p); return true;
        }
        return false;
    }
    /** Se il giocatore muore durante il duello del livello 3, la casa "esplode" in modo narrativo (visivo; blocchi intatti salvo configurazione). */
    public static void onPlayerDeath(ServerPlayer p) {
        for (Entity404 e : p.serverLevel().getEntitiesOfClass(Entity404.class, p.getBoundingBox().inflate(80), x -> x.fighting && x.bossLevel == 3 && x.duelActive() && p.getUUID().equals(x.fightPlayer))) {
            ServerLevel l = p.serverLevel(); BlockPos b = p.getRespawnPosition() != null ? p.getRespawnPosition() : p.blockPosition();
            l.explode(null, b.getX() + 0.5, b.getY() + 0.5, b.getZ() + 0.5, 3f, Config.HOUSE_EXPLOSION.get() ? ExplosionInteraction.TNT : ExplosionInteraction.NONE); e.say(p, 6); return;
        }
    }
    @Override protected void cleanup(ServerLevel l, ServerPlayer p) {
        killMinions(l); TempBlocks.restoreNear(l, blockPosition(), 80, s -> s.is(Reg.block("green_cube")) || s.is(Blocks.COBWEB) || s.is(Reg.block("glitch_block")) || s.is(Reg.block("plague_flesh")));
        if (p != null) p.removeEffect(Reg.fx("green_hearts"));
        for (Mob m : l.getEntitiesOfClass(Mob.class, getBoundingBox().inflate(120), e -> e.getTags().contains("hu_servant"))) { m.setTarget(null); m.removeTag("hu_servant"); }
    }
    @Override protected void reward(ServerLevel l, ServerPlayer p) {
        switch (bossLevel) {
            case 1 -> Fx.give(p, "green_fragment", 2); case 2 -> { Fx.give(p, "green_fragment", 3); Fx.give(p, "scroll_e404", 1); }
            case 3 -> { Fx.give(p, "plague_core", 1); Fx.give(p, "plague_vial", 1); } case 4 -> { Fx.give(p, "plague_crystal", 3); Fx.give(p, "key_realm", 1); }
            case 5 -> { Fx.give(p, "lord_core", 1); Fx.give(p, "plague_crystal", 3); } case 6 -> Fx.give(p, "plague_ingot", 4);
            case 7 -> { Fx.give(p, "soul_seal", 1); Fx.give(p, "plague_ingot", 8); }
            default -> { }
        }
    }
}
