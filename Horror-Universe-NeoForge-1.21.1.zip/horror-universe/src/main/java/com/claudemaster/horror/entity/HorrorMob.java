package com.claudemaster.horror.entity;

import com.claudemaster.horror.*;
import com.claudemaster.horror.ai.*;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import java.util.*;

/** Base di tutte le creature della mod: cervello a stati, memoria, abilità, debolezze e furto reversibile. */
public abstract class HorrorMob extends Monster {
    public final Brain brain = new Brain(this);
    public final Memory mem = new Memory();
    public Vec3 home; public UUID owner;
    public final List<ItemStack> stolen = new ArrayList<>();
    protected boolean diffDone;
    private record Task(int at, Runnable r) {}
    private final List<Task> tasks = new ArrayList<>();
    protected HorrorMob(EntityType<? extends Monster> t, Level l) { super(t, l); }
    public abstract String key();
    public Ent family() { return null; }
    public boolean has(String a) { return false; }
    public List<String> weak() { return List.of(); }
    protected List<Ability> abilities() { return List.of(); }
    protected boolean noMelee() { return false; }
    public void later(int ticks, Runnable r) { tasks.add(new Task(tickCount + ticks, r)); }
    public double power() { return getMaxHealth() / 20.0 + getAttributeValue(Attributes.ATTACK_DAMAGE) / 3.0; }

    @Override protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(2, new BrainGoal());
        goalSelector.addGoal(3, new MeleeAttackGoal(this, 1.15, true) {
            @Override public boolean canUse() { return brain.mood == Mood.HOSTILE && !noMelee() && super.canUse(); }
            @Override public boolean canContinueToUse() { return brain.mood == Mood.HOSTILE && !noMelee() && super.canContinueToUse(); }
        });
        goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 16f));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, 10, true, false, e -> e instanceof Player p && brain.wantsTarget(p)));
    }
    /** Movimento guidato dall'umore (osserva, pedina, indaga, fugge, segue). Il combattimento resta ai goal vanilla. */
    private class BrainGoal extends Goal {
        private int cd;
        BrainGoal() { setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK)); }
        @Override public boolean canUse() { Mood m = brain.mood; return m != Mood.HOSTILE && m != Mood.DORMANT && m != Mood.FINAL && !isNoAi(); }
        @Override public boolean canContinueToUse() { return canUse(); }
        @Override public void tick() {
            if (!(level() instanceof ServerLevel l)) return;
            ServerPlayer p = Senses.nearestPlayer(l, HorrorMob.this, 64); if (p == null) return;
            double d = distanceTo(p); getLookControl().setLookAt(p, 30f, 30f);
            if (--cd > 0) return; cd = 10;
            switch (brain.mood) {
                case OBSERVING -> { if (d < 14) away(p, 2.0); else if (d > 30) getNavigation().moveTo(p, 0.9); else getNavigation().stop(); }
                case STALKING -> { Vec3 b = p.position().subtract(p.getLookAngle().multiply(8, 0, 8)); if (d > 6) getNavigation().moveTo(b.x, b.y, b.z, 1.0); else getNavigation().stop(); }
                case INVESTIGATING -> { if (brain.heard != null) getNavigation().moveTo(brain.heard.x, brain.heard.y, brain.heard.z, 1.0); }
                case FLEEING -> away(p, 1.3);
                case ALLY, TRUCE -> { if (d > 10) getNavigation().moveTo(p, 1.1); else if (d < 3.5) getNavigation().stop(); }
                default -> { }
            }
        }
        private void away(ServerPlayer p, double speed) { Vec3 v = position().subtract(p.position()).normalize().scale(12); getNavigation().moveTo(getX() + v.x, getY(), getZ() + v.z, speed); }
    }
    @Override protected void customServerAiStep() {
        super.customServerAiStep();
        if (!(level() instanceof ServerLevel sl)) return;
        if (!diffDone) { applyDifficulty(); diffDone = true; if (home == null) home = position(); }
        if (tickCount % 5 == 0) brain.tick(sl);
        aiTick(sl);
    }
    protected void aiTick(ServerLevel l) { for (Ability a : abilities()) a.tick(this, l); }
    protected void applyDifficulty() {
        double d = Config.DIFFICULTY.get(); if (d == 1.0) return;
        AttributeInstance h = getAttribute(Attributes.MAX_HEALTH); h.setBaseValue(h.getBaseValue() * d); setHealth(getMaxHealth());
        AttributeInstance a = getAttribute(Attributes.ATTACK_DAMAGE); if (a != null) a.setBaseValue(a.getBaseValue() * d);
    }
    @Override public void tick() {
        super.tick();
        if (level().isClientSide) return;
        if (!tasks.isEmpty()) for (Task t : new ArrayList<>(tasks)) if (tickCount >= t.at()) { tasks.remove(t); t.r().run(); }
        tickExtra();
    }
    protected void tickExtra() {}
    @Override public boolean hurt(DamageSource src, float amt) {
        if (level().isClientSide) return super.hurt(src, amt);
        amt = weaknessAdjust(src, amt); mem.noteHurt(this, src, amt);
        for (Ability a : abilities()) amt = a.hurt(this, src, amt);
        return super.hurt(src, amt);
    }
    private float weaknessAdjust(DamageSource src, float amt) {
        ItemStack w = Weapons.held(src);
        for (String t : weak()) {
            boolean neg = t.startsWith("-"); String k = neg ? t.substring(1) : t; boolean m = false;
            switch (k) {
                case "light" -> m = level().getMaxLocalRawBrightness(blockPosition()) >= 12;
                case "fire" -> m = src.is(DamageTypeTags.IS_FIRE);
                case "projectile" -> m = src.is(DamageTypeTags.IS_PROJECTILE);
                case "magic" -> m = src.is(DamageTypes.MAGIC) || src.is(DamageTypes.INDIRECT_MAGIC);
                case "pickaxe" -> m = w.getItem() instanceof PickaxeItem;
                case "sword" -> m = w.getItem() instanceof SwordItem;
                case "plague_weapon" -> { amt *= Weapons.isPlague(w) ? 1.5f : 0.15f; continue; }
                default -> { }
            }
            if (m) amt *= neg ? 0.5f : 1.5f;
        }
        if (key().equals("living_statue") && !(w.getItem() instanceof PickaxeItem) && !src.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) amt = 0f;
        if (has("deflect") && src.is(DamageTypeTags.IS_PROJECTILE)) amt *= 0.3f;
        return amt;
    }
    @Override public boolean doHurtTarget(Entity t) {
        boolean ok = super.doHurtTarget(t);
        if (ok && t instanceof LivingEntity le) for (Ability a : abilities()) a.hit(this, le);
        return ok;
    }
    @Override public void die(DamageSource s) {
        super.die(s);
        if (level() instanceof ServerLevel l) { returnStolen(); for (Ability a : abilities()) a.death(this, l); }
    }
    @Override public void remove(Entity.RemovalReason r) { if (!level().isClientSide && r.shouldDestroy()) returnStolen(); super.remove(r); }
    public void returnStolen() {
        if (stolen.isEmpty()) return;
        Player p = owner == null ? null : level().getPlayerByUUID(owner);
        for (ItemStack s : new ArrayList<>(stolen)) { if (p instanceof ServerPlayer sp) Fx.give(sp, s); else spawnAtLocation(s); }
        stolen.clear();
    }
    @Override public void addAdditionalSaveData(CompoundTag t) {
        super.addAdditionalSaveData(t); t.putString("mood", brain.mood.name()); t.putBoolean("diff", diffDone);
        if (home != null) { t.putDouble("hx", home.x); t.putDouble("hy", home.y); t.putDouble("hz", home.z); }
        if (owner != null) t.putUUID("owner", owner);
        ListTag l = new ListTag(); for (ItemStack s : stolen) l.add(s.save(registryAccess())); t.put("stolen", l); mem.save(t);
    }
    @Override public void readAdditionalSaveData(CompoundTag t) {
        super.readAdditionalSaveData(t); try { brain.mood = Mood.valueOf(t.getString("mood")); } catch (Exception ignored) { }
        diffDone = t.getBoolean("diff"); if (t.contains("hx")) home = new Vec3(t.getDouble("hx"), t.getDouble("hy"), t.getDouble("hz"));
        if (t.hasUUID("owner")) owner = t.getUUID("owner");
        ListTag l = t.getList("stolen", 10); for (int i = 0; i < l.size(); i++) ItemStack.parse(registryAccess(), l.getCompound(i)).ifPresent(stolen::add); mem.load(t);
    }
}
