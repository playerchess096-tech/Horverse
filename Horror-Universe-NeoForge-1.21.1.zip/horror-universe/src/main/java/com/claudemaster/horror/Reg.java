package com.claudemaster.horror;

import com.claudemaster.horror.entity.*;
import com.google.gson.*;
import net.minecraft.Util;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.*;
import net.minecraft.world.item.*;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.block.Block;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredRegister;
import java.util.*;
import java.util.function.Supplier;

/** Tutte le registrazioni, guidate da horror_content.json. */
public final class Reg {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(HorrorMod.MODID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(HorrorMod.MODID);
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(Registries.ENTITY_TYPE, HorrorMod.MODID);
    public static final DeferredRegister<MobEffect> EFFECTS = DeferredRegister.create(Registries.MOB_EFFECT, HorrorMod.MODID);
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(Registries.SOUND_EVENT, HorrorMod.MODID);
    public static final DeferredRegister<ArmorMaterial> ARMOR = DeferredRegister.create(Registries.ARMOR_MATERIAL, HorrorMod.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, HorrorMod.MODID);
    public static final Map<String, Supplier<? extends Block>> B = new LinkedHashMap<>();
    public static final Map<String, Supplier<? extends Item>> I = new LinkedHashMap<>();
    public static final Map<String, Supplier<? extends EntityType<?>>> E = new LinkedHashMap<>();
    public static final Map<String, Holder<MobEffect>> FX = new LinkedHashMap<>();
    public static final Map<String, Supplier<SoundEvent>> S = new LinkedHashMap<>();
    public static final Holder<ArmorMaterial> PALE_MAT, PLAGUE_MAT;

    private static Holder<ArmorMaterial> mat(String name, int boots, int legs, int chest, int helm, int ench, float tough, float kb, String repair) {
        return ARMOR.register(name, () -> new ArmorMaterial(Util.make(new EnumMap<>(ArmorItem.Type.class), m -> {
            m.put(ArmorItem.Type.BOOTS, boots); m.put(ArmorItem.Type.LEGGINGS, legs); m.put(ArmorItem.Type.CHESTPLATE, chest);
            m.put(ArmorItem.Type.HELMET, helm); m.put(ArmorItem.Type.BODY, chest);
        }), ench, SoundEvents.ARMOR_EQUIP_IRON, () -> Ingredient.of(item(repair)), List.of(new ArmorMaterial.Layer(HorrorMod.id(name))), tough, kb));
    }
    private static <T extends Entity> void boss(String id, EntityType.EntityFactory<T> f) {
        Content.BossSpec b = Content.BOSSES.get(id);
        E.put(id, ENTITIES.register(id, () -> EntityType.Builder.of(f, MobCategory.MONSTER).sized(b.w(), b.h()).clientTrackingRange(10).build(id)));
    }
    static {
        PALE_MAT = mat("pale", 3, 6, 8, 3, 15, 1.5f, 0.0f, "pale_ingot");
        PLAGUE_MAT = mat("plague", 4, 7, 9, 4, 12, 3.0f, 0.1f, "plague_ingot");
        for (JsonElement e : Content.arr("blocks")) {
            JsonObject d = e.getAsJsonObject(); String id = d.get("id").getAsString();
            B.put(id, BLOCKS.register(id, () -> HBlocks.make(d)));
            I.put(id, ITEMS.register(id, () -> new BlockItem(block(id), new Item.Properties())));
        }
        for (JsonElement e : Content.arr("items")) {
            JsonObject d = e.getAsJsonObject(); String id = d.get("id").getAsString();
            I.put(id, ITEMS.register(id, () -> HItems.make(d)));
        }
        for (JsonElement e : Content.arr("effects")) {
            JsonObject d = e.getAsJsonObject(); String id = d.get("id").getAsString();
            FX.put(id, EFFECTS.register(id, () -> new HorrorEffect(Content.b(d, "good") ? MobEffectCategory.BENEFICIAL : MobEffectCategory.HARMFUL, (int) Content.n(d, "color", 0x555555), id, (int) Content.n(d, "interval", 20))));
        }
        for (JsonElement e : Content.arr("sounds")) {
            String id = e.getAsString();
            S.put(id, SOUNDS.register(id, () -> SoundEvent.createVariableRangeEvent(HorrorMod.id(id))));
        }
        for (Content.MobSpec m : Content.MOBS.values())
            E.put(m.id(), ENTITIES.register(m.id(), () -> EntityType.Builder.of(SpecMob::new, MobCategory.MONSTER).sized(m.w(), m.h()).clientTrackingRange(8).build(m.id())));
        boss("custode", Custode::new); boss("corrotto", Corrotto::new); boss("entity404", Entity404::new);
        boss("mago", Mago::new); boss("steve", SteveBoss::new); boss("osservatore", Osservatore::new);
        TABS.register("main", () -> CreativeModeTab.builder().title(Component.translatable("itemGroup.horror_universe")).icon(() -> new ItemStack(item("eden_fruit")))
                .displayItems((p, out) -> { for (Supplier<? extends Item> s : I.values()) out.accept(s.get()); }).build());
    }
    public static void init(IEventBus bus) {
        BLOCKS.register(bus); ITEMS.register(bus); ENTITIES.register(bus); EFFECTS.register(bus); SOUNDS.register(bus); ARMOR.register(bus); TABS.register(bus);
    }
    public static Block block(String id) { return B.get(id).get(); }
    public static Item item(String id) { return I.get(id).get(); }
    public static EntityType<?> type(String id) { return E.get(id).get(); }
    @SuppressWarnings("unchecked") public static EntityType<? extends Mob> mob(String id) { return (EntityType<? extends Mob>) E.get(id).get(); }
    public static Holder<MobEffect> fx(String id) { return FX.get(id); }
    public static SoundEvent sound(String id) { return S.get(id).get(); }
    private Reg() {}
}
