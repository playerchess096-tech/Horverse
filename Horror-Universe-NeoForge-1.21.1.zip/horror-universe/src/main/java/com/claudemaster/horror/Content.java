package com.claudemaster.horror;

import com.google.gson.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Legge horror_content.json: unica fonte per oggetti, blocchi, mostri, effetti e suoni "semplici". */
public final class Content {
    public record MobSpec(String id, String owner, String model, float w, float h, double hp, double dmg, double spd,
                          List<String> abil, List<String> weak, boolean glow, float scale, int weight) {
        public boolean has(String a) { return abil.contains(a); }
    }
    public record BossSpec(String id, String model, float w, float h, float scale) {}
    private static JsonObject root;
    public static final Map<String, MobSpec> MOBS = new LinkedHashMap<>();
    public static final Map<String, BossSpec> BOSSES = new LinkedHashMap<>();
    public static final Map<String, List<String>> BY_OWNER = new HashMap<>();

    public static synchronized JsonObject root() {
        if (root == null) {
            try (InputStream in = Content.class.getResourceAsStream("/horror_content.json")) {
                root = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
            } catch (Exception e) { throw new RuntimeException("horror_content.json mancante o non valido", e); }
        }
        return root;
    }
    public static JsonArray arr(String k) { return root().getAsJsonArray(k); }
    public static String s(JsonObject o, String k, String d) { return o.has(k) ? o.get(k).getAsString() : d; }
    public static double n(JsonObject o, String k, double d) { return o.has(k) ? o.get(k).getAsDouble() : d; }
    public static boolean b(JsonObject o, String k) { return o.has(k) && o.get(k).getAsBoolean(); }
    private static List<String> list(JsonObject o, String k) {
        List<String> r = new ArrayList<>();
        if (o.has(k)) for (JsonElement e : o.getAsJsonArray(k)) r.add(e.getAsString());
        return r;
    }
    static {
        for (JsonElement e : arr("mobs")) {
            JsonObject o = e.getAsJsonObject();
            MobSpec m = new MobSpec(s(o, "id", "?"), s(o, "owner", "hostile"), s(o, "model", "humanoid"), (float) n(o, "w", 0.6), (float) n(o, "h", 1.95),
                    n(o, "hp", 20), n(o, "dmg", 3), n(o, "spd", 0.25), list(o, "abil"), list(o, "weak"), b(o, "glow"), (float) n(o, "scale", 1), (int) n(o, "weight", 0));
            MOBS.put(m.id(), m);
            BY_OWNER.computeIfAbsent(m.owner(), k -> new ArrayList<>()).add(m.id());
        }
        for (JsonElement e : arr("bosses")) {
            JsonObject o = e.getAsJsonObject();
            BOSSES.put(s(o, "id", "?"), new BossSpec(s(o, "id", "?"), s(o, "model", "humanoid"), (float) n(o, "w", 0.6), (float) n(o, "h", 1.95), (float) n(o, "scale", 1)));
        }
    }
    /** Mostro "minion" scelto a caso tra quelli dello stesso proprietario (escluso se stesso e i boss). */
    public static String minionOf(String owner, String except, Random r) {
        List<String> l = new ArrayList<>();
        for (String id : BY_OWNER.getOrDefault(owner, List.of())) {
            MobSpec m = MOBS.get(id);
            if (!id.equals(except) && m.hp() < 150 && m.spd() > 0 && !m.has("ally") && !m.has("follow") && !id.equals("illusion_double") && !id.equals("mage_copy")) l.add(id);
        }
        return l.isEmpty() ? null : l.get(r.nextInt(l.size()));
    }
    private Content() {}
}
