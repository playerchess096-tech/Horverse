package com.claudemaster.horror;

import com.claudemaster.horror.entity.*;
import com.claudemaster.horror.world.Director;
import com.claudemaster.horror.world.Realm;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;

/** /horror: choice (scelta del Custode), status, summon, event, reset, recover, realm, restore. */
public final class HorrorCommand {
    public static void register(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("horror")
            .then(Commands.literal("choice").then(Commands.literal("spare").executes(c -> choice(c, true))).then(Commands.literal("kill").executes(c -> choice(c, false))))
            .then(Commands.literal("status").executes(HorrorCommand::status))
            .then(Commands.literal("summon").requires(s -> s.hasPermission(2)).then(Commands.argument("entita", StringArgumentType.word()).suggests((c, b) -> { for (Ent e : Ent.values()) b.suggest(e.id); return b.buildFuture(); })
                .executes(c -> summon(c, 0)).then(Commands.argument("livello", IntegerArgumentType.integer(1, 9)).executes(c -> summon(c, IntegerArgumentType.getInteger(c, "livello"))))))
            .then(Commands.literal("event").requires(s -> s.hasPermission(2)).then(Commands.argument("nome", StringArgumentType.word()).executes(c -> { ServerPlayer p = c.getSource().getPlayerOrException(); Director.fire(StringArgumentType.getString(c, "nome"), p.serverLevel(), p); return 1; })))
            .then(Commands.literal("reset").requires(s -> s.hasPermission(2)).executes(c -> { ServerPlayer p = c.getSource().getPlayerOrException(); Saga.get(p.serverLevel()).resetPlayer(p.getUUID()); c.getSource().sendSuccess(() -> Component.literal("Progressione azzerata."), true); return 1; }))
            .then(Commands.literal("recover").requires(s -> s.hasPermission(2)).executes(c -> { for (ServerPlayer p : c.getSource().getServer().getPlayerList().getPlayers()) Soul.recover(p); return 1; }))
            .then(Commands.literal("realm").requires(s -> s.hasPermission(2)).executes(c -> { Realm.enter(c.getSource().getPlayerOrException()); return 1; }))
            .then(Commands.literal("restore").requires(s -> s.hasPermission(2)).executes(c -> { Saga.get(c.getSource().getServer()).wsi("devastated", 0); TempBlocks.restoreAll(c.getSource().getServer()); c.getSource().sendSuccess(() -> Component.literal("Mondo ripristinato (nessun dato era stato cancellato)."), true); return 1; })));
    }
    private static int choice(CommandContext<CommandSourceStack> c, boolean spare) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException(); if (!Custode.chooseNear(p, spare)) Fx.msg(p, "msg.immune"); return 1;
    }
    private static int status(CommandContext<CommandSourceStack> c) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException(); Saga s = Saga.get(p.serverLevel());
        for (Ent e : Ent.values()) { int lv = s.level(p.getUUID(), e), rel = s.rel(p.getUUID(), e); p.sendSystemMessage(Component.translatable("entity.horror_universe." + e.id).withStyle(e.color).append(Component.literal("  livello " + lv + "/" + e.max + "  rapporto " + rel))); }
        p.sendSystemMessage(Component.literal("Anima corrotta: " + Soul.get(p) + "%  Statue del Destino: " + Entity404.countStatues(p.serverLevel(), p) + "/5"));
        return 1;
    }
    private static int summon(CommandContext<CommandSourceStack> c, int lvl) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException(); ServerLevel l = p.serverLevel(); Ent e = Ent.of(StringArgumentType.getString(c, "entita"));
        if (e == null) { c.getSource().sendFailure(Component.literal("Entità sconosciuta: custode, corrotto, entity404, mago, steve, osservatore")); return 0; }
        if (e == Ent.OSSERVATORE) { Osservatore.startTrial(p); return 1; }
        BossMob b = (BossMob) Reg.type(e.id).create(l); Vec3 s = Fx.spotAround(l, p.position(), 6, 10); if (b == null || s == null) return 0;
        b.moveTo(s.x, s.y, s.z); l.addFreshEntity(b); b.startFight(p, lvl > 0 ? lvl : Math.min(e.max, b.nextLevel(p))); return 1;
    }
    private HorrorCommand() {}
}
