package com.claudemaster.horror.entity;

import com.claudemaster.horror.*;
import com.claudemaster.horror.ai.*;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.BossEvent;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.*;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import java.util.*;

/** L'Osservatore: presenza psicologica. Le prove (dalla Lente) premiano l'attenzione: 1 Prova del Buio, 2 Tracce nei luoghi visitati, 3 Sequenza di eventi. Non si combatte. */
public class Osservatore extends BossMob {
    private int touches, found, seqPos, tries; private final List<BlockPos> marks = new ArrayList<>(), sigils = new ArrayList<>(); private final List<Integer> seq = new ArrayList<>();
    public Osservatore(EntityType<? extends Osservatore> t, Level l) { super(t, l, Ent.OSSERVATORE); }
    @Override public String key() { return "osservatore"; }
    @Override protected boolean noMelee() { return true; }
    @Override protected boolean fightsOnPresence() { return false; }
    @Override protected int lookLimit() { return 30; }
    @Override public Mood presenceMood(double d) { return d < 8 ? Mood.FLEEING : d > 38 ? Mood.STALKING : Mood.OBSERVING; }
    @Override protected Weapons.Rule rule() { return Weapons.Rule.immune(); }
    @Override protected float progress() { return bossLevel == 1 ? Math.min(1f, fightTicks / 1800f) : bossLevel == 2 ? found / 5f : seq.isEmpty() ? 0f : seqPos / (float) seq.size(); }
    public static void startTrial(ServerPlayer p) {
        ServerLevel l = p.serverLevel(); if (!l.getEntitiesOfClass(Osservatore.class, p.getBoundingBox().inflate(100), x -> x.fighting).isEmpty()) return;
        Osservatore o = (Osservatore) Reg.type("osservatore").create(l); Vec3 s = Fx.spotAround(l, p.position(), 12, 18); if (o == null || s == null) { Fx.msg(p, "msg.defeat"); return; }
        o.moveTo(s.x, s.y, s.z); l.addFreshEntity(o); o.startFight(p, Math.min(3, o.nextLevel(p)));
    }
    @Override protected void begin(ServerLevel l, ServerPlayer p) {
        touches = found = seqPos = tries = 0; marks.clear(); sigils.clear(); seq.clear(); setHp(20); setInvisible(bossLevel == 1); barStyle(BossEvent.BossBarColor.WHITE, BossEvent.BossBarOverlay.NOTCHED_10); say(p, 1 + bossLevel);
        if (bossLevel == 1) p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 200, 0));
        if (bossLevel == 2) { List<BlockPos> v = Saga.get(l).visited(p.getUUID()); Collections.shuffle(v);
            for (int i = 0; i < 5; i++) { Vec3 s = i < v.size() ? Fx.standPos(l, v.get(i).getX(), v.get(i).getY(), v.get(i).getZ()) : Fx.spotAround(l, p.position(), 12, 40); if (s != null) { BlockPos bp = BlockPos.containing(s); if (TempBlocks.set(l, bp, Reg.block("observer_mark").defaultBlockState(), 6000, true)) marks.add(bp); } } }
        if (bossLevel == 3) { Vec3 d = p.getLookAngle(); String[] ids = {"sigil_a", "sigil_b", "sigil_c", "sigil_d"};
            for (int i = 0; i < 4; i++) { BlockPos bp = BlockPos.containing(p.getX() + d.x * 5 - d.z * (i - 1.5) * 2, p.getY(), p.getZ() + d.z * 5 + d.x * (i - 1.5) * 2); if (TempBlocks.set(l, bp, Reg.block(ids[i]).defaultBlockState(), 6000, true)) sigils.add(bp); }
            for (int i = 0; i < 4; i++) seq.add(random.nextInt(4)); showSeq(l); }
    }
    private void showSeq(ServerLevel l) {
        for (int i = 0; i < seq.size(); i++) { int k = seq.get(i); later(40 + i * 30, () -> { if (k < sigils.size()) { Vec3 c = Vec3.atCenterOf(sigils.get(k)); Fx.particles(l, ParticleTypes.END_ROD, c.add(0, 1, 0), 15, 0.2); Fx.sound(l, c, "chime", 0.9f, 0.7f + 0.25f * k); } }); }
    }
    @Override protected void script(ServerLevel l, ServerPlayer p) {
        if (bossLevel == 1) {
            if (every(20)) { Vec3 s = Fx.spotAround(l, p.position(), 5, 16); if (s != null) moveTo(s.x, s.y, s.z); }
            if (every(40)) Fx.soundTo(p, random.nextBoolean() ? "steps_behind" : "breath", 0.5f, 1f, position());
            if (distanceTo(p) < 2.5 && tickCount % 20 == 0) { touches++; p.hurt(damageSources().magic(), 4f); Fx.fx(p, "watched", 200, 0); say(p, 3); if (touches >= 3) endFight(l, p, false); }
            if (fightTicks >= 1800) endFight(l, p, true);
        } else if (bossLevel == 2) {
            if (every(20)) { Vec3 s = Fx.spotAround(l, p.position(), 18, 24); if (s != null) moveTo(s.x, s.y, s.z); }
            for (BlockPos bp : marks) if (every(10)) Fx.particles(l, ParticleTypes.END_ROD, Vec3.atCenterOf(bp).add(0, 1.5, 0), 2, 0.1);
            if (found >= 5) endFight(l, p, true); if (fightTicks > 4800) endFight(l, p, false);
        } else {
            if (every(20)) { Vec3 s = Fx.spotAround(l, p.position(), 14, 20); if (s != null) moveTo(s.x, s.y, s.z); }
            if (fightTicks > 6000) endFight(l, p, false);
        }
    }
    public static void markFound(ServerLevel l, ServerPlayer p, BlockPos pos) {
        for (Osservatore o : l.getEntitiesOfClass(Osservatore.class, p.getBoundingBox().inflate(120), x -> x.fighting && x.bossLevel == 2)) if (o.marks.remove(pos)) { o.found++; TempBlocks.restoreNear(l, pos, 1, s -> s.is(Reg.block("observer_mark"))); Fx.sound(l, Vec3.atCenterOf(pos), "chime", 1f, 1.2f); Fx.bar(p, "msg.victory"); }
    }
    public static void sigilPressed(ServerLevel l, ServerPlayer p, int idx) {
        for (Osservatore o : l.getEntitiesOfClass(Osservatore.class, p.getBoundingBox().inflate(60), x -> x.fighting && x.bossLevel == 3)) {
            if (o.seq.get(o.seqPos) == idx) { o.seqPos++; Fx.sound(l, p.position(), "chime", 0.8f, 0.7f + 0.25f * idx); if (o.seqPos >= o.seq.size()) { Fx.msg(p, "msg.sigil_ok"); o.endFight(l, p, true); } }
            else { Fx.msg(p, "msg.sigil_bad"); o.seqPos = 0; if (++o.tries >= 3) o.endFight(l, p, false); else o.showSeq(l); }
        }
    }
    /** Reazioni dell'Osservatore a eventi significativi (morte, sonno, diamanti, spawner, assenza prolungata...). */
    public static void react(ServerPlayer p, String what) {
        ServerLevel l = p.serverLevel(); Saga s = Saga.get(l); long gt = l.getGameTime(); if (gt - s.gl(p.getUUID(), "obsReact") < 2400 || l.random.nextInt(100) >= (int) (40 * Config.mul())) return; s.sl(p.getUUID(), "obsReact", gt);
        int line = switch (what) { case "sleep" -> 4; case "diamond" -> 5; case "return" -> 2; case "death" -> 3; default -> 6; };
        l.getServer().tell(new net.minecraft.server.TickTask(l.getServer().getTickCount() + 60 + l.random.nextInt(200), () -> { if (p.isAlive()) { Fx.say(p, Ent.OSSERVATORE, line); Fx.soundTo(p, "heartbeat", 0.7f, 1f, p.position()); } }));
    }
    @Override protected void cleanup(ServerLevel l, ServerPlayer p) { setInvisible(false); for (BlockPos bp : marks) TempBlocks.restoreNear(l, bp, 1, s -> true); for (BlockPos bp : sigils) TempBlocks.restoreNear(l, bp, 1, s -> true); }
    @Override protected void reward(ServerLevel l, ServerPlayer p) { switch (bossLevel) { case 1 -> Fx.give(p, "scroll_osservatore", 1); case 2 -> Fx.give(p, "observer_eye", 1); default -> { Fx.give(p, "observer_eye", 1); Fx.give(p, "white_symbol", 2); } } }
}
