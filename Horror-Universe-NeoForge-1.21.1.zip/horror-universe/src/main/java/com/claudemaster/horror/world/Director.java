package com.claudemaster.horror.world;

import com.claudemaster.horror.*;
import com.claudemaster.horror.entity.*;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import java.util.*;

/** Regista dell'orrore: eventi ambientali con probabilità e cooldown, apparizioni autonome delle entità, interazioni tra entità. Niente ogni-tick: lavora una volta al secondo. */
public final class Director {
    private record Task(int at, Runnable r) {}
    private static final List<Task> TASKS = new ArrayList<>();
    private static final Map<String, Long> LAST = new HashMap<>();
    public static void later(MinecraftServer s, int ticks, Runnable r) { TASKS.add(new Task(s.getTickCount() + ticks, r)); }
    /** Un livello è disponibile solo dopo un certo numero di giorni di gioco (scalato dal tipo di entità). */
    public static boolean unlocked(ServerLevel l, Ent e, int lvl) {
        long day = l.getServer().overworld().getDayTime() / 24000L;
        int base = switch (e) { case OSSERVATORE -> 0; case CUSTODE -> 1; case STEVE -> 2; case CORROTTO -> 3; case MAGO -> 4; case E404 -> 6; };
        return day >= base + (lvl - 1) * 3L;
    }
    public static void afterFight(ServerLevel l, ServerPlayer p) { if (l.random.nextInt(100) < 35) later(l.getServer(), 200, () -> { if (p.isAlive()) spawnPresence(l, p, Ent.OSSERVATORE); }); }
    public static void tick(MinecraftServer s) {
        int tc = s.getTickCount();
        if (!TASKS.isEmpty()) for (Task t : new ArrayList<>(TASKS)) if (tc >= t.at()) { TASKS.remove(t); try { t.r().run(); } catch (Exception ex) { HorrorMod.LOG.warn("Task Director fallito", ex); } }
        if (tc % 20 != 0) return;
        for (ServerPlayer p : s.getPlayerList().getPlayers()) {
            if (!p.isAlive() || p.isSpectator()) continue; ServerLevel l = p.serverLevel();
            if (l.dimension() == Realm.R404) continue;
            events(l, p); appearances(l, p);
        }
        if (tc % 100 == 0) interactions(s);
    }
    private static Vec3 behind(ServerPlayer p, double d) { return p.position().subtract(p.getLookAngle().multiply(d, 0, d)); }
    private static void events(ServerLevel l, ServerPlayer p) {
        if (l.random.nextDouble() >= Config.mul() / Config.EVENT_SECONDS.get()) return;
        long day = l.getServer().overworld().getDayTime() / 24000L;
        List<String> pool = new ArrayList<>(List.of("steps", "creeper", "whisper", "heartbeat", "title", "door", "dark", "thunder"));
        if (day >= 1) pool.addAll(List.of("figure", "torch")); if (day >= 2) pool.addAll(List.of("lightning", "fake_join")); if (day >= 3) pool.addAll(List.of("statue", "gift", "runes")); if (day >= 5) pool.add("glitch");
        String ev = pool.get(l.random.nextInt(pool.size())); String k = p.getUUID() + ev; long gt = l.getGameTime();
        if (gt - LAST.getOrDefault(k, -99999L) < 1200) return; LAST.put(k, gt); fire(ev, l, p);
    }
    public static void fire(String ev, ServerLevel l, ServerPlayer p) {
        switch (ev) {
            case "steps" -> Fx.soundTo(p, "steps_behind", 0.8f, 1f, behind(p, 4));
            case "creeper" -> Fx.vsoundTo(p, SoundEvents.CREEPER_PRIMED, 0.8f, 1f, behind(p, 3));
            case "whisper" -> Fx.soundTo(p, l.random.nextBoolean() ? "whisper_a" : "whisper_b", 0.6f, 1f, behind(p, 2));
            case "heartbeat" -> { Fx.soundTo(p, "heartbeat", 0.9f, 1f, p.position()); Fx.fx(p, "watched", 120, 0); }
            case "title" -> { Fx.title(p, Component.translatable("horror_universe.say.osservatore." + (1 + l.random.nextInt(6))).withStyle(ChatFormatting.GRAY), Component.empty()); if (Config.JUMPSCARES.get()) Fx.soundTo(p, "stinger", 0.5f, 1f, p.position()); }
            case "door" -> {
                for (BlockPos bp : BlockPos.betweenClosed(p.blockPosition().offset(-12, -2, -12), p.blockPosition().offset(12, 3, 12))) {
                    BlockState st = l.getBlockState(bp);
                    if (st.getBlock() instanceof DoorBlock db && !st.is(Blocks.IRON_DOOR) && st.getValue(DoorBlock.HALF) == DoubleBlockHalf.LOWER) {
                        BlockPos pos = bp.immutable(); boolean open = st.getValue(DoorBlock.OPEN); db.setOpen(null, l, st, pos, !open); Fx.soundTo(p, "door_creak", 0.8f, 1f, Vec3.atCenterOf(pos));
                        later(l.getServer(), 100, () -> { BlockState c = l.getBlockState(pos); if (c.getBlock() instanceof DoorBlock d2 && c.getValue(DoorBlock.OPEN) == !open) d2.setOpen(null, l, c, pos, open); }); return;
                    }
                }
                Fx.soundTo(p, "door_creak", 0.7f, 1f, behind(p, 6));
            }
            case "dark" -> { p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 100, 0)); Fx.soundTo(p, "heartbeat", 0.7f, 1f, p.position()); }
            case "thunder" -> { Vec3 far = Fx.spotAround(l, p.position(), 40, 60); Fx.soundTo(p, "thunder_far", 0.9f, 1f, far == null ? p.position() : far); }
            case "figure" -> { if (l.getEntitiesOfClass(SpecMob.class, p.getBoundingBox().inflate(90), m -> m.key().equals("faceless_wanderer")).isEmpty()) Fx.spawnNear(l, Reg.type("faceless_wanderer"), p.position(), 44, null, 1, null); }
            case "torch" -> { int n = 0; for (BlockPos bp : BlockPos.betweenClosed(p.blockPosition().offset(-10, -3, -10), p.blockPosition().offset(10, 5, 10))) { BlockState st = l.getBlockState(bp); if ((st.is(Blocks.TORCH) || st.is(Blocks.WALL_TORCH)) && TempBlocks.set(l, bp, Blocks.AIR.defaultBlockState(), 200, true) && ++n >= 3) break; } }
            case "lightning" -> { Vec3 far = Fx.spotAround(l, p.position(), 40, 60); if (far != null) { Fx.lightning(l, far, 0f, 1, null); Fx.soundTo(p, "thunder_far", 0.9f, 1f, far); } }
            case "fake_join" -> { if (!Config.FAKE_MESSAGES.get()) return; String n = new String[]{"Steve404", "Observer", "xX_Null_Xx", "Anon"}[l.random.nextInt(4)]; p.sendSystemMessage(Component.translatable("multiplayer.player.joined", n).withStyle(ChatFormatting.YELLOW)); later(l.getServer(), 120, () -> p.sendSystemMessage(Component.translatable("multiplayer.player.left", n).withStyle(ChatFormatting.YELLOW))); }
            case "statue" -> { if (l.getEntitiesOfClass(SpecMob.class, p.getBoundingBox().inflate(90), m -> m.key().equals("living_statue")).isEmpty()) Fx.spawnNear(l, Reg.type("living_statue"), p.position(), 44, null, 1, null); }
            case "gift" -> { Vec3 s = Fx.spotAround(l, p.position(), 3, 7); if (s != null) { l.addFreshEntity(new ItemEntity(l, s.x, s.y + 0.5, s.z, new ItemStack(new net.minecraft.world.item.Item[]{Items.BREAD, Items.TORCH, Items.ARROW, Items.COOKED_BEEF}[l.random.nextInt(4)], 2 + l.random.nextInt(4)))); Fx.say(p, Ent.STEVE, 6); } }
            case "runes" -> { Fx.particles(l, ParticleTypes.ENCHANT, p.position().add(0, 1, 0), 60, 1.5); Fx.sound(l, p.position(), "chime", 0.7f, 0.8f); }
            case "glitch" -> { p.sendSystemMessage(Component.literal(String.valueOf(10000000 + l.random.nextInt(89999999))).withStyle(ChatFormatting.GREEN)); Fx.soundTo(p, "glitch_a", 0.7f, 1f, p.position()); }
            default -> { }
        }
    }
    public static boolean spawnPresence(ServerLevel l, ServerPlayer p, Ent e) {
        if (!l.getEntitiesOfClass(BossMob.class, p.getBoundingBox().inflate(128), b -> b.ent == e).isEmpty()) return false;
        Vec3 s = Fx.spotAround(l, p.position(), 28, 42); if (s == null) return false;
        Entity en = Reg.type(e.id).create(l); if (en == null) return false; en.moveTo(s.x, s.y, s.z, l.random.nextFloat() * 360f, 0f); l.addFreshEntity(en); return true;
    }
    private static void appearances(ServerLevel l, ServerPlayer p) {
        if (!Config.AUTONOMOUS.get()) return; long gt = l.getGameTime(); Saga s = Saga.get(l);
        for (Ent e : Ent.values()) {
            if (!unlocked(l, e, 1) || gt - s.gl(p.getUUID(), "seen." + e.id) < Config.APPEAR_COOLDOWN.get() * 20L) continue;
            double chance = 0.004 * Config.mul() * (s.rel(p.getUUID(), e) <= -30 ? 2 : 1); if (l.random.nextDouble() >= chance) continue;
            if (spawnPresence(l, p, e)) s.sl(p.getUUID(), "seen." + e.id, gt);
        }
    }
    /** Interazioni tra entità: il Custode percepisce il Corrotto e li fa ritirare entrambi; l'Uomo Magico offre protezione dallo sguardo (se il rapporto non è ostile). */
    private static void interactions(MinecraftServer s) {
        for (ServerLevel l : s.getAllLevels()) {
            List<BossMob> all = new ArrayList<>(); for (Entity e : l.getAllEntities()) if (e instanceof BossMob b && !b.fighting) all.add(b);
            for (BossMob a : all) for (BossMob b : all) if (a.ent == Ent.CUSTODE && b.ent == Ent.CORROTTO && a.distanceTo(b) < 48) { Fx.sound(l, a.position(), "thunder_far", 1f, 0.7f); a.vanish(l); b.vanish(l); }
            for (ServerPlayer p : l.players()) if (p.hasEffect(Reg.fx("watched")) && Saga.get(l).rel(p.getUUID(), Ent.MAGO) >= 0 && !l.getEntitiesOfClass(Mago.class, p.getBoundingBox().inflate(60), m -> !m.fighting).isEmpty()) { p.removeEffect(Reg.fx("watched")); Fx.say(p, Ent.MAGO, 6); }
        }
    }
    private Director() {}
}
