package com.claudemaster.horror;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import java.util.UUID;

/** Abitudini del giocatore registrate in modo legittimo (colpi, costruzioni, miniera): servono alle entità per adattarsi. */
public final class Habits {
    public static void bump(ServerLevel l, UUID u, String k) { Saga.get(l).ai(u, "h." + k, 1); }
    public static String style(ServerLevel l, ServerPlayer p) {
        Saga s = Saga.get(l); int m = s.gi(p.getUUID(), "h.melee"), r = s.gi(p.getUUID(), "h.ranged"), b = s.gi(p.getUUID(), "h.build");
        if (b > m + r && b > 40) return "builder"; if (r > m * 1.3 && r > 5) return "ranged"; if (m > r * 1.3 && m > 5) return "melee"; return "balanced";
    }
    private Habits() {}
}
