package com.claudemaster.horror;

import net.minecraft.core.registries.Registries;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.block.Block;

public enum HTier implements Tier {
    PALE(1561, 7.0F, 3.0F, 15, BlockTags.INCORRECT_FOR_DIAMOND_TOOL, "pale_ingot"), PLAGUE(2400, 9.0F, 4.0F, 12, BlockTags.INCORRECT_FOR_NETHERITE_TOOL, "plague_ingot");
    private final int uses, ench; private final float speed, bonus; private final TagKey<Block> incorrect; private final String repair;
    HTier(int u, float s, float b, int e, TagKey<Block> inc, String r) { uses = u; speed = s; bonus = b; ench = e; incorrect = inc; repair = r; }
    public static HTier of(String n) { return n.equals("plague") ? PLAGUE : PALE; }
    @Override public int getUses() { return uses; }
    @Override public float getSpeed() { return speed; }
    @Override public float getAttackDamageBonus() { return bonus; }
    @Override public TagKey<Block> getIncorrectBlocksForDrops() { return incorrect; }
    @Override public int getEnchantmentValue() { return ench; }
    @Override public Ingredient getRepairIngredient() { return Ingredient.of(Reg.item(repair)); }
}
