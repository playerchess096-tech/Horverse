package com.claudemaster.horror;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;
import java.util.UUID;

/** Memoria persistente del mondo: progressione, relazioni, scelte, abitudini del giocatore. Nessun dato del giocatore viene cancellato. */
public class Saga extends SavedData {
    private final CompoundTag root;
    private Saga(CompoundTag r) { root = r; }
    public static Saga get(MinecraftServer s) {
        return s.overworld().getDataStorage().computeIfAbsent(new SavedData.Factory<>(() -> new Saga(new CompoundTag()), (t, p) -> new Saga(t.getCompound("d")), null), "horror_universe_saga");
    }
    public static Saga get(ServerLevel l) { return get(l.getServer()); }
    @Override public CompoundTag save(CompoundTag tag, HolderLookup.Provider p) { tag.put("d", root); return tag; }
    private static CompoundTag sub(CompoundTag parent, String key) { if (!parent.contains(key, 10)) parent.put(key, new CompoundTag()); return parent.getCompound(key); }
    private CompoundTag pl(UUID id) { return sub(sub(root, "p"), id.toString()); }
    private CompoundTag w() { return sub(root, "w"); }
    public int gi(UUID u, String k) { return pl(u).getInt(k); }
    public void si(UUID u, String k, int v) { pl(u).putInt(k, v); setDirty(); }
    public int ai(UUID u, String k, int d) { int v = gi(u, k) + d; si(u, k, v); return v; }
    public long gl(UUID u, String k) { return pl(u).getLong(k); }
    public void sl(UUID u, String k, long v) { pl(u).putLong(k, v); setDirty(); }
    public boolean gb(UUID u, String k) { return pl(u).getBoolean(k); }
    public void sb(UUID u, String k, boolean v) { pl(u).putBoolean(k, v); setDirty(); }
    public int wi(String k) { return w().getInt(k); }
    public void wsi(String k, int v) { w().putInt(k, v); setDirty(); }
    public long wl(String k) { return w().getLong(k); }
    public void wsl(String k, long v) { w().putLong(k, v); setDirty(); }
    public int rel(UUID u, Ent e) { return gi(u, "rel." + e.id); }
    public void addRel(UUID u, Ent e, int d) { si(u, "rel." + e.id, Math.max(-100, Math.min(100, rel(u, e) + d))); }
    public int level(UUID u, Ent e) { return gi(u, "lvl." + e.id); }
    /** Posti già visitati (memoria dell'Osservatore, massimo 24, in ordine di inserimento). */
    public void visit(UUID u, BlockPos p) {
        ListTag l = pl(u).getList("visited", 4); if (!pl(u).contains("visited", 9)) { l = new ListTag(); pl(u).put("visited", l); }
        for (Tag t : l) if (t instanceof LongTag lt && BlockPos.of(lt.getAsLong()).distSqr(p) < 400) return;
        l.add(LongTag.valueOf(p.asLong())); while (l.size() > 24) l.remove(0); setDirty();
    }
    public java.util.List<BlockPos> visited(UUID u) {
        java.util.List<BlockPos> r = new java.util.ArrayList<>(); if (!pl(u).contains("visited", 9)) return r;
        for (Tag t : pl(u).getList("visited", 4)) if (t instanceof LongTag lt) r.add(BlockPos.of(lt.getAsLong())); return r;
    }
    public void addStatue(BlockPos p) { ListTag l = sub(root, "w").getList("statues", 4); if (!w().contains("statues", 9)) { l = new ListTag(); w().put("statues", l); } l.add(LongTag.valueOf(p.asLong())); setDirty(); }
    public java.util.List<BlockPos> statues() { java.util.List<BlockPos> r = new java.util.ArrayList<>(); if (!w().contains("statues", 9)) return r; for (Tag t : w().getList("statues", 4)) if (t instanceof LongTag lt) r.add(BlockPos.of(lt.getAsLong())); return r; }
    public void resetPlayer(UUID u) { sub(root, "p").remove(u.toString()); setDirty(); }
}
