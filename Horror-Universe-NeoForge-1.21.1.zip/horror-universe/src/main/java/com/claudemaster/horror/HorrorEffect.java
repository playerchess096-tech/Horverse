package com.claudemaster.horror;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.*;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.phys.Vec3;
import java.util.Set;

/** Effetti personalizzati. Il Frutto dell'Eden annulla quelli elencati in PROTECTED. */
public class HorrorEffect extends MobEffect {
    public static final Set<String> PROTECTED = Set.of("electrified", "corruption", "rune_seal", "gravity_flux", "inner_threat");
    private final String id; private final int interval;
    public HorrorEffect(MobEffectCategory cat, int color, String id, int interval) {
        super(cat, color); this.id = id; this.interval = interval;
        if (id.equals("limb_loss")) {
            addAttributeModifier(Attributes.ATTACK_DAMAGE, HorrorMod.id("limb_loss_atk"), -0.4, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
            addAttributeModifier(Attributes.MOVEMENT_SPEED, HorrorMod.id("limb_loss_spd"), -0.15, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
        }
        if (id.equals("watched")) addAttributeModifier(Attributes.MOVEMENT_SPEED, HorrorMod.id("watched_spd"), -0.08, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
    }
    @Override public boolean shouldApplyEffectTickThisTick(int duration, int amp) { return interval > 0 && duration % interval == 0; }
    @Override public boolean applyEffectTick(LivingEntity e, int amp) {
        if (e.level().isClientSide || !(e.level() instanceof ServerLevel sl)) return true;
        if (PROTECTED.contains(id) && e.hasEffect(Reg.fx("eden_ward"))) { e.removeEffect(Reg.fx(id)); return true; }
        switch (id) {
            case "plague" -> { if (e.getHealth() > 2f) e.hurt(sl.damageSources().magic(), 1f + amp); if (e instanceof ServerPlayer p) p.getFoodData().addExhaustion(0.8f); Fx.dust(sl, 0x2f9b3a, e.position().add(0, 1, 0), 6, 0.4); }
            case "electrified" -> { e.hurt(sl.damageSources().lightningBolt(), 2f + amp); Fx.particles(sl, ParticleTypes.ELECTRIC_SPARK, e.position().add(0, 1, 0), 10, 0.4); }
            case "watched" -> { if (e instanceof ServerPlayer p && sl.random.nextInt(3) == 0) Fx.soundTo(p, sl.random.nextBoolean() ? "steps_behind" : "breath", 0.5f, 1f, p.position().add(-p.getLookAngle().x * 3, 0, -p.getLookAngle().z * 3)); }
            case "gravity_flux" -> { Vec3 m = e.getDeltaMovement(); e.setDeltaMovement(m.x, (e.tickCount / Math.max(1, interval)) % 2 == 0 ? 0.28 : -0.28, m.z); e.hurtMarked = true; }
            case "soul_drain" -> { if (e instanceof ServerPlayer p) Soul.add(p, 2); }
            case "inner_threat" -> { if (e instanceof ServerPlayer p) { Fx.fx(p, "watched", 60, 0); e.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 80, 0)); if (sl.random.nextInt(2) == 0) Fx.spawnNear(sl, "plague_hunter", p.position(), 5, p, 2); } }
            case "purified" -> { e.removeEffect(Reg.fx("corruption")); e.removeEffect(Reg.fx("plague")); e.removeEffect(Reg.fx("green_hearts")); }
            default -> { }
        }
        return true;
    }
}
