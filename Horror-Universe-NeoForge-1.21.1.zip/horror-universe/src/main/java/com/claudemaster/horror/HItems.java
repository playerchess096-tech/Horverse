package com.claudemaster.horror;

import com.claudemaster.horror.entity.*;
import com.claudemaster.horror.world.Realm;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.*;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import java.util.List;

/** Costruisce gli oggetti dal manifest e implementa le azioni degli oggetti speciali. */
public final class HItems {
    public static Item make(JsonObject d) {
        String kind = Content.s(d, "kind", "item"), id = Content.s(d, "id", "?"); Item.Properties p = new Item.Properties(); boolean desc = Content.b(d, "desc");
        int stack = (int) Content.n(d, "stack", 64), dur = (int) Content.n(d, "dur", 0); HTier t = HTier.of(Content.s(d, "tier", "pale"));
        switch (kind) {
            case "sword": return new Sword(t, p.attributes(SwordItem.createAttributes(t, (int) Content.n(d, "dmg", 3), (float) Content.n(d, "spd", -2.4))), Content.s(d, "onhit", ""), id, desc);
            case "axe": return new AxeItem(t, p.attributes(AxeItem.createAttributes(t, (float) Content.n(d, "dmg", 6), (float) Content.n(d, "spd", -3.1))));
            case "pickaxe": return new PickaxeItem(t, p.attributes(PickaxeItem.createAttributes(t, 1.0F, -2.8F)));
            case "shovel": return new ShovelItem(t, p.attributes(ShovelItem.createAttributes(t, 1.5F, -3.0F)));
            case "hoe": return new HoeItem(t, p.attributes(HoeItem.createAttributes(t, -2.0F, -1.0F)));
            case "armor": {
                Holder<ArmorMaterial> m = t == HTier.PALE ? Reg.PALE_MAT : Reg.PLAGUE_MAT;
                ArmorItem.Type ty = switch (Content.s(d, "slot", "head")) { case "chest" -> ArmorItem.Type.CHESTPLATE; case "legs" -> ArmorItem.Type.LEGGINGS; case "feet" -> ArmorItem.Type.BOOTS; default -> ArmorItem.Type.HELMET; };
                return new ArmorItem(m, ty, p.durability(ty.getDurability(t == HTier.PALE ? 30 : 40)));
            }
            case "food": {
                FoodProperties.Builder fb = new FoodProperties.Builder().nutrition((int) Content.n(d, "nut", 4)).saturationModifier((float) Content.n(d, "sat", 0.3)).alwaysEdible();
                if (d.has("fx")) { JsonArray a = d.getAsJsonArray("fx"); fb.effect(new MobEffectInstance(Reg.fx(a.get(0).getAsString()), a.get(1).getAsInt(), a.get(2).getAsInt()), a.get(3).getAsFloat()); }
                return new Basic(p.food(fb.build()), id, desc);
            }
            case "use": if (dur > 0) p.durability(dur); else p.stacksTo(stack); return new Use(p, Content.s(d, "use", ""), id, desc);
            case "pearl": return new Pearl(p.stacksTo(16), id);
            case "egg": { final String mob = Content.s(d, "mob", ""); return new DeferredSpawnEggItem(() -> Reg.mob(mob), (int) Content.n(d, "c1", 0x555555), (int) Content.n(d, "c2", 0xffffff), p); }
            default: return new Basic(p.stacksTo(stack), id, desc);
        }
    }
    static void tip(List<Component> tt, String id, boolean desc, ItemStack st) {
        if (desc) tt.add(Component.translatable("item.horror_universe." + id + ".desc").withStyle(ChatFormatting.GRAY));
        if (Marks.has(st, "hu_corrupted")) tt.add(Component.translatable("item.horror_universe.corrupted").withStyle(ChatFormatting.DARK_PURPLE));
        if (Marks.has(st, "hu_neutralized")) tt.add(Component.translatable("item.horror_universe.neutralized").withStyle(ChatFormatting.DARK_PURPLE));
    }
    public static class Basic extends Item {
        private final String id; private final boolean desc;
        public Basic(Properties p, String id, boolean desc) { super(p); this.id = id; this.desc = desc; }
        @Override public void appendHoverText(ItemStack st, Item.TooltipContext c, List<Component> tt, TooltipFlag f) { tip(tt, id, desc, st); }
    }
    public static class Sword extends SwordItem {
        private final String onhit, id; private final boolean desc;
        public Sword(Tier t, Properties p, String onhit, String id, boolean desc) { super(t, p); this.onhit = onhit; this.id = id; this.desc = desc; }
        @Override public boolean hurtEnemy(ItemStack st, LivingEntity t, LivingEntity a) {
            switch (onhit) {
                case "plague" -> Fx.fx(t, "plague", 100, 0);
                case "lord" -> { Fx.fx(t, "plague", 160, 1); t.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 0)); }
                case "wither" -> { t.addEffect(new MobEffectInstance(MobEffects.WITHER, 100, 0)); a.heal(1f); }
                case "slow" -> t.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 1));
                case "rune" -> Fx.fx(t, "rune_seal", 100, 0);
                default -> { }
            }
            return super.hurtEnemy(st, t, a);
        }
        @Override public void appendHoverText(ItemStack st, Item.TooltipContext c, List<Component> tt, TooltipFlag f) { tip(tt, id, desc, st); }
    }
    public static class Pearl extends EnderpearlItem {
        private final String id;
        public Pearl(Properties p, String id) { super(p); this.id = id; }
        @Override public void appendHoverText(ItemStack st, Item.TooltipContext c, List<Component> tt, TooltipFlag f) { tip(tt, id, true, st); }
    }
    public static class Use extends Item {
        private final String use, id; private final boolean desc;
        public Use(Properties p, String use, String id, boolean desc) { super(p); this.use = use; this.id = id; this.desc = desc; }
        @Override public InteractionResultHolder<ItemStack> use(Level l, Player p, InteractionHand h) {
            ItemStack st = p.getItemInHand(h);
            if (l.isClientSide) return InteractionResultHolder.success(st);
            ServerPlayer sp = (ServerPlayer) p; ServerLevel sl = (ServerLevel) l;
            if (Marks.unusable(st)) { Fx.bar(sp, "msg.corrupted"); return InteractionResultHolder.fail(st); }
            if (sp.getCooldowns().isOnCooldown(st.getItem())) return InteractionResultHolder.fail(st);
            return Uses.run(use, sl, sp, st, h);
        }
        @Override public void appendHoverText(ItemStack st, Item.TooltipContext c, List<Component> tt, TooltipFlag f) { tip(tt, id, desc, st); }
    }
    /** Azioni degli oggetti speciali. */
    static final class Uses {
        private static boolean altar(ServerLevel l, ServerPlayer p) { for (BlockPos bp : BlockPos.betweenClosed(p.blockPosition().offset(-5, -2, -5), p.blockPosition().offset(5, 3, 5))) if (l.getBlockState(bp).is(Reg.block("ritual_altar"))) return true; return false; }
        static InteractionResultHolder<ItemStack> run(String use, ServerLevel l, ServerPlayer p, ItemStack st, InteractionHand h) {
            switch (use) {
                case "eden_fruit" -> { p.addEffect(new MobEffectInstance(Reg.fx("eden_ward"), 6000, 0)); st.shrink(1); Fx.sound(l, p.position(), "chime", 1f, 1.3f); Fx.particles(l, ParticleTypes.TOTEM_OF_UNDYING, p.position().add(0, 1, 0), 40, 0.5); return InteractionResultHolder.consume(st); }
                case "artifact" -> { if (!Corrotto.useArtifact(p)) return InteractionResultHolder.pass(st); st.hurtAndBreak(1, p, LivingEntity.getSlotForHand(h)); p.getCooldowns().addCooldown(st.getItem(), 100); Fx.particles(l, ParticleTypes.END_ROD, p.position().add(0, 1, 0), 30, 0.6); return InteractionResultHolder.consume(st); }
                case "salt" -> { Corrotto.purify(p); p.removeEffect(Reg.fx("corruption")); st.shrink(1); return InteractionResultHolder.consume(st); }
                case "scepter" -> {
                    LivingEntity t = Rays.target(p, 24, e -> e != p); if (t == null) return InteractionResultHolder.fail(st);
                    Fx.lightning(l, t.position(), 0f, 0.1, null); t.hurt(l.damageSources().lightningBolt(), 10f); Fx.fx(t, "electrified", 80, 0);
                    for (LivingEntity o : l.getEntitiesOfClass(LivingEntity.class, t.getBoundingBox().inflate(6), e -> e != t && e != p && !(e instanceof Player))) { Rays.beam(l, t.getEyePosition(), o.getEyePosition(), 0x80d0ff); o.hurt(l.damageSources().lightningBolt(), 5f); }
                    p.getCooldowns().addCooldown(st.getItem(), 60); st.hurtAndBreak(1, p, LivingEntity.getSlotForHand(h)); return InteractionResultHolder.consume(st);
                }
                case "staff" -> {
                    if (p.hasEffect(Reg.fx("rune_seal"))) { Fx.bar(p, "msg.immune"); return InteractionResultHolder.fail(st); }
                    LivingEntity t = Rays.target(p, 22, e -> e != p); Rays.beam(l, p.getEyePosition(), t != null ? t.getEyePosition() : p.getEyePosition().add(p.getLookAngle().scale(18)), 0xd070ff);
                    if (t != null) t.hurt(l.damageSources().indirectMagic(p, p), 8f); Fx.sound(l, p.position(), "cast", 0.8f, 1f); p.getCooldowns().addCooldown(st.getItem(), 25); st.hurtAndBreak(1, p, LivingEntity.getSlotForHand(h)); Habits.bump(l, p.getUUID(), "magic"); return InteractionResultHolder.consume(st);
                }
                case "vial" -> { TempBlocks.restoreNear(l, p.blockPosition(), 12, s -> s.is(Reg.block("plague_soil")) || s.is(Reg.block("plague_flesh")) || s.is(Reg.block("plague_vein")) || s.is(Reg.block("green_cube"))); Saga.get(l).wsl("plague_contained_until", l.getGameTime() + 6000); p.removeEffect(Reg.fx("plague")); Fx.particles(l, ParticleTypes.END_ROD, p.position().add(0, 1, 0), 40, 2.0); st.shrink(1); return InteractionResultHolder.consume(st); }
                case "seal" -> { p.removeEffect(Reg.fx("inner_threat")); p.addEffect(new MobEffectInstance(Reg.fx("purified"), 1200, 0)); st.hurtAndBreak(1, p, LivingEntity.getSlotForHand(h)); return InteractionResultHolder.consume(st); }
                case "key_realm" -> { if (!altar(l, p)) { Fx.bar(p, "msg.realm_off"); return InteractionResultHolder.fail(st); } Realm.enter(p); return InteractionResultHolder.success(st); }
                case "key_vault" -> { if (!altar(l, p)) { Fx.bar(p, "msg.realm_off"); return InteractionResultHolder.fail(st); } Realm.enterHollow(p); return InteractionResultHolder.success(st); }
                case "recovery" -> { if (!altar(l, p)) return InteractionResultHolder.fail(st); int n = 0; for (ServerPlayer o : l.getServer().getPlayerList().getPlayers()) if (Saga.get(l).gb(o.getUUID(), "lost")) { Soul.recover(o); n++; } if (n > 0) { st.shrink(1); Fx.msg(p, "msg.recovered"); } return InteractionResultHolder.consume(st); }
                case "pact" -> { Mago.pact(p); st.shrink(1); return InteractionResultHolder.consume(st); }
                case "lens" -> { Osservatore.startTrial(p); p.getCooldowns().addCooldown(st.getItem(), 1200); return InteractionResultHolder.consume(st); }
                default -> { return InteractionResultHolder.pass(st); }
            }
        }
    }
    private HItems() {}
}
