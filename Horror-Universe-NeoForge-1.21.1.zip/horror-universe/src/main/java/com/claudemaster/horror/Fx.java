package com.claudemaster.horror;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.*;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.*;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.*;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/** Utilità comuni: particelle, suoni, effetti, messaggi, spawn sicuro. */
public final class Fx {
    public static void particles(ServerLevel l, ParticleOptions o, Vec3 p, int n, double s) { l.sendParticles(o, p.x, p.y, p.z, n, s, s, s, 0.02); }
    public static void dust(ServerLevel l, int rgb, Vec3 p, int n, double s) {
        particles(l, new DustParticleOptions(new Vector3f(((rgb >> 16) & 255) / 255f, ((rgb >> 8) & 255) / 255f, (rgb & 255) / 255f), 1.4f), p, n, s);
    }
    public static void sound(Level l, Vec3 p, String id, float v, float pt) { l.playSound(null, p.x, p.y, p.z, Reg.sound(id), SoundSource.HOSTILE, v, pt); }
    public static void vsound(Level l, Vec3 p, SoundEvent s, float v, float pt) { l.playSound(null, p.x, p.y, p.z, s, SoundSource.HOSTILE, v, pt); }
    public static void soundTo(ServerPlayer pl, String id, float v, float pt, Vec3 at) { vsoundTo(pl, Reg.sound(id), v, pt, at); }
    public static void vsoundTo(ServerPlayer pl, SoundEvent s, float v, float pt, Vec3 at) {
        pl.connection.send(new ClientboundSoundPacket(BuiltInRegistries.SOUND_EVENT.wrapAsHolder(s), SoundSource.AMBIENT, at.x, at.y, at.z, v, pt, pl.getRandom().nextLong()));
    }
    /** Applica un effetto della mod rispettando la protezione del Frutto dell'Eden. */
    public static void fx(LivingEntity e, String id, int ticks, int amp) {
        if (HorrorEffect.PROTECTED.contains(id) && e.hasEffect(Reg.fx("eden_ward"))) return;
        e.addEffect(new MobEffectInstance(Reg.fx(id), ticks, amp, false, true, true));
    }
    public static void say(ServerPlayer p, Ent e, int n) {
        p.sendSystemMessage(Component.translatable("entity.horror_universe." + e.id).withStyle(e.color, ChatFormatting.BOLD).append(Component.literal(": ").withStyle(ChatFormatting.GRAY))
                .append(Component.translatable("horror_universe.say." + e.id + "." + n).withStyle(e.color)));
    }
    public static void msg(ServerPlayer p, String key, Object... a) { p.sendSystemMessage(Component.translatable("horror_universe." + key, a).withStyle(ChatFormatting.GRAY)); }
    public static void bar(ServerPlayer p, String key, Object... a) { p.displayClientMessage(Component.translatable("horror_universe." + key, a), true); }
    public static void title(ServerPlayer p, Component t, Component sub) {
        p.connection.send(new ClientboundSetTitlesAnimationPacket(10, 50, 30)); p.connection.send(new ClientboundSetSubtitleTextPacket(sub)); p.connection.send(new ClientboundSetTitleTextPacket(t));
    }
    public static void give(ServerPlayer p, ItemStack s) { if (!p.getInventory().add(s)) p.drop(s, false); }
    public static void give(ServerPlayer p, String item, int n) { give(p, new ItemStack(Reg.item(item), n)); }
    /** Posizione in cui stare in piedi vicino a (x, yHint, z), oppure null. */
    public static Vec3 standPos(ServerLevel l, double x, double yHint, double z) {
        int bx = Mth.floor(x), bz = Mth.floor(z);
        for (int dy = 5; dy >= -8; dy--) {
            BlockPos p = new BlockPos(bx, (int) yHint + dy, bz);
            if (l.getBlockState(p).isAir() && l.getBlockState(p.above()).isAir() && !l.getBlockState(p.below()).getCollisionShape(l, p.below()).isEmpty() && l.getFluidState(p).isEmpty())
                return new Vec3(bx + 0.5, p.getY(), bz + 0.5);
        }
        return null;
    }
    public static Vec3 spotAround(ServerLevel l, Vec3 c, double min, double max) {
        for (int i = 0; i < 14; i++) {
            double a = l.random.nextDouble() * Math.PI * 2, r = min + l.random.nextDouble() * (max - min);
            Vec3 s = standPos(l, c.x + Math.cos(a) * r, c.y, c.z + Math.sin(a) * r); if (s != null) return s;
        }
        return null;
    }
    public static int countTag(ServerLevel l, Vec3 c, double r, String tag) { return l.getEntitiesOfClass(Mob.class, new AABB(c, c).inflate(r), e -> e.getTags().contains(tag)).size(); }
    public static int spawnNear(ServerLevel l, String mobId, Vec3 c, double r, ServerPlayer target, int n) { return spawnNear(l, Reg.type(mobId), c, r, target, n, null); }
    public static int spawnNear(ServerLevel l, EntityType<?> t, Vec3 c, double r, ServerPlayer target, int n, String tag) {
        int done = 0;
        for (int i = 0; i < n; i++) {
            Vec3 s = spotAround(l, c, Math.min(3, r), r); if (s == null) continue;
            Entity e = t.create(l); if (e == null) continue;
            e.moveTo(s.x, s.y, s.z, l.random.nextFloat() * 360f, 0f);
            if (tag != null) e.addTag(tag);
            if (e instanceof Mob m) { m.finalizeSpawn(l, l.getCurrentDifficultyAt(m.blockPosition()), MobSpawnType.MOB_SUMMONED, null); if (target != null) m.setTarget(target); }
            l.addFreshEntity(e); done++;
        }
        return done;
    }
    /** Fulmine visivo (nessun incendio) + danno ai giocatori vicini. */
    public static void lightning(ServerLevel l, Vec3 at, float dmg, double radius, String effect) {
        net.minecraft.world.entity.LightningBolt b = EntityType.LIGHTNING_BOLT.create(l);
        if (b != null) { b.moveTo(at.x, at.y, at.z); b.setVisualOnly(true); l.addFreshEntity(b); }
        for (ServerPlayer p : l.getEntitiesOfClass(ServerPlayer.class, new AABB(at, at).inflate(radius))) {
            if (p.isCreative() || p.isSpectator()) continue;
            p.hurt(l.damageSources().lightningBolt(), dmg); if (effect != null) fx(p, effect, 100, 0);
        }
    }
    public static void hitPlayers(ServerLevel l, Vec3 at, double radius, float dmg, String effect) {
        for (ServerPlayer p : l.getEntitiesOfClass(ServerPlayer.class, new AABB(at, at).inflate(radius))) {
            if (p.isCreative() || p.isSpectator()) continue;
            if (dmg > 0) p.hurt(l.damageSources().magic(), dmg); if (effect != null) fx(p, effect, 100, 0);
        }
    }
    public static int surfaceY(ServerLevel l, int x, int z) { return l.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z); }
    private Fx() {}
}
