package com.claudemaster.horror.api;

import com.claudemaster.horror.entity.BossMob;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.item.Item;
import net.neoforged.bus.api.Event;
import net.neoforged.bus.api.ICancellableEvent;
import net.neoforged.neoforge.common.NeoForge;
import java.util.HashMap;
import java.util.Map;

/**
 * API pubblica per le altre mod (oltre ai tag dati horror_universe:valid_weapons, invalid_weapons, magic_items, assimilable, ai_threats...).
 * Eventi sul bus NeoForge: HitEvent (cancellabile, danno modificabile) e LevelEvent (inizio/fine livello boss).
 */
public final class HorrorApi {
    private static final Map<Item, Double> ATTACK = new HashMap<>();
    /** Dichiara l'attacco "da tooltip" di un'arma di un'altra mod (se i suoi attributi non bastano). */
    public static void setWeaponAttack(Item item, double attack) { ATTACK.put(item, attack); }
    public static Double attackOverride(Item item) { return ATTACK.get(item); }
    public static class HitEvent extends Event implements ICancellableEvent {
        private final BossMob boss; private final DamageSource source; private float damage;
        public HitEvent(BossMob b, DamageSource s, float d) { boss = b; source = s; damage = d; }
        public BossMob getBoss() { return boss; } public DamageSource getSource() { return source; }
        public float getDamage() { return damage; } public void setDamage(float d) { damage = d; }
    }
    public static class LevelEvent extends Event {
        private final String entity; private final int level; private final ServerPlayer player; private final boolean start, victory;
        public LevelEvent(String e, int l, ServerPlayer p, boolean s, boolean v) { entity = e; level = l; player = p; start = s; victory = v; }
        public String getEntity() { return entity; } public int getLevel() { return level; } public ServerPlayer getPlayer() { return player; }
        public boolean isStart() { return start; } public boolean isVictory() { return victory; }
    }
    public static HitEvent fireHit(BossMob b, DamageSource s, float d) { return NeoForge.EVENT_BUS.post(new HitEvent(b, s, d)); }
    public static void fireLevel(String e, int l, ServerPlayer p, boolean start, boolean victory) { NeoForge.EVENT_BUS.post(new LevelEvent(e, l, p, start, victory)); }
    private HorrorApi() {}
}
