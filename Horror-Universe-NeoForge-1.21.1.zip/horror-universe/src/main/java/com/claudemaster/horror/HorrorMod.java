package com.claudemaster.horror;

import com.mojang.logging.LogUtils;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import org.slf4j.Logger;

@Mod(HorrorMod.MODID)
public class HorrorMod {
    public static final String MODID = "horror_universe";
    public static final Logger LOG = LogUtils.getLogger();

    public static ResourceLocation id(String path) { return ResourceLocation.fromNamespaceAndPath(MODID, path); }

    public HorrorMod(IEventBus bus, ModContainer container) {
        Reg.init(bus);
        container.registerConfig(ModConfig.Type.COMMON, Config.SPEC);
        LOG.info("Minecraft Horror Universe caricato: {} mostri, {} oggetti", Content.MOBS.size(), Reg.I.size());
    }
}
