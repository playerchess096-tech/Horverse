package com.claudemaster.horror;

import com.claudemaster.horror.entity.*;
import com.claudemaster.horror.world.Director;
import com.claudemaster.horror.world.Realm;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.TagKey;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.EnderMan;
import net.minecraft.world.entity.projectile.ThrownEnderpearl;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.EntityHitResult;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.ServerChatEvent;
import net.neoforged.neoforge.event.entity.ProjectileImpactEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.player.AttackEntityEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.level.BlockEvent;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import java.util.Locale;

/** Eventi del gioco: tempo, abitudini del giocatore, blocchi speciali, perle rituali, chat, morte, respawn. */
@EventBusSubscriber(modid = HorrorMod.MODID)
public final class GameEvents {
    private static final TagKey<Item> MAGIC = TagKey.create(Registries.ITEM, HorrorMod.id("magic_items"));
    @SubscribeEvent public static void serverTick(ServerTickEvent.Post e) { MinecraftServer s = e.getServer(); TempBlocks.tick(s); Orbs.tick(s); Director.tick(s); }
    @SubscribeEvent public static void stopping(ServerStoppingEvent e) { TempBlocks.restoreAll(e.getServer()); Orbs.clear(); }
    @SubscribeEvent public static void commands(RegisterCommandsEvent e) { HorrorCommand.register(e.getDispatcher()); }

    @SubscribeEvent public static void playerTick(PlayerTickEvent.Post e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || p.tickCount % 20 != 0) return; ServerLevel l = p.serverLevel(); Saga s = Saga.get(l);
        Soul.tick(p);
        if (p.tickCount % 600 == 0 && l.dimension() == net.minecraft.world.level.Level.OVERWORLD) s.visit(p.getUUID(), p.blockPosition());
        boolean sl = p.isSleeping(); if (p.getPersistentData().getBoolean("hu_sleep") && !sl) com.claudemaster.horror.entity.Osservatore.react(p, "sleep"); p.getPersistentData().putBoolean("hu_sleep", sl);
        if (p.getY() < 45 && !l.canSeeSky(p.blockPosition())) { int m = s.ai(p.getUUID(), "h.mine_s", 1); if (m % 600 == 0) Osservatore.react(p, "mine"); }
        if (p.tickCount % 200 == 0 && l.getEntitiesOfClass(Custode.class, p.getBoundingBox().inflate(120), c -> c.fighting).isEmpty()) Custode.clearTemp(p);
        if (p.getPersistentData().getBoolean("hu_just_in")) { p.getPersistentData().putBoolean("hu_just_in", false); long away = l.getGameTime() - s.gl(p.getUUID(), "lastOut"); if (s.gl(p.getUUID(), "lastOut") > 0 && away > 48000) Osservatore.react(p, "return"); }
    }
    @SubscribeEvent public static void login(PlayerEvent.PlayerLoggedInEvent e) { if (e.getEntity() instanceof ServerPlayer p) { p.getPersistentData().putBoolean("hu_just_in", true); Custode.clearTemp(p); } }
    @SubscribeEvent public static void logout(PlayerEvent.PlayerLoggedOutEvent e) { if (e.getEntity() instanceof ServerPlayer p) { Saga.get(p.serverLevel()).sl(p.getUUID(), "lastOut", p.serverLevel().getGameTime()); Custode.clearTemp(p); } }
    @SubscribeEvent public static void respawn(PlayerEvent.PlayerRespawnEvent e) { if (e.getEntity() instanceof ServerPlayer p) Soul.onRespawn(p); }

    @SubscribeEvent public static void breakBlock(BlockEvent.BreakEvent e) {
        if (!(e.getPlayer() instanceof ServerPlayer p) || !(e.getLevel() instanceof ServerLevel l)) return; BlockState st = e.getState(); BlockPos pos = e.getPos();
        if (Marks.unusable(p.getMainHandItem())) { e.setCanceled(true); Fx.bar(p, "msg.corrupted"); return; }
        Habits.bump(l, p.getUUID(), "mine"); Senses_burst(p, 14);
        if (st.is(Blocks.DIAMOND_ORE) || st.is(Blocks.DEEPSLATE_DIAMOND_ORE)) Osservatore.react(p, "diamond"); if (st.is(Blocks.SPAWNER)) Osservatore.react(p, "spawner");
        if (st.is(Reg.block("glitch_block"))) for (Entity404 b : l.getEntitiesOfClass(Entity404.class, p.getBoundingBox().inflate(80), x -> x.fighting)) b.glitchBroken(l, p, pos);
        if (st.is(Reg.block("plague_heart")) && l.dimension() == Realm.R404) Realm.heartBroken(p);
        if (st.is(Reg.block("rune_node")) || st.is(Reg.block("staff_core"))) Mago.blockBroken(l, p, pos);
        if (st.is(Reg.block("steve_cache"))) SteveBoss.cacheBroken(l, p, pos);
        if (st.is(Reg.block("rusty_barrel")) && l.random.nextInt(100) < 8) Fx.spawnNear(l, Reg.type("chest_mimic"), net.minecraft.world.phys.Vec3.atCenterOf(pos), 2, p, 1, null);
    }
    private static void Senses_burst(ServerPlayer p, double r) { com.claudemaster.horror.ai.Senses.burst(p, r, 40); }
    @SubscribeEvent public static void place(BlockEvent.EntityPlaceEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || !(e.getLevel() instanceof ServerLevel l)) return; Habits.bump(l, p.getUUID(), "build"); Senses_burst(p, 10);
        if (e.getPlacedBlock().is(Reg.block("fate_statue"))) { Saga.get(l).addStatue(e.getPos()); Fx.msg(p, "msg.statue_placed", Entity404.countStatues(l, p)); }
    }
    @SubscribeEvent public static void rightBlock(PlayerInteractEvent.RightClickBlock e) {
        if (e.getLevel().isClientSide || e.getHand() != InteractionHand.MAIN_HAND || !(e.getEntity() instanceof ServerPlayer p)) return; ServerLevel l = p.serverLevel(); BlockState st = l.getBlockState(e.getPos());
        for (int i = 0; i < 4; i++) if (st.is(Reg.block("sigil_" + "abcd".charAt(i)))) { Osservatore.sigilPressed(l, p, i); e.setCanceled(true); return; }
        if (st.is(Reg.block("observer_mark"))) { Osservatore.markFound(l, p, e.getPos()); e.setCanceled(true); return; }
        if (st.is(Reg.block("ritual_altar")) && e.getItemStack().is(Items.ENDER_EYE) && !l.getEntitiesOfClass(EnderMan.class, p.getBoundingBox().inflate(8)).isEmpty()) {
            Saga s = Saga.get(l); int lv = s.level(p.getUUID(), Ent.CUSTODE); if (lv < 3 || !Director.unlocked(l, Ent.CUSTODE, 1)) { Fx.bar(p, "msg.immune"); return; }   // dal livello 3 in poi il rituale può essere tentato (non autorizzato fino al livello 4)
            e.getItemStack().shrink(1); Custode c = (Custode) Reg.type("custode").create(l); net.minecraft.world.phys.Vec3 sp = Fx.spotAround(l, p.position(), 6, 10);
            if (c != null && sp != null) { c.moveTo(sp.x, sp.y, sp.z); l.addFreshEntity(c); c.startFight(p, 5); } e.setCanceled(true);
        }
    }
    @SubscribeEvent public static void rightItem(PlayerInteractEvent.RightClickItem e) {
        ItemStack s = e.getItemStack(); if (Marks.unusable(s) && !e.getLevel().isClientSide) { e.setCanceled(true); if (e.getEntity() instanceof ServerPlayer p) Fx.bar(p, "msg.corrupted"); return; }
        if (e.getEntity().hasEffect(Reg.fx("rune_seal")) && s.is(MAGIC) && !e.getLevel().isClientSide) { e.setCanceled(true); if (e.getEntity() instanceof ServerPlayer p) Fx.bar(p, "msg.immune"); }
    }
    @SubscribeEvent public static void attack(AttackEntityEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        if (Marks.unusable(p.getMainHandItem())) { e.setCanceled(true); Fx.bar(p, "msg.corrupted"); return; }
        Habits.bump(p.serverLevel(), p.getUUID(), "melee"); Senses_burst(p, 12);
    }
    @SubscribeEvent public static void incoming(LivingIncomingDamageEvent e) {
        var ent = e.getEntity(); float a = e.getAmount();
        if (ent.hasEffect(Reg.fx("corruption"))) a *= 1f + 0.2f * (ent.getEffect(Reg.fx("corruption")).getAmplifier() + 1);
        if (ent.hasEffect(Reg.fx("green_hearts"))) a *= 1.3f;
        e.setAmount(a);
        if (ent instanceof ServerPlayer p && p.getHealth() - a <= 0f && Entity404.rescueToRealm(p)) { e.setCanceled(true); return; }
        if (e.getSource().getEntity() instanceof ServerPlayer att && e.getSource().is(net.minecraft.tags.DamageTypeTags.IS_PROJECTILE)) Habits.bump(att.serverLevel(), att.getUUID(), "ranged");
    }
    @SubscribeEvent public static void death(LivingDeathEvent e) { if (e.getEntity() instanceof ServerPlayer p) { Entity404.onPlayerDeath(p); Osservatore.react(p, "death"); } }
    @SubscribeEvent public static void impact(ProjectileImpactEvent e) {
        if (!(e.getProjectile() instanceof ThrownEnderpearl pearl) || pearl.level().isClientSide || !pearl.getItem().is(Reg.item("ritual_pearl"))) return;
        if (e.getRayTraceResult() instanceof EntityHitResult eh && eh.getEntity() instanceof Custode c && pearl.getOwner() instanceof ServerPlayer p) { boolean ok = c.onPearlHit(p); e.setCanceled(true); pearl.discard(); if (!ok) Fx.bar(p, "msg.immune"); }
    }
    @SubscribeEvent public static void chat(ServerChatEvent e) {
        ServerPlayer p = e.getPlayer(); ServerLevel l = p.serverLevel(); String t = e.getRawText().toLowerCase(Locale.ROOT);
        for (Entity404 c : l.getEntitiesOfClass(Entity404.class, p.getBoundingBox().inflate(40), x -> x.fighting && x.bossLevel == 8)) c.onChat(p, e.getRawText());
        if (t.matches(".*(stupid|idiot|muori|noob|schifo|odio).*") && !l.getEntitiesOfClass(Corrotto.class, p.getBoundingBox().inflate(40)).isEmpty()) { Saga.get(l).addRel(p.getUUID(), Ent.CORROTTO, -10); Fx.say(p, Ent.CORROTTO, 2); }
        else if (t.matches(".*(grazie|amico|ti aiuto|thanks|friend|sorry|scusa).*") && !l.getEntitiesOfClass(Corrotto.class, p.getBoundingBox().inflate(40)).isEmpty()) { Saga.get(l).addRel(p.getUUID(), Ent.CORROTTO, 6); Fx.say(p, Ent.CORROTTO, 1); }
    }
    private GameEvents() {}
}
