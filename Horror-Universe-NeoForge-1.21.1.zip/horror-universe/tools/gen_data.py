# -*- coding: utf-8 -*-
import os, sys, json, random
sys.path.insert(0, os.path.dirname(__file__))
from content import *
import items as IT
from nbtw import St
from gen_assets import wj, RES, D, A, MOBS, BOSSDEF
HU = 'horror_universe:'
def ing(x): return {'item': x if ':' in x else HU + x}
def res(x, n=1): return {'id': x if ':' in x else HU + x, 'count': n}
def shaped(name, pat, key, result, n=1):
    wj(D + '/recipe/%s.json' % name, {'type': 'minecraft:crafting_shaped', 'category': 'misc', 'pattern': pat, 'key': {k: ing(v) for k, v in key.items()}, 'result': res(result, n)})
def shapeless(name, ings, result, n=1):
    wj(D + '/recipe/%s.json' % name, {'type': 'minecraft:crafting_shapeless', 'category': 'misc', 'ingredients': [ing(i) for i in ings], 'result': res(result, n)})
def cook(name, kind, src, result, xp, t):
    wj(D + '/recipe/%s.json' % name, {'type': 'minecraft:' + kind, 'category': 'misc', 'ingredient': ing(src), 'result': {'id': HU + result}, 'experience': xp, 'cookingtime': t})
def recipes():
    cook('pale_ingot_smelt', 'smelting', 'pale_ore', 'pale_ingot', 0.7, 200); cook('pale_ingot_smelt_deep', 'smelting', 'deepslate_pale_ore', 'pale_ingot', 0.7, 200)
    cook('pale_ingot_blast', 'blasting', 'pale_ore', 'pale_ingot', 0.7, 100); cook('pale_ingot_blast_deep', 'blasting', 'deepslate_pale_ore', 'pale_ingot', 0.7, 100)
    shaped('pale_block', ['III', 'III', 'III'], {'I': 'pale_ingot'}, 'pale_block'); shapeless('pale_ingot_from_block', ['pale_block'], 'pale_ingot', 9)
    shaped('plague_block', ['III', 'III', 'III'], {'I': 'plague_ingot'}, 'plague_block'); shapeless('plague_ingot_from_block', ['plague_block'], 'plague_ingot', 9)
    shapeless('pale_dust', ['pale_stone'], 'pale_dust', 2); shapeless('plague_ingot', ['pale_ingot', 'plague_crystal', 'green_fragment'], 'plague_ingot')
    for t in ('pale', 'plague'):
        m = t + '_ingot'; s = 'minecraft:stick'
        shaped(t + '_pickaxe', ['III', ' S ', ' S '], {'I': m, 'S': s}, t + '_pickaxe'); shaped(t + '_axe', ['II', 'IS', ' S'], {'I': m, 'S': s}, t + '_axe')
        shaped(t + '_shovel', ['I', 'S', 'S'], {'I': m, 'S': s}, t + '_shovel'); shaped(t + '_hoe', ['II', ' S', ' S'], {'I': m, 'S': s}, t + '_hoe')
        shaped(t + '_helmet', ['III', 'I I'], {'I': m}, t + '_helmet'); shaped(t + '_chestplate', ['I I', 'III', 'III'], {'I': m}, t + '_chestplate')
        shaped(t + '_leggings', ['III', 'I I', 'I I'], {'I': m}, t + '_leggings'); shaped(t + '_boots', ['I I', 'I I'], {'I': m}, t + '_boots')
        shaped(t + '_sword', ['I', 'I', 'S'], {'I': m, 'S': s}, t + '_sword')
    shaped('plague_blade', [' C ', ' P ', ' S '], {'C': 'plague_core', 'P': 'plague_ingot', 'S': 'minecraft:stick'}, 'plague_blade')
    wj(D + '/recipe/lord_blade.json', {'type': 'minecraft:smithing_transform', 'template': ing('minecraft:netherite_upgrade_smithing_template'), 'base': ing('plague_blade'), 'addition': ing('lord_core'), 'result': res('lord_blade')})
    shaped('reaper_scythe', ['DDD', '  S', ' S '], {'D': 'dark_shard', 'S': 'minecraft:stick'}, 'reaper_scythe'); shaped('pale_spear', ['  I', ' S ', 'S  '], {'I': 'pale_ingot', 'S': 'minecraft:stick'}, 'pale_spear')
    shaped('arcane_dagger', ['R', 'S'], {'R': 'rune_shard', 'S': 'minecraft:stick'}, 'arcane_dagger'); shaped('ruin_hammer', ['III', 'ISI', ' S '], {'I': 'pale_ingot', 'S': 'minecraft:stick'}, 'ruin_hammer')
    shaped('eden_fruit', ['AAA', 'AAA', 'AAA'], {'A': 'minecraft:golden_apple'}, 'eden_fruit')
    shaped('anti_dark_artifact', ['GAG', 'ASA', 'GAG'], {'G': 'minecraft:glowstone_dust', 'A': 'minecraft:amethyst_shard', 'S': 'minecraft:gold_ingot'}, 'anti_dark_artifact')
    shapeless('purifying_salt', ['minecraft:quartz', 'minecraft:glowstone_dust', 'minecraft:bone_meal'], 'purifying_salt', 2); shapeless('ritual_ash', ['minecraft:charcoal', 'minecraft:bone_meal'], 'ritual_ash', 2)
    shapeless('ritual_pearl', ['minecraft:ender_pearl', 'ritual_ash'], 'ritual_pearl'); shapeless('plague_vial', ['minecraft:glass_bottle', 'plague_crystal', 'purifying_salt'], 'plague_vial')
    shaped('soul_seal', ['GSG', 'SDS', 'GSG'], {'G': 'minecraft:gold_nugget', 'S': 'soul_fragment', 'D': 'minecraft:diamond'}, 'soul_seal')
    shaped('fate_statue', ['OPO', 'PCP', 'OPO'], {'O': 'minecraft:obsidian', 'P': 'plague_ingot', 'C': 'plague_crystal'}, 'fate_statue')
    shaped('recovery_totem', ['GSG', 'STS', 'GSG'], {'G': 'minecraft:gold_ingot', 'S': 'soul_fragment', 'T': 'minecraft:totem_of_undying'}, 'recovery_totem')
    shapeless('key_realm', ['plague_crystal', 'minecraft:ender_eye', 'green_fragment'], 'key_realm'); shapeless('key_vault', ['pale_ingot', 'minecraft:ender_eye', 'white_symbol'], 'key_vault')
    shaped('ritual_altar', ['AAA', 'OOO', 'OOO'], {'A': 'ritual_ash', 'O': 'minecraft:obsidian'}, 'ritual_altar'); shaped('rune_staff', ['  R', ' S ', 'S  '], {'R': 'rune_shard', 'S': 'minecraft:stick'}, 'rune_staff')
    shapeless('pale_bread', ['minecraft:wheat', 'minecraft:wheat', 'minecraft:wheat', 'pale_dust'], 'pale_bread'); shapeless('white_candle', ['minecraft:candle', 'pale_dust'], 'white_candle')
    shapeless('observer_lens', ['minecraft:spyglass', 'observer_eye'], 'observer_lens'); shapeless('mage_pact', ['minecraft:paper', 'arcane_dust', 'rune_shard'], 'mage_pact')
    shapeless('illusion_block', ['pale_stone', 'arcane_dust'], 'illusion_block', 2)
# ---------------------------------------------------------------- loot
def entry(item, w=1, lo=1, hi=1):
    e = {'type': 'minecraft:item', 'name': item if ':' in item else HU + item, 'weight': w}
    if hi > 1: e['functions'] = [{'function': 'minecraft:set_count', 'count': {'type': 'minecraft:uniform', 'min': lo, 'max': hi}}]
    return e
def chest(name, rolls, ents):
    wj(D + '/loot_table/chests/%s.json' % name, {'type': 'minecraft:chest', 'pools': [{'rolls': {'type': 'minecraft:uniform', 'min': rolls[0], 'max': rolls[1]}, 'entries': ents}]})
OWN = {'custode': [('pale_dust', 0.6, 2), ('white_symbol', 0.12, 1)], 'corrotto': [('dark_shard', 0.45, 2), ('soul_fragment', 0.2, 1)], 'e404': [('green_fragment', 0.5, 2), ('plague_crystal', 0.2, 1)],
       'mago': [('arcane_dust', 0.55, 2), ('rune_shard', 0.2, 1)], 'steve': [('steel_ingot', 0.4, 2), ('steve_token', 0.12, 1)], 'neutral': [('white_symbol', 0.08, 1)], 'hostile': [('dark_shard', 0.3, 1), ('pale_dust', 0.2, 2)]}
SPECIAL = {'reaper': [('reaper_scythe', 1.0, 1), ('dark_shard', 1.0, 3)], 'hollow_giant': [('pale_ingot', 1.0, 4)], 'statue_queen': [('soul_fragment', 1.0, 2), ('dark_shard', 1.0, 3)], 'portal_guardian': [('key_realm', 1.0, 1), ('void_essence', 1.0, 1)],
           'light_eater': [('void_essence', 1.0, 2)], 'runic_colossus': [('rune_shard', 1.0, 4), ('ancient_rune_1', 0.3, 1)], 'meteor_lord': [('green_fragment', 1.0, 3)], 'nameless_knight': [('steve_token', 1.0, 2), ('observer_eye', 0.3, 1)],
           'corrupt_pup': [('lord_core', 1.0, 1), ('plague_crystal', 1.0, 3)], 'staff_keeper': [('ancient_rune_2', 1.0, 1), ('rune_shard', 1.0, 2)], 'major_demon': [('plague_core', 0.5, 1), ('plague_crystal', 1.0, 2)], 'heart_guardian': [('plague_ingot', 1.0, 2)],
           'ritual_enderman': [('void_essence', 1.0, 1), ('ritual_pearl', 1.0, 2)], 'barrier_pylon': [], 'illusion_double': [], 'e404_clone_ally': []}
def loot():
    chest('chapel', (2, 4), [entry('pale_dust', 10, 2, 5), entry('white_symbol', 4), entry('minecraft:golden_apple', 3), entry('scroll_custode', 2), entry('ritual_ash', 6, 1, 3), entry('minecraft:gold_ingot', 6, 1, 4)])
    chest('plague', (2, 4), [entry('green_fragment', 10, 1, 4), entry('plague_crystal', 5, 1, 2), entry('scroll_e404', 2), entry('minecraft:rotten_flesh', 8, 2, 6), entry('plague_vial', 1)])
    chest('rune', (2, 5), [entry('arcane_dust', 10, 2, 5), entry('rune_shard', 5, 1, 3), entry('mage_pact', 2), entry('scroll_mago', 2), entry('minecraft:amethyst_shard', 8, 2, 6), entry('minecraft:lapis_lazuli', 8, 2, 8)])
    chest('steve', (3, 6), [entry('steel_ingot', 8, 1, 4), entry('minecraft:iron_ingot', 10, 2, 6), entry('minecraft:arrow', 8, 6, 16), entry('minecraft:golden_apple', 2), entry('steve_token', 3), entry('scroll_steve', 2), entry('minecraft:ender_pearl', 2)])
    chest('bunker', (2, 5), [entry('minecraft:coal', 10, 2, 8), entry('dark_shard', 5, 1, 2), entry('minecraft:iron_nugget', 10, 3, 9), entry('scroll_osservatore', 1), entry('observer_eye', 1), entry('minecraft:redstone', 6, 2, 6)])
    chest('shrine', (2, 4), [entry('pale_ingot', 6, 1, 3), entry('minecraft:diamond', 2), entry('rune_shard', 4, 1, 2), entry('scroll_corrotto', 3), entry('purifying_salt', 4, 1, 2), entry('pale_bread', 6, 1, 3)])
    chest('observer', (1, 2), [entry('observer_eye', 2), entry('scroll_osservatore', 4), entry('minecraft:clock', 3), entry('minecraft:spyglass', 3)])
    wj(D + '/loot_table/blocks/rusty_barrel.json', {'type': 'minecraft:block', 'pools': [{'rolls': {'type': 'minecraft:uniform', 'min': 1, 'max': 3}, 'entries': [entry('minecraft:iron_nugget', 8, 1, 4), entry('minecraft:coal', 6, 1, 3), entry('dark_shard', 3), entry('minecraft:rotten_flesh', 5, 1, 3), entry('minecraft:bread', 3), entry('steel_ingot', 1)]}]})
    for b in IT.B:
        if b['drop'] == 'self':
            wj(D + '/loot_table/blocks/%s.json' % b['id'], {'type': 'minecraft:block', 'pools': [{'rolls': 1, 'bonus_rolls': 0, 'conditions': [{'condition': 'minecraft:survives_explosion'}], 'entries': [{'type': 'minecraft:item', 'name': HU + b['id']}]}]})
    for m in MOBS:
        drops = SPECIAL.get(m['id'], OWN.get(m['owner'], []))
        pools = []
        for (it, ch, mx) in drops:
            conds = [] if ch >= 1.0 else [{'condition': 'minecraft:random_chance', 'chance': ch}]
            pools.append({'rolls': 1, 'conditions': conds, 'entries': [entry(it, 1, 1, mx)]})
        wj(D + '/loot_table/entities/%s.json' % m['id'], {'type': 'minecraft:entity', 'pools': pools})
    bossloot = {'custode': [('pale_dust', 1.0, 3)], 'corrotto': [('dark_shard', 1.0, 3)], 'entity404': [('green_fragment', 1.0, 4)], 'mago': [('arcane_dust', 1.0, 4)], 'steve': [('steel_ingot', 1.0, 4)], 'osservatore': [('observer_eye', 1.0, 1)]}
    for b, ds in bossloot.items():
        wj(D + '/loot_table/entities/%s.json' % b, {'type': 'minecraft:entity', 'pools': [{'rolls': 1, 'entries': [entry(i, 1, 1, mx)]} for (i, c, mx) in ds]})
# ---------------------------------------------------------------- tag
def tags():
    mine = [b['id'] for b in IT.B if b['tool'] == 'pickaxe']; axe = [b['id'] for b in IT.B if b['tool'] == 'axe']
    wj(RES + '/data/minecraft/tags/block/mineable/pickaxe.json', {'values': [HU + i for i in mine]}); wj(RES + '/data/minecraft/tags/block/mineable/axe.json', {'values': [HU + i for i in axe]})
    wj(RES + '/data/minecraft/tags/block/needs_iron_tool.json', {'values': [HU + b['id'] for b in IT.B if b['lvl'] == 'iron']}); wj(RES + '/data/minecraft/tags/block/needs_diamond_tool.json', {'values': [HU + b['id'] for b in IT.B if b['lvl'] == 'diamond']})
    wj(RES + '/data/minecraft/tags/block/needs_stone_tool.json', {'values': [HU + b['id'] for b in IT.B if b['lvl'] == 'stone']})
    weap = ['plague_blade', 'lord_blade', 'reaper_scythe', 'pale_spear', 'arcane_dagger', 'ruin_hammer', 'pale_sword', 'plague_sword', 'pale_axe', 'plague_axe']
    wj(D + '/tags/item/valid_weapons.json', {'values': [HU + w for w in weap]}); wj(D + '/tags/item/invalid_weapons.json', {'values': []})
    wj(D + '/tags/item/magic_items.json', {'values': [HU + w for w in ['rune_staff', 'arcane_dagger', 'mage_pact', 'ancient_rune_1', 'ancient_rune_2', 'ancient_rune_3', 'ancient_rune_4', 'ancient_rune_5', 'rune_shard', 'arcane_dust']] + ['minecraft:enchanted_book', 'minecraft:nether_star', 'minecraft:ender_eye', 'minecraft:totem_of_undying']})
    wj(D + '/tags/item/steal_blacklist.json', {'values': [HU + 'recovery_totem', HU + 'soul_seal']})
    wj(D + '/tags/entity_type/custode_summons.json', {'values': ['minecraft:zombie', 'minecraft:skeleton', 'minecraft:spider', 'minecraft:husk', 'minecraft:stray', 'minecraft:vindicator']})
    wj(D + '/tags/entity_type/assimilable.json', {'values': ['minecraft:wither', 'minecraft:warden', 'minecraft:elder_guardian', {'id': '#c:bosses', 'required': False}]})
    wj(D + '/tags/entity_type/no_assimilate.json', {'values': ['minecraft:ender_dragon', 'minecraft:player']})
    wj(D + '/tags/entity_type/ai_threats.json', {'values': ['minecraft:iron_golem', 'minecraft:ravager', 'minecraft:warden', 'minecraft:wither', {'id': '#c:bosses', 'required': False}]})
    wj(D + '/tags/entity_type/ai_ignored.json', {'values': ['minecraft:armor_stand', 'minecraft:item_frame', 'minecraft:villager']})
# ---------------------------------------------------------------- worldgen
def biome(name, temp, down, sky, fog, water, wfog, grass, foliage, amb, mob, spawns, carve=True, part=None):
    eff = {'sky_color': sky, 'fog_color': fog, 'water_color': water, 'water_fog_color': wfog, 'ambient_sound': HU + amb, 'mood_sound': {'sound': HU + mob, 'tick_delay': 6000, 'block_search_extent': 8, 'offset': 2.0}}
    if grass is not None: eff['grass_color'] = grass; eff['foliage_color'] = foliage
    if part: eff['particle'] = {'probability': 0.004, 'options': {'type': part}}
    sp = {k: [] for k in ('monster', 'creature', 'ambient', 'water_creature', 'underground_water_creature', 'water_ambient', 'misc', 'axolotls')}
    for cat, lst in spawns.items(): sp[cat] = [{'type': HU + t, 'weight': w, 'minCount': 1, 'maxCount': 2} for (t, w) in lst]
    wj(D + '/worldgen/biome/%s.json' % name, {'has_precipitation': False, 'temperature': temp, 'downfall': down, 'effects': eff,
        'carvers': {'air': ['minecraft:cave', 'minecraft:cave_extra_underground', 'minecraft:canyon']} if carve else {}, 'features': [[] for _ in range(11)], 'spawners': sp, 'spawn_costs': {}})
def dimtype(name, fixed, flat):
    t = {'ultrawarm': False, 'natural': False, 'coordinate_scale': 1.0, 'has_skylight': True, 'has_ceiling': False, 'ambient_light': 0.06, 'monster_spawn_light_level': {'type': 'minecraft:uniform', 'min_inclusive': 0, 'max_inclusive': 7},
         'monster_spawn_block_light_limit': 0, 'piglin_safe': False, 'bed_works': False, 'respawn_anchor_works': False, 'has_raids': False, 'logical_height': 256 if flat else 384, 'min_y': 0 if flat else -64, 'height': 256 if flat else 384,
         'infiniburn': '#minecraft:infiniburn_overworld', 'effects': 'minecraft:overworld', 'fixed_time': fixed}
    wj(D + '/dimension_type/%s.json' % name, t)
def worldgen():
    biome('plague_wastes', 0.6, 0.0, 0x1a8f3a, 0x2fbf4a, 0x3fbf5a, 0x0a4a1a, 0x3a9a3a, 0x2a7a2a, 'ambient.plague', 'ambient.dark', {'monster': [('green_zombie', 30), ('corrupt_skeleton', 20), ('plague_hunter', 10), ('infected_creeper', 12)]}, False, 'minecraft:spore_blossom_air')
    biome('pale_barrens', 0.2, 0.0, 0xcfd2da, 0xe0e0e6, 0xb8c4d0, 0x5a6a7a, 0xe4e4dc, 0xd0d0c4, 'ambient.pale', 'ambient.void', {'monster': [('faceless_wanderer', 6), ('night_hunter', 10), ('white_eyed_zombie', 8)], 'creature': [('pale_deer', 10)]}, True, 'minecraft:white_ash')
    biome('shadow_marsh', 0.4, 0.9, 0x1a1a2a, 0x2a2438, 0x2a2a4a, 0x10101e, 0x3a3048, 0x2a2438, 'ambient.dark', 'ambient.watch', {'monster': [('shadow_spider', 12), ('light_devourer', 3), ('living_statue', 4), ('corridor_specter', 5)]}, True, 'minecraft:ash')
    biome('arcane_meadow', 0.7, 0.5, 0x7a5aff, 0xb090ff, 0x8a6aff, 0x3a2a7a, 0x9a7ad0, 0x7a5ab0, 'ambient.arcane', 'ambient.ritual', {'monster': [('illusory_specter', 8), ('mage_raven', 6), ('rune_knight', 4)], 'creature': [('clue_raven', 8)]}, True, 'minecraft:enchant')
    dimtype('entity_404', 18000, True); dimtype('pale_hollow', 13000, False)
    wj(D + '/dimension/entity_404.json', {'type': HU + 'entity_404', 'generator': {'type': 'minecraft:flat', 'settings': {'biome': HU + 'plague_wastes', 'features': False, 'lakes': False,
        'layers': [{'block': 'minecraft:bedrock', 'height': 1}, {'block': 'minecraft:stone', 'height': 59}, {'block': HU + 'plague_soil', 'height': 4}]}}})
    P = lambda t: {'temperature': t, 'humidity': [-2.0, 2.0], 'continentalness': [-2.0, 2.0], 'erosion': [-2.0, 2.0], 'depth': [-2.0, 2.0], 'weirdness': [-2.0, 2.0], 'offset': 0.0}
    wj(D + '/dimension/pale_hollow.json', {'type': HU + 'pale_hollow', 'generator': {'type': 'minecraft:noise', 'settings': 'minecraft:overworld', 'biome_source': {'type': 'minecraft:multi_noise', 'biomes': [
        {'biome': HU + 'pale_barrens', 'parameters': P([-2.0, -0.35])}, {'biome': HU + 'shadow_marsh', 'parameters': P([-0.35, 0.35])}, {'biome': HU + 'arcane_meadow', 'parameters': P([0.35, 2.0])}]}}})
    # minerale
    wj(D + '/worldgen/configured_feature/pale_ore.json', {'type': 'minecraft:ore', 'config': {'discard_chance_on_air_exposure': 0.0, 'size': 7, 'targets': [
        {'state': {'Name': HU + 'pale_ore'}, 'target': {'predicate_type': 'minecraft:tag_match', 'tag': 'minecraft:stone_ore_replaceables'}}, {'state': {'Name': HU + 'deepslate_pale_ore'}, 'target': {'predicate_type': 'minecraft:tag_match', 'tag': 'minecraft:deepslate_ore_replaceables'}}]}})
    wj(D + '/worldgen/placed_feature/pale_ore.json', {'feature': HU + 'pale_ore', 'placement': [{'type': 'minecraft:count', 'count': 5}, {'type': 'minecraft:in_square'}, {'type': 'minecraft:height_range', 'height': {'type': 'minecraft:uniform', 'min_inclusive': {'absolute': -60}, 'max_inclusive': {'absolute': 40}}}, {'type': 'minecraft:biome'}]})
    wj(D + '/neoforge/biome_modifier/add_pale_ore.json', {'type': 'neoforge:add_features', 'biomes': '#minecraft:is_overworld', 'features': HU + 'pale_ore', 'step': 'underground_ores'})
    sp = [{'type': HU + m['id'], 'weight': m['weight'], 'minCount': 1, 'maxCount': 1} for m in MOBS if m['weight'] > 0 and m['owner'] in ('neutral', 'hostile')]
    wj(D + '/neoforge/biome_modifier/add_mob_spawns.json', {'type': 'neoforge:add_spawns', 'biomes': '#minecraft:is_overworld', 'spawners': sp})
# ---------------------------------------------------------------- strutture
STRUCTS = {}
def S_chapel():
    s = St(11, 9, 17); s.fill(0, 0, 0, 10, 0, 16, HU + 'pale_bricks'); r = random.Random(1)
    for z in range(17):
        for y in range(1, 7):
            for x in (0, 10):
                if y in (3, 4) and z % 4 == 2: s.set(x, y, z, 'minecraft:glass_pane', {'east': 'false', 'north': 'false', 'south': 'false', 'waterlogged': 'false', 'west': 'false'})
                else: s.set(x, y, z, HU + 'pale_stone')
    for y in range(1, 8):
        for x in range(1, 10):
            if y <= 6: s.set(x, y, 16, HU + 'pale_stone')
            if y <= 6 and not (4 <= x <= 6 and y <= 4): s.set(x, y, 0, HU + 'pale_bricks')
    for x in range(0, 11):
        for z in range(0, 17):
            if r.random() > 0.35: s.set(x, 7, z, 'minecraft:stone_brick_slab', {'type': 'bottom', 'waterlogged': 'false'})
    for z in (4, 6, 8, 10):
        for x in (2, 3, 4, 6, 7, 8): s.set(x, 1, z, 'minecraft:quartz_stairs', {'facing': 'north', 'half': 'bottom', 'shape': 'straight', 'waterlogged': 'false'})
    s.set(5, 1, 13, HU + 'ritual_altar'); s.set(3, 1, 14, HU + 'white_candle'); s.set(7, 1, 14, HU + 'white_candle'); s.chest(5, 1, 15, 'chapel'); s.ent('pale_guardian', 3, 1, 12); s.ent('pale_guardian', 7, 1, 12); return s
def S_circle():
    s = St(19, 5, 19); import math
    for x in range(19):
        for z in range(19):
            d = math.hypot(x - 9, z - 9)
            if d <= 8.6: s.set(x, 0, z, 'minecraft:obsidian' if (int(d) % 2 == 0) else 'minecraft:crying_obsidian' if (x + z) % 5 == 0 else HU + 'dark_stone')
    for k in range(8):
        a = k * math.pi / 4; x = int(9 + 7 * math.cos(a)); z = int(9 + 7 * math.sin(a)); s.fill(x, 1, z, x, 3, z, 'minecraft:polished_blackstone'); s.set(x, 4, z, 'minecraft:end_rod', {'facing': 'up'})
    s.set(9, 1, 9, HU + 'ritual_altar'); return s
def S_garden():
    s = St(21, 6, 21); r = random.Random(2)
    for x in range(21):
        for z in range(21):
            if r.random() < 0.35: s.set(x, 0, z, HU + 'dark_stone')
            if x in (0, 20) or z in (0, 20):
                if r.random() > 0.2: s.set(x, 1, z, 'minecraft:mossy_stone_bricks')
    for (x, z) in ((5, 5), (15, 5), (5, 15), (15, 15), (10, 10), (10, 4), (4, 10), (16, 10), (10, 16)):
        s.fill(x, 1, z, x, 3, z, HU + 'statue_stone'); s.set(x - 1, 2, z, 'minecraft:stone_brick_slab', {'type': 'bottom', 'waterlogged': 'false'}); s.set(x + 1, 2, z, 'minecraft:stone_brick_slab', {'type': 'bottom', 'waterlogged': 'false'})
    s.set(2, 1, 2, HU + 'corrupted_sign'); s.set(18, 1, 18, HU + 'corrupted_sign'); s.ent('statue_guardian', 10, 1, 8); s.ent('living_statue', 5, 1, 12); s.ent('living_statue', 16, 1, 12); return s
def S_obelisk():
    s = St(9, 16, 9); s.fill(0, 0, 0, 8, 0, 8, HU + 'plague_soil')
    for y in range(1, 15):
        w = 1 if y < 9 else 0
        s.fill(4 - w, y, 4 - w, 4 + w, y, 4 + w, HU + ('plague_flesh' if y % 3 else 'plague_vein'))
    s.set(4, 15, 4, HU + 'plague_vein')
    for (x, z) in ((1, 1), (7, 1), (1, 7), (7, 7)): s.fill(x, 1, z, x, 2, z, HU + 'plague_vein')
    s.chest(6, 1, 4, 'plague', 'west'); s.ent('green_mimic', 2, 1, 4); return s
def S_tower():
    s = St(9, 23, 9)
    for y in range(0, 21):
        for x in range(9):
            for z in range(9):
                if x in (0, 8) or z in (0, 8):
                    if y % 5 == 4 and x % 4 == 0 and z % 4 == 0: s.set(x, y, z, HU + 'rune_block')
                    elif y % 7 == 3 and (x == 4 or z == 4): s.set(x, y, z, 'minecraft:glass_pane', {'east': 'false', 'north': 'false', 'south': 'false', 'waterlogged': 'false', 'west': 'false'})
                    else: s.set(x, y, z, HU + 'pale_bricks')
    for y in range(1, 20): s.set(1, y, 4, 'minecraft:ladder', {'facing': 'east', 'waterlogged': 'false'})
    s.fill(0, 20, 0, 8, 20, 8, HU + 'pale_stone'); s.set(1, 20, 4, 'minecraft:air')
    s.fill(0, 21, 0, 8, 21, 8, 'minecraft:amethyst_block'); s.fill(1, 21, 1, 7, 21, 7, 'minecraft:air'); s.chest(6, 21, 4, 'rune', 'west')
    s.set(4, 0, 0, 'minecraft:air'); s.set(4, 1, 0, 'minecraft:air'); s.ent('runic_golem', 4, 1, 4); return s
def S_outpost():
    s = St(17, 7, 17); s.fill(0, 0, 0, 16, 0, 16, 'minecraft:gravel')
    for i in range(17):
        for y in (1, 2, 3):
            for (x, z) in ((i, 0), (i, 16), (0, i), (16, i)):
                if not (z == 0 and 7 <= x <= 9 and y <= 2): s.set(x, y, z, 'minecraft:cobblestone')
    for (x0, z0) in ((3, 3), (11, 3)):
        s.fill(x0, 1, z0, x0 + 2, 1, z0 + 3, 'minecraft:white_wool'); s.fill(x0, 2, z0, x0 + 2, 2, z0 + 3, 'minecraft:white_wool'); s.fill(x0 + 1, 1, z0 + 1, x0 + 1, 1, z0 + 2, 'minecraft:air')
    s.set(8, 1, 8, 'minecraft:campfire', {'facing': 'north', 'lit': 'true', 'signal_fire': 'false', 'waterlogged': 'false'}); s.chest(4, 1, 5, 'steve', 'south'); s.chest(12, 1, 5, 'steve', 'south')
    s.set(2, 1, 13, HU + 'steve_cache'); s.set(14, 1, 13, HU + 'steve_cache'); s.set(8, 1, 14, HU + 'steve_cache')
    for (x, z) in ((7, 3), (9, 3), (8, 4)): s.set(x, 1, z, 'minecraft:cobweb')
    s.ent('base_guardian', 6, 1, 6); s.ent('base_guardian', 10, 1, 6); s.ent('mech_sentinel', 8, 1, 12); return s
def S_hut():
    s = St(7, 6, 7); s.fill(0, 0, 0, 6, 0, 6, 'minecraft:oak_planks'); s.shell(0, 0, 0, 6, 4, 6, 'minecraft:spruce_planks'); s.fill(1, 1, 1, 5, 3, 5, 'minecraft:air'); s.fill(1, 0, 1, 5, 0, 5, 'minecraft:oak_planks')
    for x in range(-1, 8):
        s.set(x, 5, 3, 'minecraft:dark_oak_planks')
    s.fill(0, 4, 0, 6, 4, 6, 'minecraft:dark_oak_planks'); s.set(3, 1, 0, 'minecraft:oak_door', {'facing': 'south', 'half': 'lower', 'hinge': 'left', 'open': 'false', 'powered': 'false'}); s.set(3, 2, 0, 'minecraft:oak_door', {'facing': 'south', 'half': 'upper', 'hinge': 'left', 'open': 'false', 'powered': 'false'})
    s.set(0, 2, 3, 'minecraft:glass_pane', {'east': 'false', 'north': 'false', 'south': 'false', 'waterlogged': 'false', 'west': 'false'}); s.set(6, 2, 3, 'minecraft:glass_pane', {'east': 'false', 'north': 'false', 'south': 'false', 'waterlogged': 'false', 'west': 'false'})
    s.set(3, 3, 3, 'minecraft:lantern', {'hanging': 'true', 'waterlogged': 'false'}); s.set(5, 1, 5, 'minecraft:bookshelf'); s.chest(1, 1, 5, 'observer', 'east'); s.set(1, 1, 1, 'minecraft:lectern', {'facing': 'south', 'has_book': 'false', 'powered': 'false'}); return s
def S_bunker():
    s = St(13, 6, 13); s.fill(0, 0, 0, 12, 5, 12, 'minecraft:air'); s.shell(0, 0, 0, 12, 5, 12, 'minecraft:stone_bricks'); r = random.Random(3)
    for k in range(25): s.set(r.randrange(1, 12), r.choice([0, 5]), r.randrange(1, 12), 'minecraft:cracked_stone_bricks')
    for z in range(1, 12, 2): s.set(6, 1, z, 'minecraft:iron_bars', {'east': 'false', 'north': 'false', 'south': 'false', 'waterlogged': 'false', 'west': 'false'})
    for (x, z) in ((2, 2), (2, 10), (10, 2), (10, 10), (3, 6), (9, 6)): s.set(x, 1, z, HU + 'rusty_barrel')
    s.chest(11, 1, 6, 'bunker', 'west'); s.chest(1, 1, 6, 'bunker', 'east'); s.ent('mine_guardian', 6, 1, 6); s.set(6, 5, 12, 'minecraft:air'); s.fill(6, 1, 12, 6, 2, 12, 'minecraft:air'); return s
def S_shrine():
    s = St(11, 8, 11); r = random.Random(4); s.fill(0, 0, 0, 10, 0, 10, 'minecraft:mossy_cobblestone')
    for (x, z) in ((1, 1), (9, 1), (1, 9), (9, 9)): s.fill(x, 1, z, x, r.randrange(3, 6), z, 'minecraft:chiseled_stone_bricks')
    for x in range(11):
        for z in range(11):
            if (x in (2, 8) or z in (2, 8)) and r.random() > 0.45 and 2 <= x <= 8 and 2 <= z <= 8: s.fill(x, 1, z, x, r.randrange(1, 4), z, 'minecraft:mossy_stone_bricks')
    s.fill(4, 1, 4, 6, 1, 6, 'minecraft:stone_bricks'); s.chest(5, 2, 5, 'shrine', 'south'); s.ent('ruin_golem', 5, 1, 8); return s
def S_heart():
    s = St(25, 16, 25); import math
    for x in range(25):
        for z in range(25):
            d = math.hypot(x - 12, z - 12)
            if d <= 11.5: s.set(x, 0, z, HU + ('plague_flesh' if d > 3 else 'plague_block'))
            if 10.5 <= d <= 11.5: s.fill(x, 1, z, x, 8 - int(d % 3), z, HU + 'plague_flesh')
    for k in range(6):
        a = k * math.pi / 3; x = int(12 + 7 * math.cos(a)); z = int(12 + 7 * math.sin(a)); s.fill(x, 1, z, x, 9, z, HU + 'plague_flesh'); s.set(x, 10, z, HU + 'plague_vein')
    s.fill(11, 1, 11, 13, 1, 13, HU + 'plague_block'); s.set(12, 2, 12, HU + 'plague_heart'); s.ent('heart_guardian', 9, 1, 12); s.ent('heart_guardian', 15, 1, 12); s.ent('green_sentinel', 12, 1, 8); s.ent('green_sentinel', 12, 1, 16); return s
TABLE = [  # nome, builder, spacing, separation, step, tag biomi, sprofondamento
 ('white_chapel', S_chapel, 36, 14, 'surface_structures', '#minecraft:is_forest', 'beard_thin', True), ('ritual_circle', S_circle, 60, 24, 'surface_structures', '#minecraft:is_overworld', 'beard_thin', True),
 ('statue_garden', S_garden, 40, 16, 'surface_structures', '#minecraft:is_forest', 'beard_thin', True), ('plague_obelisk', S_obelisk, 48, 20, 'surface_structures', '#minecraft:is_overworld', 'beard_thin', True),
 ('rune_tower', S_tower, 56, 22, 'surface_structures', '#minecraft:is_hill', 'beard_thin', True), ('steve_outpost', S_outpost, 44, 18, 'surface_structures', '#minecraft:is_overworld', 'beard_thin', True),
 ('observer_hut', S_hut, 30, 10, 'surface_structures', '#minecraft:is_forest', 'beard_thin', True), ('rusty_bunker', S_bunker, 34, 12, 'underground_structures', '#minecraft:is_overworld', 'bury', False),
 ('ruin_shrine', S_shrine, 38, 14, 'surface_structures', '#minecraft:is_overworld', 'beard_thin', True)]
def structures():
    salt = 91000
    for (name, fn, sp, se, step, biomes, terr, surf) in TABLE:
        fn().save(RES + '/data/horror_universe/structure/%s.nbt' % name); salt += 77
        wj(D + '/worldgen/template_pool/%s.json' % name, {'fallback': 'minecraft:empty', 'elements': [{'weight': 1, 'element': {'element_type': 'minecraft:single_pool_element', 'location': HU + name, 'processors': 'minecraft:empty', 'projection': 'rigid'}}]})
        st = {'type': 'minecraft:jigsaw', 'biomes': HU + 'has_' + name if False else biomes, 'step': step, 'spawn_overrides': {}, 'terrain_adaptation': terr, 'start_pool': HU + name, 'size': 1, 'max_distance_from_center': 80, 'use_expansion_hack': False}
        if surf: st['start_height'] = {'absolute': 0}; st['project_start_to_heightmap'] = 'WORLD_SURFACE_WG'
        else: st['start_height'] = {'absolute': -24}
        wj(D + '/worldgen/structure/%s.json' % name, st)
        wj(D + '/worldgen/structure_set/%s.json' % name, {'structures': [{'structure': HU + name, 'weight': 1}], 'placement': {'type': 'minecraft:random_spread', 'spacing': sp, 'separation': se, 'salt': salt}})
    S_heart().save(RES + '/data/horror_universe/structure/heart_sanctum.nbt')
    # alcune strutture anche nel Vuoto Pallido
    wj(D + '/tags/worldgen/biome/pale_hollow_biomes.json', {'values': [HU + 'pale_barrens', HU + 'shadow_marsh', HU + 'arcane_meadow']})
if __name__ == '__main__':
    recipes(); loot(); tags(); worldgen(); structures(); print('data ok')
