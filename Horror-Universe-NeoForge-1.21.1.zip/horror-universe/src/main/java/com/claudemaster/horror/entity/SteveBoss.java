package com.claudemaster.horror.entity;

import com.claudemaster.horror.*;
import com.claudemaster.horror.ai.*;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.BossEvent;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import java.util.*;

/** Steve: un giocatore intelligente. 1 Sconosciuto (scambi), 2 Sopravvissuto, 3 Maestro, 4 Veterano (depositi), 5 Giocatore Perfetto (tre prove). Si adatta allo stile del giocatore e ricorda come è stato ferito. */
public class SteveBoss extends BossMob {
    private int healCd, stage, stageStart, tokens; private final List<BlockPos> caches = new ArrayList<>();
    public SteveBoss(EntityType<? extends SteveBoss> t, Level l) { super(t, l, Ent.STEVE); }
    @Override public String key() { return "steve"; }
    @Override protected boolean fightsOnPresence() { return nextLevelCache >= 2; }
    private int nextLevelCache = 2;
    @Override protected boolean wantsFight(ServerLevel l, ServerPlayer p) { nextLevelCache = nextLevel(p); return nextLevelCache >= 2 && super.wantsFight(l, p); }
    @Override protected Weapons.Rule rule() { return bossLevel == 5 && stage < 2 ? Weapons.Rule.immune() : Weapons.Rule.normal(); }
    @Override protected float progress() { return bossLevel == 5 && stage < 2 ? Math.min(1f, (fightTicks - stageStart) / (stage == 0 ? 3600f : 4800f)) : super.progress(); }
    @Override protected void begin(ServerLevel l, ServerPlayer p) {
        healCd = 0; stage = 0; stageStart = 0; tokens = 0; caches.clear(); clearGear();
        setHp(new double[]{0, 60, 160, 260, 380, 400}[Math.min(bossLevel, 5)]); barStyle(BossEvent.BossBarColor.BLUE, BossEvent.BossBarOverlay.PROGRESS);
        net.minecraft.world.item.Item[] g = bossLevel >= 4 ? new net.minecraft.world.item.Item[]{Items.NETHERITE_HELMET, Items.NETHERITE_CHESTPLATE, Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS} : bossLevel == 3 ? new net.minecraft.world.item.Item[]{Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE, Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS} : bossLevel == 2 ? new net.minecraft.world.item.Item[]{Items.IRON_HELMET, Items.IRON_CHESTPLATE, Items.IRON_LEGGINGS, Items.IRON_BOOTS} : null;
        if (g != null) { equip(EquipmentSlot.HEAD, new ItemStack(g[0])); equip(EquipmentSlot.CHEST, new ItemStack(g[1])); equip(EquipmentSlot.LEGS, new ItemStack(g[2])); equip(EquipmentSlot.FEET, new ItemStack(g[3])); }
        equip(EquipmentSlot.MAINHAND, new ItemStack(bossLevel >= 4 ? Items.NETHERITE_SWORD : bossLevel == 3 ? Items.DIAMOND_SWORD : bossLevel == 2 ? Items.IRON_SWORD : Items.WOODEN_SWORD));
        if (bossLevel >= 2) equip(EquipmentSlot.OFFHAND, new ItemStack(Items.SHIELD));
        say(p, bossLevel);
        if (bossLevel == 4) placeCaches(l, p, 4, 20, 40);
    }
    private void placeCaches(ServerLevel l, ServerPlayer p, int n, double min, double max) {
        for (int i = 0; i < n; i++) { Vec3 s = Fx.spotAround(l, p.position(), min, max); if (s == null) continue; BlockPos bp = BlockPos.containing(s); if (TempBlocks.set(l, bp, Reg.block("steve_cache").defaultBlockState(), 24000, true)) caches.add(bp); }
    }
    @Override public InteractionResult mobInteract(Player pl, InteractionHand h) {   // livello 1: scambio di oggetti, nessuna ostilità
        if (!level().isClientSide && !fighting && pl instanceof ServerPlayer sp && h == InteractionHand.MAIN_HAND) {
            ItemStack s = sp.getMainHandItem();
            if (s.isEmpty()) { Fx.say(sp, ent, 7); Saga.get(sp.serverLevel()).addRel(sp.getUUID(), ent, 2); return InteractionResult.SUCCESS; }
            s.shrink(1); Fx.give(sp, new ItemStack(new net.minecraft.world.item.Item[]{Items.BREAD, Items.ARROW, Items.TORCH, Items.COOKED_BEEF, Items.IRON_NUGGET, Reg.item("steve_token")}[random.nextInt(6)], 1 + random.nextInt(3)));
            Saga sg = Saga.get(sp.serverLevel()); sg.addRel(sp.getUUID(), ent, 8); if (sg.level(sp.getUUID(), ent) < 1) sg.si(sp.getUUID(), "lvl.steve", 1); Fx.say(sp, ent, 6); return InteractionResult.SUCCESS;
        }
        return super.mobInteract(pl, h);
    }
    @Override public Mood presenceMood(double d) { return d < 14 ? Mood.FLEEING : d > 34 ? Mood.STALKING : Mood.OBSERVING; }
    @Override protected void script(ServerLevel l, ServerPlayer p) {
        double d = distanceTo(p); float hp = getHealth() / getMaxHealth(); String style = Habits.style(l, p);
        if (bossLevel == 5) trials(l, p);
        if (d > 7 && d < 28 && every(bossLevel >= 3 ? 40 : 60) && hasLineOfSight(p)) shoot(l, p);
        if (bossLevel >= 2 && d < 10 && every(160)) { Vec3 dir = p.position().subtract(position()).normalize(); Vec3 mid = position().add(dir.scale(Math.min(4, d * 0.5))); for (int k = -1; k <= 1; k++) { BlockPos b = BlockPos.containing(mid.x - dir.z * k, mid.y, mid.z + dir.x * k); TempBlocks.set(l, b, Blocks.COBBLESTONE.defaultBlockState(), 300); TempBlocks.set(l, b.above(), Blocks.COBBLESTONE.defaultBlockState(), 300); } }
        if (bossLevel >= 2 && style.equals("ranged") && d > 6 && every(40)) { Vec3 c = cover(l, p); if (c != null) getNavigation().moveTo(c.x, c.y, c.z, 1.2); }          // contro gli arcieri: cerca copertura
        if (bossLevel >= 3 && style.equals("melee") && d < 4 && every(30)) { Vec3 v = position().subtract(p.position()).normalize().scale(8); getNavigation().moveTo(getX() + v.x, getY(), getZ() + v.z, 1.3); }   // contro la mischia: mantiene la distanza
        if (bossLevel >= 3 && style.equals("builder") && p.getY() > getY() + 2.5 && every(20)) TempBlocks.set(l, blockPosition().below(), Blocks.COBBLESTONE.defaultBlockState(), 600);   // ponti e torri
        if (healCd > 0) healCd--;
        if (bossLevel >= 2 && hp < 0.4f && healCd == 0 && (bossLevel != 4 || !caches.isEmpty() || bossLevel == 5)) { healCd = 700; Vec3 v = position().subtract(p.position()).normalize().scale(14); getNavigation().moveTo(getX() + v.x, getY(), getZ() + v.z, 1.4); later(50, () -> { heal(getMaxHealth() * 0.3f); Fx.particles(l, ParticleTypes.HEART, position().add(0, 2, 0), 6, 0.4); }); say(p, 5); }
        if (bossLevel >= 3 && hp < 0.3f && every(200) && d < 6) { Vec3 s = Fx.spotAround(l, p.position(), 12, 18); if (s != null) { Fx.particles(l, ParticleTypes.PORTAL, position().add(0, 1, 0), 20, 0.4); moveTo(s.x, s.y, s.z); Fx.sound(l, s, "teleport", 0.7f, 1.2f); } }      // perla dell'End
        if (bossLevel >= 3 && at(1200, 900)) { tpNear(l, p, 5, 9); say(p, 3); }                                                                                                                       // imboscata
        if (bossLevel >= 5) { if (mem.fire >= 2 && !hasEffect(MobEffects.FIRE_RESISTANCE)) addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 1200, 0)); if (mem.explosion >= 2) addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 200, 0)); }
        if (fightTicks > 16000) endFight(l, p, false);
    }
    private Vec3 cover(ServerLevel l, ServerPlayer p) {
        for (int i = 0; i < 12; i++) { Vec3 c = Fx.spotAround(l, position(), 3, 10); if (c != null && Rays.blocked(l, c.add(0, 1.6, 0), p.getEyePosition(), this)) return c; } return null;
    }
    private void shoot(ServerLevel l, ServerPlayer p) {
        Arrow a = EntityType.ARROW.create(l); if (a == null) return;
        a.setOwner(this); a.setPos(getX(), getEyeY() - 0.1, getZ()); a.pickup = AbstractArrow.Pickup.DISALLOWED; a.setBaseDamage(2.0 + bossLevel * 0.5);
        Vec3 t = p.getEyePosition().subtract(a.position()); a.shoot(t.x, t.y + Math.sqrt(t.x * t.x + t.z * t.z) * 0.05, t.z, 1.7f, Math.max(1f, 8f - bossLevel * 1.5f)); l.addFreshEntity(a); Fx.vsound(l, position(), net.minecraft.sounds.SoundEvents.ARROW_SHOOT, 0.8f, 1f);
    }
    private void trials(ServerLevel l, ServerPlayer p) {   // Giocatore Perfetto: 0 sopravvivenza, 1 strategia/risorse, 2 combattimento finale
        int t = fightTicks - stageStart;
        if (stage == 0) { if (at(400, 100)) summon(l, "armored_hunter", 1, 12, p); if (t >= 3600) { stage = 1; stageStart = fightTicks; placeCaches(l, p, 3, 25, 45); tokens = 0; say(p, 4); bar.setName(net.minecraft.network.chat.Component.literal("Steve — prova 2: strategia")); } }
        else if (stage == 1) { caches.removeIf(bp -> !l.getBlockState(bp).is(Reg.block("steve_cache"))); tokens = 3 - caches.size(); if (caches.isEmpty() && t > 40) { stage = 2; stageStart = fightTicks; say(p, 6); bar.setName(net.minecraft.network.chat.Component.literal("Steve — prova 3: duello")); } else if (t > 4800) endFight(l, p, false); if (at(500, 100)) summon(l, "mech_sentinel", 1, 12, p); }
    }
    @Override public boolean hurt(DamageSource src, float amt) {   // adattamento: scudo più efficace contro ciò che lo ha ferito più spesso
        if (bossLevel >= 2 && src.getEntity() != null && getViewVector(1f).dot(src.getEntity().position().subtract(position()).normalize()) > 0.3) {
            float f = src.is(DamageTypeTags.IS_PROJECTILE) ? (bossLevel >= 5 && mem.ranged >= 3 ? 0.3f : 0.6f) : (bossLevel >= 5 && mem.melee >= 6 ? 0.55f : 0.8f); amt *= f;
        }
        return super.hurt(src, amt);
    }
    public static void cacheBroken(ServerLevel l, ServerPlayer p, BlockPos pos) {
        for (SteveBoss s : l.getEntitiesOfClass(SteveBoss.class, p.getBoundingBox().inflate(120), x -> x.fighting)) if (s.caches.remove(pos)) { Fx.msg(p, "msg.cache_broken", s.caches.size()); Fx.sound(l, Vec3.atCenterOf(pos), "alarm", 0.6f, 1f); s.say(p, 1); }
    }
    @Override protected void cleanup(ServerLevel l, ServerPlayer p) { killMinions(l); for (BlockPos bp : caches) TempBlocks.restoreNear(l, bp, 1, s -> true); TempBlocks.restoreNear(l, blockPosition(), 60, s -> s.is(Blocks.COBBLESTONE)); }
    @Override protected void reward(ServerLevel l, ServerPlayer p) {
        Saga.get(l).addRel(p.getUUID(), ent, 15);
        switch (bossLevel) { case 2 -> Fx.give(p, "steel_ingot", 3); case 3 -> { Fx.give(p, "steve_token", 2); Fx.give(p, "scroll_steve", 1); } case 4 -> Fx.give(p, "steel_ingot", 6); default -> { Fx.give(p, "steve_token", 5); Fx.give(p, "plague_ingot", 2); } }
    }
}
