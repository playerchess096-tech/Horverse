package com.claudemaster.horror;

import com.google.gson.JsonObject;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.MapColor;

/** Costruisce i blocchi dal manifest; solo due hanno comportamenti propri (Nebbia Oscura e Terra della Piaga), il resto è gestito da eventi. */
public final class HBlocks {
    private static SoundType snd(String s) {
        return switch (s) { case "metal" -> SoundType.METAL; case "deepslate" -> SoundType.DEEPSLATE; case "gravel" -> SoundType.GRAVEL; case "wart" -> SoundType.WART_BLOCK; case "glass" -> SoundType.GLASS;
            case "wool" -> SoundType.WOOL; case "amethyst" -> SoundType.AMETHYST; case "wood" -> SoundType.WOOD; case "candle" -> SoundType.CANDLE; default -> SoundType.STONE; };
    }
    public static Block make(JsonObject d) {
        float hard = (float) Content.n(d, "hard", 2), res = (float) Content.n(d, "res", 6); String kind = Content.s(d, "kind", "plain"); final int light = (int) Content.n(d, "light", 0);
        BlockBehaviour.Properties pr = BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_GRAY).sound(snd(Content.s(d, "snd", "stone"))).strength(hard < 0 ? -1f : hard, res);
        if (light > 0) pr = pr.lightLevel(s -> light);
        if (!Content.s(d, "lvl", "none").equals("none")) pr = pr.requiresCorrectToolForDrops();
        return switch (kind) {
            case "dark" -> new DarkFog(pr.noCollission().noOcclusion().strength(-1f, 0f));
            case "cube", "glitch" -> new Block(pr.noOcclusion());
            case "illusion" -> new Block(pr.noCollission());
            case "plague" -> new PlagueSoil(pr.randomTicks());
            default -> new Block(pr);
        };
    }
    /** Nebbia Oscura: non solida, infligge Corruzione e un po' di danno a chi la attraversa (sparisce da sola: è sempre temporanea). */
    public static class DarkFog extends Block {
        public DarkFog(Properties p) { super(p); }
        @Override public void entityInside(BlockState st, Level l, BlockPos pos, Entity e) {
            if (!l.isClientSide && e instanceof LivingEntity le && l.getGameTime() % 10 == 0) { Fx.fx(le, "corruption", 100, 0); le.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 60, 0)); le.hurt(l.damageSources().magic(), 1f); }
        }
    }
    /** Terra della Piaga: si espande lentamente SOLO in modo temporaneo (tramite TempBlocks) e mai oltre un tetto; la Fiala di Contenimento la ferma. */
    public static class PlagueSoil extends Block {
        public PlagueSoil(Properties p) { super(p); }
        @Override public void randomTick(BlockState st, ServerLevel l, BlockPos pos, RandomSource r) {
            if (r.nextInt(6) != 0 || TempBlocks.count(l) > 400 || l.getGameTime() < Saga.get(l).wl("plague_contained_until")) return;
            BlockPos t = pos.offset(r.nextInt(3) - 1, r.nextInt(3) - 1, r.nextInt(3) - 1); BlockState s = l.getBlockState(t);
            if ((s.is(Blocks.GRASS_BLOCK) || s.is(Blocks.DIRT)) && l.getBlockState(t.above()).isAir()) TempBlocks.set(l, t, defaultBlockState(), 6000, true);
        }
    }
    private HBlocks() {}
}
