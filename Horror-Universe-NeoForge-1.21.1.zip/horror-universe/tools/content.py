# -*- coding: utf-8 -*-
# Fonte unica dei contenuti "semplici": usata sia dal generatore di asset sia (via horror_content.json) dal codice Java.
PAL = {
 'pale':('d9d6cc','a9a597','f4f2ea','ffffff'), 'white':('e8e8ee','b4b4c4','ffffff','ffffff'),
 'shadow':('1b1a24','0a0a10','3a3850','8a4bff'), 'corrupt':('2a1a35','100818','4a2a5a','b020ff'),
 'green':('2f9b3a','14501c','8cff7a','40ff60'), 'rune':('5a3aa8','2a1860','b090ff','d070ff'),
 'steel':('8a8f98','50555e','c8ccd4','ffcc40'), 'obs':('2d2d33','141418','55555d','ffffff'),
 'blood':('6a1a1a','300808','a03030','ff3030'), 'gold':('c8a030','7a5a10','ffe070','fff0a0'),
 'bone':('cfc6a8','8a8268','efe8d0','ffffff'), 'ender':('1a0f2a','080410','3a2060','e040ff'),
 'storm':('4a5a78','202838','9ab0e0','80d0ff'), 'rust':('7a4a2a','3a2010','b0733a','e09040'),
}
# id|nome|owner|model|w|h|hp|dmg|spd|pal|abilita|debolezze(-=resistenza)|glow|scala|peso_spawn
MOBS_TXT = """
white_eyed_zombie|Zombie dagli Occhi Bianchi|custode|humanoid|0.6|1.95|44|7|0.29|white|dash,hit_slow,summon_pack|light,-projectile|1|1|0
pale_guardian|Guardiano Pallido|custode|humanoid|0.9|2.4|70|9|0.22|pale|guardian,deflect,hit_weakness|pickaxe|1|1.25|0
lightning_knight|Cavaliere del Fulmine|custode|humanoid|0.7|2.0|52|8|0.27|storm|lightning,hit_electrified,armor|-fire|1|1.05|0
end_sentinel|Sentinella dell'End|custode|enderman|0.6|2.9|60|7|0.30|ender|blink,gaze,guardian|water|1|1|0
white_mimic|Imitatore Bianco|custode|humanoid|0.6|1.95|36|6|0.30|white|echo,mimic_sound,stalk|magic|1|1|0
custode_shadow|Ombra del Custode|custode|humanoid|0.6|1.95|30|6|0.32|shadow|blink,vanish,hit_darkness|light|1|1|0
ritual_herald|Araldo del Rituale|custode|humanoid|0.6|1.95|40|3|0.24|pale|heal_pulse,summon,flee_low|projectile|1|1|0
ritual_enderman|Enderman Corrotto dal Rituale|custode|enderman|0.7|3.1|120|11|0.32|ender|blink,hit_gravity,summon_pack|water|1|1.1|0
living_statue|Statua Vivente|corrotto|humanoid|0.7|2.1|90|16|0.30|shadow|freeze,statue_touch|pickaxe,-sword|1|1.1|0
wandering_eye|Occhio Errante|corrotto|creeper|0.6|1.2|26|6|0.26|corrupt|stalk,hit_darkness,dash|light|1|0.8|0
devouring_shadow|Ombra Divoratrice|corrotto|spider|1.2|0.7|34|6|0.34|shadow|regen_dark,hit_wither,leap|light,fire|1|1|0
dark_knight|Cavaliere Oscuro|corrotto|skeleton|0.6|1.99|58|9|0.27|corrupt|armor,deflect,hit_corruption|magic|1|1.1|0
corrupt_mimic|Mimico Corrotto|corrotto|creeper|0.9|0.9|48|10|0.30|corrupt|ambush,hit_corruption|fire|1|0.9|0
soul_wisp|Frammento dell'Anima|corrotto|creeper|0.5|0.9|16|0|0.32|corrupt|soul_leech,stalk|magic|1|0.6|0
statue_guardian|Guardiano delle Statue|corrotto|humanoid|0.8|2.3|80|10|0.24|shadow|guardian,summon,deflect|pickaxe|1|1.2|0
incomplete_clone|Clone Incompleto|corrotto|humanoid|0.6|1.8|34|6|0.30|corrupt|mirror,hit_slow|light|1|1|0
light_devourer|Divoratore di Luce|corrotto|spider|1.4|1.0|44|7|0.30|shadow|snuff,hit_darkness,regen_dark|light|1|1.2|0
darkness_herald|Araldo dell'Oscurità|corrotto|humanoid|0.6|1.95|38|4|0.26|corrupt|snuff,summon,flee_low|light|1|1|0
green_zombie|Zombie Verde|e404|humanoid|0.6|1.95|42|7|0.28|green|hit_plague,dash|fire|1|1|0
corrupt_skeleton|Scheletro Corrotto|e404|skeleton|0.6|1.99|36|6|0.27|green|bolt,hit_plague|fire|1|1|0
infected_creeper|Creeper Infetto|e404|creeper|0.6|1.7|30|0|0.28|green|contaminate,dash|water|1|1|0
living_tentacle|Tentacolo Vivente|e404|spider|0.8|2.2|50|9|0.0|green|root,pull,hit_plague|fire|1|1.1|0
green_mimic|Mimico Verde|e404|creeper|0.9|0.9|50|10|0.30|green|ambush,hit_plague|fire|1|0.9|0
imperfect_clone|Clone Imperfetto|e404|humanoid|0.6|1.8|40|7|0.30|green|mirror,hit_plague|fire|1|1|0
green_sentinel|Sentinella Verde|e404|humanoid|0.7|2.2|90|8|0.0|green|root,beam|plague_weapon|1|1.15|0
minor_demon|Demone Minore|e404|humanoid|0.7|2.2|70|10|0.30|green|guardian,leap,hit_plague|plague_weapon|1|1.15|0
major_demon|Demone Maggiore|e404|humanoid|1.0|3.0|260|14|0.26|green|summon,meteor,hit_wither,retreat_phase|plague_weapon|1|1.5|0
corrupt_pup|Cucciolo Corrotto|e404|spider|0.9|0.8|160|9|0.33|green|leap,hit_plague,drain_hearts|plague_weapon|1|1.3|0
item_devourer|Divoratore di Oggetti|e404|spider|0.9|0.7|30|3|0.38|green|steal,flee_low,dash|projectile|1|0.9|0
heart_guardian|Guardiano del Cuore|e404|humanoid|1.1|3.0|220|13|0.22|green|guardian,deflect,summon|plague_weapon|1|1.5|0
human_imitator|Imitatore Umano|e404|humanoid|0.6|1.8|36|6|0.31|green|mimic_sound,stalk,hit_slow|light|1|1|0
plague_hunter|Cacciatore della Piaga|e404|humanoid|0.6|2.0|50|8|0.34|green|stalk,dash,hit_plague|fire|1|1|0
meteor_beast|Bestia Meteorica|e404|spider|1.6|1.4|140|12|0.26|rust|meteor,leap,hit_fire|water|1|1.5|0
green_herald|Araldo Verde|e404|humanoid|0.6|1.95|36|3|0.26|green|summon,heal_pulse,flee_low|projectile|1|1|0
e404_clone_ally|Clone Redento|e404|humanoid|0.6|1.8|120|8|0.32|green|ally,follow,bolt|-fire|1|1|0
barrier_pylon|Pilone Barriera|e404|humanoid|0.9|2.6|100|0|0.0|green|root,shield_aura|plague_weapon|1|1.2|0
corrupt_pup_friend|Cucciolo Corrotto Amico|e404|spider|0.8|0.7|40|0|0.35|green|follow,ally|fire|1|0.9|0
runic_golem|Golem Runico|mago|humanoid|1.0|2.8|120|14|0.2|rune|guardian,deflect,hit_slow|magic|1|1.4|0
illusory_specter|Spettro Illusorio|mago|humanoid|0.6|1.95|28|5|0.30|rune|illusion_split,blink,vanish|magic|1|1|0
arcane_guardian|Guardiano Arcano|mago|humanoid|0.8|2.2|90|9|0.24|rune|guardian,bolt,shield_aura|-magic|1|1.2|0
mage_raven|Corvo del Mago|mago|creeper|0.5|0.7|12|2|0.40|rune|stalk,clue_drop,flee_low|projectile|1|0.5|0
astral_mimic|Mimico Astrale|mago|humanoid|0.6|1.95|38|7|0.30|rune|mimic_sound,ambush,blink|magic|1|1|0
violet_elemental|Elementale Viola|mago|creeper|0.8|1.6|46|7|0.27|rune|bolt,hit_weakness|water|1|1.2|0
rune_knight|Cavaliere delle Rune|mago|skeleton|0.6|1.99|62|10|0.26|rune|armor,hit_rune_seal|magic|1|1.1|0
enchanted_serpent|Serpente Incantato|mago|spider|1.2|0.6|40|8|0.30|rune|guardian,hit_slow,webs|fire|1|1|0
staff_keeper|Custode del Bastone|mago|humanoid|1.0|2.8|300|13|0.24|rune|summon,bolt,shield_aura,heal_pulse|magic|1|1.4|0
living_echo|Eco Vivente|mago|humanoid|0.6|1.95|30|5|0.30|rune|echo,vanish|magic|1|1|0
gravity_golem|Golem Gravitazionale|mago|humanoid|1.0|2.8|130|12|0.2|rune|gravity,guardian|magic|1|1.4|0
arcane_herald|Araldo Arcano|mago|humanoid|0.6|1.95|34|3|0.26|rune|bolt,summon,flee_low|projectile|1|1|0
mage_copy|Copia del Mago|mago|humanoid|0.6|1.95|30|6|0.32|rune|mirror,bolt,vanish|magic|1|1|0
illusion_double|Doppio Illusorio|mago|humanoid|0.6|1.95|1|0|0.32|rune|vanish,illusion_split|-magic|1|1|0
mech_sentinel|Sentinella Meccanica|steve|humanoid|0.8|2.0|70|8|0.0|steel|root,bolt|-magic|1|1.1|0
defense_golem|Golem da Difesa|steve|humanoid|1.0|2.8|140|15|0.22|steel|guardian,deflect|magic|0|1.4|0
base_guardian|Guardiano della Base|steve|humanoid|0.6|1.95|60|8|0.28|steel|guardian,armor,shield_use|magic|0|1|0
recon_drone|Drone di Ricognizione|steve|creeper|0.5|0.5|10|2|0.45|steel|stalk,flee_low,clue_drop|projectile|1|0.5|0
armored_hunter|Cacciatore Corazzato|steve|humanoid|0.6|2.0|80|10|0.31|steel|armor,dash,shield_use|magic|0|1.05|0
tactical_mimic|Mimico Tattico|steve|creeper|0.9|0.9|40|9|0.30|steel|ambush,mimic_sound|fire|0|0.9|0
auto_builder|Costruttore Automatico|steve|humanoid|0.8|1.8|50|4|0.26|steel|builder,flee_low|magic|0|1|0
faceless_wanderer|Viandante Senza Volto|neutral|humanoid|0.6|2.1|40|6|0.27|obs|vanish,stalk|light|1|1.1|6
pale_deer|Cervo Pallido|neutral|spider|1.0|1.6|26|0|0.36|pale|clue_trail,flee_low|projectile|1|1.2|5
clue_raven|Corvo degli Indizi|neutral|creeper|0.5|0.6|10|0|0.40|obs|clue_drop,stalk,flee_low|projectile|1|0.5|6
wandering_specter|Spettro Errante|neutral|humanoid|0.6|1.95|30|5|0.26|bone|vanish,gaze,night|magic|1|1|4
ruin_keeper|Custode delle Rovine|neutral|humanoid|0.9|2.5|110|11|0.22|bone|guardian,deflect|pickaxe|1|1.3|3
silent_imitator|Imitatore Silenzioso|neutral|humanoid|0.6|1.95|34|6|0.29|obs|mimic_sound,stalk,ambush|magic|1|1|4
night_hunter|Cacciatore Notturno|hostile|humanoid|0.6|2.0|46|8|0.34|shadow|night,stalk,dash|light|1|1|6
shadow_spider|Ragno delle Ombre|hostile|spider|1.3|0.9|38|7|0.33|shadow|regen_dark,webs,hit_slow|light|1|1.1|6
broken_knight|Cavaliere Spezzato|hostile|skeleton|0.6|1.99|56|9|0.25|bone|armor,deflect|magic|1|1.05|5
chest_mimic|Mimico dei Bauli|hostile|creeper|0.9|0.9|44|11|0.30|rust|ambush,leap|fire|0|0.9|5
burrowing_beast|Bestia Sotterranea|hostile|spider|1.5|1.1|80|11|0.30|rust|emerge,pull|projectile|0|1.4|4
mine_guardian|Guardiano delle Miniere|hostile|humanoid|0.9|2.4|90|10|0.24|rust|guardian,armor,deflect|magic|0|1.25|4
corridor_specter|Spettro del Corridoio|hostile|humanoid|0.6|1.95|30|7|0.34|bone|vanish,dash,gaze|light|1|1|4
silent_predator|Predatore Silenzioso|hostile|spider|1.1|0.9|48|9|0.36|obs|stalk,ambush,dash|light|1|1|5
ruin_golem|Golem delle Rovine|hostile|humanoid|1.1|3.0|160|15|0.2|bone|guardian,deflect|pickaxe|1|1.5|3
shadow_herald|Araldo delle Ombre|hostile|humanoid|0.6|1.95|34|3|0.26|shadow|summon,snuff,flee_low|light|1|1|4
reaper|Il Mietitore|boss|humanoid|0.8|2.4|220|14|0.30|blood|retreat_phase,dash,hit_wither,blink|-fire|1|1.25|1
hollow_giant|Il Gigante Cavo|boss|humanoid|1.4|4.2|420|18|0.2|bone|guardian,deflect,pull|pickaxe|1|2.0|1
statue_queen|La Regina delle Statue|boss|humanoid|0.8|2.4|260|13|0.26|shadow|summon,freeze,hit_slow|pickaxe|1|1.25|1
portal_guardian|Il Guardiano del Portale|boss|enderman|0.9|3.4|380|15|0.28|ender|guardian,blink,gaze|water|1|1.3|1
light_eater|Il Divoratore di Luce|boss|spider|2.0|1.6|300|13|0.28|shadow|snuff,regen_dark,hit_darkness,leap|light|1|1.8|1
runic_colossus|Il Colosso Runico|boss|humanoid|1.5|4.0|450|17|0.19|rune|bolt,shield_aura,gravity|magic|1|2.0|1
meteor_lord|La Bestia Meteorica Maggiore|boss|spider|2.2|1.8|340|16|0.25|rust|meteor,leap,hit_fire|water|1|1.9|1
nameless_knight|Il Cavaliere Senza Nome|boss|skeleton|0.7|2.2|320|15|0.29|obs|armor,deflect,dash,retreat_phase|magic|1|1.2|1
"""
BOSSES = [  # id, nome italiano, palette, colore uovo
 ('custode','Il Custode dagli Occhi Bianchi','white',0xE8E8EE,0x202020),
 ('corrotto','Il Corrotto','corrupt',0x2A1A35,0xB020FF),
 ('entity404','Entity 404','green',0x2F9B3A,0x101010),
 ('mago','L\'Uomo Magico','rune',0x5A3AA8,0xD070FF),
 ('steve','Steve, il Giocatore Impossibile','steel',0x4AA8C8,0x3A3A9A),
 ('osservatore','L\'Osservatore','obs',0x141418,0xFFFFFF)]
EFFECTS = [  # id, nome, colore, buono, intervallo tick
 ('corruption','Corruzione',0x5a1a7a,0,40),('plague','Piaga',0x2f9b3a,0,40),('watched','Sotto Osservazione',0x303030,0,60),
 ('electrified','Elettrizzato',0x80d0ff,0,30),('rune_seal','Sigillo Runico',0x7a4aff,0,20),('gravity_flux','Instabilità Gravitazionale',0xa080ff,0,10),
 ('soul_drain','Anima Assorbita',0x401060,0,40),('purified','Purificato',0xfff0a0,1,20),('eden_ward','Protezione dell\'Eden',0xffe070,1,20),
 ('tremor','Tremore',0x404040,0,20),('inner_threat','Presenza Interiore',0x1a5a22,0,100),('limb_loss','Perdita di un Arto',0x6a1a1a,0,40),
 ('green_hearts','Cuori Verdi',0x40ff60,0,40)]
SOUNDS = ['ambient.pale','ambient.void','ambient.plague','ambient.arcane','ambient.steel','ambient.watch','ambient.ritual','ambient.dark',
 'heartbeat','steps_behind','door_creak','whisper_a','whisper_b','glitch_a','glitch_b','thunder_far','zap','chime','rune_hum','whoosh',
 'teleport','stinger','choir','growl','breath','statue_grind','cast','portal','static','bell','tentacle','scream_far','mimic','clone_laugh','alarm','swing_heavy']
EFF_NAMES = {e[0]:e for e in EFFECTS}
def parse_mobs():
    out=[]
    for ln in MOBS_TXT.strip().splitlines():
        f=ln.split('|'); 
        out.append(dict(id=f[0],it=f[1],owner=f[2],model=f[3],w=float(f[4]),h=float(f[5]),hp=float(f[6]),dmg=float(f[7]),spd=float(f[8]),
          pal=f[9],abil=[a for a in f[10].split(',') if a],weak=[a for a in f[11].split(',') if a],glow=f[12]=='1',scale=float(f[13]),weight=int(f[14])))
    return out
