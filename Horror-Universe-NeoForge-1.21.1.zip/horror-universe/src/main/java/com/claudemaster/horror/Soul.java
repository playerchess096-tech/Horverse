package com.claudemaster.horror;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.GameType;

/** Corruzione dell'anima (0-100) e morte permanente NARRATIVA (spettatore finché non c'è il recupero). */
public final class Soul {
    public static int get(ServerPlayer p) { return Saga.get(p.serverLevel()).gi(p.getUUID(), "soul"); }
    public static void add(ServerPlayer p, int d) {
        Saga s = Saga.get(p.serverLevel()); int v = Math.max(0, Math.min(100, s.gi(p.getUUID(), "soul") + d)); s.si(p.getUUID(), "soul", v);
        Fx.bar(p, "msg.soul", v);
        if (v >= 100 && Config.PERMADEATH.get() && !s.gb(p.getUUID(), "lost")) lose(p);
    }
    public static void lose(ServerPlayer p) {
        Saga s = Saga.get(p.serverLevel()); s.sb(p.getUUID(), "lost", true); s.sl(p.getUUID(), "lostAt", p.serverLevel().getGameTime()); s.si(p.getUUID(), "soul", 0);
        p.hurt(p.serverLevel().damageSources().genericKill(), Float.MAX_VALUE);
    }
    /** Chiamato al respawn: se l'anima è persa, il giocatore resta spettatore (reversibile). */
    public static void onRespawn(ServerPlayer p) {
        Saga s = Saga.get(p.serverLevel());
        if (s.gb(p.getUUID(), "lost")) {
            s.si(p.getUUID(), "prevMode", p.gameMode.getGameModeForPlayer() == GameType.SPECTATOR ? 0 : p.gameMode.getGameModeForPlayer().getId());
            p.setGameMode(GameType.SPECTATOR); Fx.msg(p, "msg.permadeath");
        }
    }
    public static void recover(ServerPlayer p) {
        Saga s = Saga.get(p.serverLevel()); if (!s.gb(p.getUUID(), "lost")) return;
        s.sb(p.getUUID(), "lost", false); p.setGameMode(GameType.byId(s.gi(p.getUUID(), "prevMode"))); Fx.msg(p, "msg.recovered");
    }
    public static void tick(ServerPlayer p) {
        Saga s = Saga.get(p.serverLevel());
        if (s.gb(p.getUUID(), "lost") && p.serverLevel().getGameTime() - s.gl(p.getUUID(), "lostAt") > Config.PERMADEATH_MIN.get() * 1200L) recover(p);
    }
    private Soul() {}
}
